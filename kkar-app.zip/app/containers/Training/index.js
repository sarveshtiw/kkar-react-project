import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import {DashboardMenu} from 'components/DashboardMenu';
import TextField from 'material-ui/TextField';
var util = require('utils/request');
import {ViewEdit} from 'components/ViewEdit_Component';
import {ProgressSlider} from 'components/ProgressSlider';
import cookie from 'react-cookie';
var ProgressStyle = {
    width:'60%'
};

export class Training extends React.Component {
  openRoute = (route) => {
      this.props.changeRoute(route);
  };
    constructor(props) {
        super(props);
        this.state = {
            stateUpdate:false,
            years:[1976,1977,1978,1979,1980,1981,1982,1983,1984,1985,1986,1987,1988,1989,1990,1991,1992,1993,1994,1995,
                1996,1997,1998,1999,2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016],

            trainingdata:[],
            form_data:{
                id_training: 0,
                institute_name: '',
                nature_of_training:'',
                education_photo: '',
                education_photo_name: '',
                education_video: '',
                education_link: '',
                number_of_days: '',
                duration_in:'',
                year_of_training: '',
                button_text:'ADD',
                result : null,
                resultMsg : ''
            }
          }
    }

    componentDidMount() {
       document.title = "Extended Profile | Kalakar";
      (function($){
             $(window).load(function(){
             $(".scroller335").mCustomScrollbar({
                 setHeight:335,
                 theme:"dark-3"
               });
             });

         })(jQuery);




      var local= this;
      $("[data-toggle='tooltip']").tooltip();
      document.getElementById("uploadBtn").onchange = function () {
          var filename = this.value.replace(/^.*\\/, "");
          document.getElementById("uploadFile").value=filename;
          local.isDisabledImageUpload(filename);
       };
        var param = {action: 'training_list', profile_id: this.props.params.profileId}
        var formState = this;
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                if(data.data!=null){
                    formState.setState({trainingdata : data.data});
                    formState.initializeGallery();
                }
            }
            else {
                  console.log("Error in TrainingList.Please try again.");
            }
        });

   }
    initializeGallery(){
        jQuery('#lightgallery').lightGallery();
        jQuery('.lightgallery-single-image').lightGallery();
        jQuery('.lightgallery-single-video').lightGallery();
    }

    handleChange(name, e) {
        var change = {};
        change.form_data = this.state.form_data;
        change.form_data[name] = e.target.value;
        this.setState(change);
        if(name=='institute_name'){
            this.validate1();
        }
        if(name=='nature_of_training'){
            this.validate2();
        }
        if(name=='education_video'){
            this.isDisabledWebsite();
        }
        if(name=='education_link'){
            this.isDisabledLink();
        }
        if(name=='number_of_days'){
            this.validate3();
        }

    }

    handleOptionChange(name,e){
      var change = {};
      change.form_data = this.state.form_data;
      change.form_data[name] = e.target.value;
      this.setState(change);
        if(name=='year_of_training'){
            this.validateSelect();
        }

     }
    handleImageChange(e) {
        e.preventDefault();
        let reader = new FileReader();
        let file = e.target.files[0];
        reader.onloadend = () => {
            var change = {};
            change.form_data = this.state.form_data;
            change.form_data['education_photo'] = reader.result;
            change.form_data['education_photo_name'] = file.name;
            this.setState(change);
        };
        reader.readAsDataURL(file);
    }

    validate1() {
        let valid=false;
        if(this.state.form_data.institute_name == ""){
            this.setState({
               name_error_text: "Required"
            });
        } else {
            valid=true
            this.setState({
                name_error_text: null
            })

        }return valid;
    }
    validate2() {
        let valid=false;
        if(this.state.form_data.nature_of_training == ""){
            this.setState({
                nature_of_training_error: "Required"
            });
        } else {
            valid=true
            this.setState({
                nature_of_training_error: null
            })

        }return valid;
    }
    validate3() {
        let valid=false;
        if(this.state.form_data.number_of_days == ""){
            this.setState({
                dworked_error_text: "Required"
            });
        } else {
            valid=true
            this.setState({
                dworked_error_text: null
            })

        }return valid;
    }
    validateWebsite(value){
        var exp =/^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?.*$/
        return exp.test(value);
    }
    isDisabledWebsite() {
        let urlIsValid = false;
        if (this.state.form_data.education_video === "") {
            urlIsValid=true;
            this.setState({
                website_error_text: null
            });
        } else {
            if (this.validateWebsite(this.state.form_data.education_video)) {
                urlIsValid = true;
                this.setState({
                    website_error_text: null
                });
            }
            else {
                this.setState({
                    website_error_text: "Sorry, this is not a valid format"
                });
            }
        }
        return urlIsValid;
    }
    isDisabledLink() {
        let urlIsValid = false;
        if (this.state.form_data.education_link  === "") {
            urlIsValid=true;
            this.setState({
                lwebsite_error_text: null
            });
        } else {
            if (this.validateWebsite(this.state.form_data.education_link)) {
                urlIsValid = true;
                this.setState({
                    lwebsite_error_text: null
                });
            }
            else {
                this.setState({
                    lwebsite_error_text: "Sorry, this is not a valid format"
                });
            }
        }
        return urlIsValid;
    }
    validateSelect() {
        let valid=false;

        if(this.state.form_data.year_of_training == ""){
            this.setState({
                    year_error_text: "Required"
                }
            );
        } else {
            valid=true;
            this.setState({
                year_error_text: null
            });

        }return valid;
    }

    validateImageUpload(value){
        var exp =/([a-zA-Z0-9\s_\\.\-:])+(.png|.jpg|.gif|.jpeg)$/;
        return exp.test(value);
    }
    isDisabledImageUpload(value) {
        let urlIsValid = false;
        if (value === "") {
            urlIsValid=true;
            this.setState({
                photo_error_text: null
            });
        } else {
            if (this.validateImageUpload(value)) {
                urlIsValid = true;
                this.setState({
                    photo_error_text: null
                });
            }
            else {
                this.setState({
                    photo_error_text: "Please upload Valid image file"
                });
            }
        }
        return urlIsValid;
    }

    uploadMedia(){
      var form = this;
      var param = {
        action : 'mediaupload',
        user_id : cookie.load('userId'),
        profile_id : this.props.params.profileId,
        file_name : this.state.form_data.education_photo_name,
        imgsrc : this.state.form_data.education_photo
      }
      util.getSetData(param, function (mediaData) {
          if (mediaData.status == "success") {
              form.uploadTraining(mediaData.mediaId);
           }

      });
    }

  uploadTraining(mediaId){
    var formState = this;

  var trainingParam = {
    action : "training",
    profile_id : this.props.params.profileId,
    institute_name: this.state.form_data.institute_name,
    nature_of_training:this.state.form_data.nature_of_training,
    education_video: this.state.form_data.education_video,
    education_link: this.state.form_data.education_link,
    number_of_days: this.state.form_data.number_of_days,
    duration_in:this.state.form_data.duration_in,
    year_of_training: this.state.form_data.year_of_training,
    training_media : mediaId
  }
  if (this.state.form_data.id_training != 0) {
      trainingParam["training_id"] = this.state.form_data.id_training;
  }

    util.getSetData(trainingParam, function (data) {
    if(data.status == "success"){
        formState.state.stateUpdate = true;
      var param1 = {action: 'training_list', profile_id: formState.props.params.profileId}
      util.getSetData(param1, function (data1) {
          if (data1.status == "success") {
            document.getElementById("uploadFile").value = "";
              formState.setState({
                trainingdata : data1.data,
                form_data:{
                  id_training: 0,
                  institute_name: '',
                  nature_of_training:'',
                  education_photo: '',
                  education_video: '',
                  education_link: '',
                  number_of_days: '',
                  duration_in:'',
                  year_of_training: '',
                  button_text : 'ADD',
                  result : true,
                  resultMsg : data.message
              }
            });
              formState.initializeGallery();
          }
      });
    }
    else {
      var change = {};
      change.form_data = formState.state.form_data;
      change.form_data["result"] = false;
      change.form_data["resultMsg"] = data.message;
      formState.setState(change);
  }
});
  }

    submitData(){
        if(!(this.validate1() && this.validate2() &&   this.isDisabledWebsite() && this.isDisabledLink() &&  this.validate3()
            && this.validateSelect()  )){
            this.validate1();
            this.validate2();
            this.validate3();
            this.isDisabledWebsite();
            this.isDisabledLink();
            this.validateSelect();
            return;
        }
        if(this.state.form_data.education_photo_name != undefined && this.state.form_data.education_photo_name != "" && this.state.form_data.education_photo_name != null && this.state.form_data.education_photo_name != 0)
        {
          //Media upload
          this.uploadMedia();
        }
        else
        {
          //Upload Training
          if(this.state.form_data.education_photo != "" && this.state.form_data.education_photo != null){
              this.uploadTraining(this.state.form_data.education_photo);
            }
          else
          {
              this.uploadTraining(0);
          }

        }
   }

    handleEditClick(id,local) {
     var param = {action: 'training_detail', trainig_id: id}
     util.getSetData(param, function (data) {
     if (data.status == "success") {
        var change = {};
        change.form_data = data.data[0];
        change.form_data["button_text"] = "UPDATE";
        local.setState(change);
      }
      else {
          alert("Please try again.");
      }
      });
    }

    handleDeleteClick(id,local) {
       var param = {action: 'deleteTraining', training_id: id}
       util.getSetData(param, function (data) {
       if (data.status == "success") {
          alert("Record deleted successfully.");
        }
        else {
            alert("Please try again.");
        }
        });
    }

    Continue()
    {
        var p_id = this.props.params.profileId;
        this.props.changeRoute('/my-accounts/extended-profile/'+ p_id +'/awards');
    }

    render() {
        var updateState = false;
        if(this.state.stateUpdate)
        {
            updateState = true;
            this.state.stateUpdate = false;
        }

        var local = this;
        return (
          <div>
          <section className="inner-page basic-profile">

          <DashboardMenu page="Training" profileId = {this.props.params.profileId}/>

          <div className="pageRest cell">
            <div className="basic-profile-inner">

            {this.state.form_data.result == true &&
               <div className="sucess_ep">{this.state.form_data.resultMsg}</div> }
               {this.state.form_data.result == false &&
                  <div className="error_ep">{this.state.form_data.resultMsg}</div> }

                    <div className="row">
                        <div className="col-sm-6 ">
                            <div className="btn_inline_view">
                                <h1 className="h1_btn">Training</h1>
                            <span className="lightgallery-single-video">
                             <li className="video" data-src="https://www.youtube.com/watch?v=nXnwMfasZEA&feature=youtu.be">
                                 <button type="button" className=" btn video_assist_btn">Video Assist <i className="fa fa-play-circle"></i></button>
                             </li></span>

                            </div>
                        </div>
                        <div className="col-sm-6">
                          <h3>Step 5/14</h3>
                        </div>
                        </div>
                    <div className="row">
                    <div className="col-xs-12 lastCol">
                        <input type="text" placeholder="Name of Institute" value={this.state.form_data.institute_name}
                               onBlur={this.handleChange.bind(this,'institute_name')}
                        onChange={this.handleChange.bind(this,'institute_name')}/>
                        <small className="errorMsg">{this.state.name_error_text}</small>
                        <i className="fa fa-info" data-toggle="tooltip" title="" data-original-title="Name of Institute"></i>
                   </div>
                   <div className="col-xs-12 lastCol">
                        <input type="text" placeholder="Nature of Training" value={this.state.form_data.nature_of_training}
                               onBlur={this.handleChange.bind(this,'nature_of_training')}
                        onChange={this.handleChange.bind(this,'nature_of_training')}/>
                       <small className="errorMsg">{this.state.nature_of_training_error}</small>
                        <i className="fa fa-info" data-toggle="tooltip" title="" data-original-title="Nature of Training"></i>
                   </div>
                   </div>
                  <div className="row">
                   <div className="col-md-4 col-sm-4 col-xs-12 uploadBasicPh">
                     <input id="uploadFile" type="text" placeholder="Verify by Photo" value={this.state.value} />
                       <small className="errorMsg">{this.state.photo_error_text}</small>
                     <div className="fileUpload">
                       <span></span>
                         <input id="uploadBtn" type="file" accept="image/*" className="upload"
                                onChange={this.handleImageChange.bind(this)}/>
                       <i className="fa fa-upload" aria-hidden="true"></i>
                     </div>
                   </div>


                  <div className="col-md-4 col-sm-4 col-xs-12">
                    <input type="text" placeholder="Verify by Video" value={this.state.form_data.education_video}
                           onChange={this.handleChange.bind(this,'education_video')}/>
                      <small className="errorMsg">{this.state.website_error_text}</small>
                  </div>
                  <div className="col-md-4 col-sm-4 col-xs-12 lastCol">
                    <input type="text" placeholder="Verify by Link" value={this.state.form_data.education_link}
                    onChange={this.handleChange.bind(this,'education_link')}/>
                      <small className="errorMsg">{this.state.lwebsite_error_text}</small>
                    <i className="fa fa-info" data-toggle="tooltip" title="" data-original-title="Links"></i>
                  </div>
              </div>
              <div className="row">
                  <div className="col-md-3 col-sm-3 col-xs-12">
                    <label>Duration</label>
                    <input type="number"  min="0"  placeholder="Number of" value={this.state.form_data.number_of_days}
                           onBlur={this.handleChange.bind(this,'number_of_days')}
                    onChange={this.handleChange.bind(this,'number_of_days')}/>
                      <small className="errorMsg">{this.state.dworked_error_text}</small>
                  </div>
                  <div className="col-md-3 col-sm-3 col-xs-12">
                     <label></label>
                      <select value={this.state.form_data.duration_in} onChange={this.handleOptionChange.bind(this,"duration_in")} >>
                        <option value="days" key="days">Days</option>
                        <option value="weeks" key="weeks">Weeks</option>
                        <option value="months" key="months">Months</option>
                        <option value="years" key="years">Years</option>
                      </select>

                 </div>
                 <div className="col-md-3 col-sm-3 col-xs-12">
                   <label>Year of Training</label>
                   <select  value={this.state.form_data.year_of_training} onChange={this.handleOptionChange.bind(this,"year_of_training")} >
                      <option value="">Years</option>
                      {
                        this.state.years.map(c =>
                         <option value={c} key={c}>{c}</option>)
                       }
                   </select>
                     <small className="errorMsg">{this.state.year_error_text}</small>
                 </div>
                 <div className="col-md-3 col-sm-3 col-xs-12 lastCol alignRigh1">
                    <label>	&nbsp;</label>
                   <button className="add_val_btn marginTopBott4" onClick={this.submitData.bind(this)}>{this.state.form_data.button_text}</button>
                 </div>
              </div>

              <div className="row">
                <div className="col-xs-12 lastCol">
                  <div className="spacerLine"></div>
                </div>
              </div>

              <div className="scroller335">
                <div className="row">
                <div className="col-xs-12">
                  {local.state.trainingdata.map(function(object, i){
                      return <ViewEdit key={i} institute={object.institute_name} project_name={object.nature_of_training}
                      year={object.year_of_training + " | "} no_days={object.number_of_days} duration={object.duration_in}
                      hPhoto={object.photourl} hVideo={object.education_video}
                      hLink={object.education_link} onClick={local.handleEditClick.bind(null,object.id_training,local)}
                      onDeleteClick={local.handleDeleteClick.bind(null,object.id_training,local)}/>
                    })}
                </div>
                </div>
              </div>

              <div className="row">
                 <div className="col-sm-12 col-xs-12 alignRigh1">
                  <button onClick={this.Continue.bind(this)} className="btn btn-profile2 big " type="button">Continue <i
                      className="fa fa-chevron-right"></i></button>
                 </div>
              </div>

                <ProgressSlider profileId = {this.props.params.profileId} stateUpdate={updateState}/>
          </div>

        </div>
        </section>
        </div>
          );}
      }

      Training.propTypes = {
          changeRoute: React.PropTypes.func,
      };

      function mapDispatchToProps(dispatch) {
          return {
              changeRoute: (url) => dispatch(push(url)),
          };
      }

      export default connect(null, mapDispatchToProps)(Training);
//export default Training;
