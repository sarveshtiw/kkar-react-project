/*
* HomePage
*
* This is the first thing users see of our App, at the '/' route
*/
import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import { createStructuredSelector } from 'reselect';
import { selectRepos, selectLoading, selectError } from 'containers/App/selectors';
import { selectUsername } from './selectors';
import { changeUsername } from './actions';
import { loadRepos } from '../App/actions';
import RepoListItem from 'containers/RepoListItem';
import $ from 'jquery';
import List from 'components/List';
import ListItem from 'components/ListItem';
import LoadingIndicator from 'components/LoadingIndicator';
import style from '../App/assets/css/stylesheet.css';
import ReactPlayer from 'react-player'
import TextField from 'material-ui/TextField';
import SelectField from 'material-ui/SelectField';
import MenuItem from 'material-ui/MenuItem';
import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
import cookie from 'react-cookie';
const customContentStyle = { width: '100%',  maxWidth: 'none',};
import Img from 'components/Img';
var util = require('utils/request');
import { API_URL } from 'containers/App/constants'


export class HomePage extends React.Component {
/**
 * when initial state username is not null, submit the form to load repos
 */
 constructor(props) {
  super(props);
      this.state = {
          data:[],
          open: false,
          searchbox: '',
          parentCategory:[],
          child:[],
          subchild:[]

      }
  }
  handleOpen = () => {
 this.setState({open: true});
};

handleClose = () => {
 this.setState({open: false});
};
componentDidMount() {

  $('.dropdown-toggle').click(function(){
  $('#search-container').removeClass('active');
  $('li.active').removeClass('active');
  $('.search_othres').removeClass('active');
  });


       $('body').addClass('HomePage');


       if ($('header ul li a').hasClass('sign_in_togg')) {
           $('body').addClass("NotLogin");
       }


  $.ajax({
    url: 'http://kalakar.pro:90/kalakar/api/',
    dataType: 'json',
    type: 'POST',
    cache: false,
    data: {action:'get_child_cat', category:1},
    success: function(response){
      this.setState({
          data: response.data
      })
    }.bind(this),
    error: function(xhr, status, err) {

    }.bind(this)
  });
  $('footer h3').click(function(){
$(this).toggleClass('active');
$(this).next('ul').slideToggle().toggleClass('active');
});

    if($(window).width() > 1199){
      jQuery("#bgVideo").YTPlayer();
      jQuery("#bgVideo").YTPPlay();
    }
    else if($(window).width() > 1199){
      jQuery("#bgVideo").YTPStop()	;
    }

    $(window).bind('resize', function(){
      if($(window).width() > 1199){
        jQuery( "#bgVideo" ).YTPlayer();
        jQuery("#bgVideo").YTPPlay();
      }
      else if($(window).width() > 1199){
        jQuery("#bgVideo").YTPStop();
      }
    });
    this.childCategory();
       jQuery("#homeScroller").owlCarousel({
         rtl:true,
        loop:true,
        autoplayTimeout:3000,
        autoplaySpeed: 1000,
        autoplay:true,
        items : 7,
        itemsDesktop : [1199,4],
        itemsDesktopSmall : [979,3],
        autoplayHoverPause:true,
        responsive:{  0:{items:2},  600:{items:4}, 1000:{items:7} }
    });



}
    childCategory(){
        var formState=this;
        var param = {action: 'get_home_cat'}
        util.getSetData(param, function (data) {
            if (data.status == "success" ){
                formState.setState({
                    parentCategory:data.parent,
                    child:data.child,
                    subchild:data.subChild
                });

                $('.search_keywords > li > a').click(function() {
                if (!$(this).parent().hasClass('active')){
                $('.search_keywords > li').removeClass('active');
                $(this).parent().addClass('active');
                $('#search-container').addClass('active');
                $('.search_othres').addClass('active');
                        }
                        else{
                          $('.search_keywords > li').removeClass('active');
                          $('#search-container').removeClass('active');
                          $('.search_othres').removeClass('active');
                        }
                     });

                     $('.search_keywords h3').click(function(){
                       $(this).toggleClass('active');
                      $(this).next('ul').toggleClass('active');
                     });

                     $('header').click(function(){
                     $('#search-container').removeClass('active');
                     $('li.active').removeClass('active');
                     $('.search_othres').removeClass('active');
                     });
                     $('#logoicon').click(function(){
                     $('#search-container').removeClass('active');
                     $('li.active').removeClass('active');
                     $('.search_othres').removeClass('active');
                     });
                     $('.player').click(function(){
                     $('#search-container').removeClass('active');
                     $('li.active').removeClass('active');
                     $('.search_othres').removeClass('active');
                     });
                     $('footer').click(function(){
                     $('#search-container').removeClass('active');
                     $('li.active').removeClass('active');
                     $('.search_othres').removeClass('active');
                     });
                     $('.MedixaPartaner').click(function(){
                     $('#search-container').removeClass('active');
                     $('li.active').removeClass('active');
                     $('.search_othres').removeClass('active');
                     });
                     $('.search-form input').click(function(){
                     $('#search-container').removeClass('active');
                     $('li.active').removeClass('active');
                     $('.search_othres').removeClass('active');
                     });
                jQuery("#homeScroller").owlCarousel({
                    rtl:true,
                    loop:true,
                    autoplayTimeout:3000,
                    autoplaySpeed: 1000,
                    autoplay:true,
                    items : 7,
                    itemsDesktop : [1199,4],
                    itemsDesktopSmall : [979,3],
                    autoplayHoverPause:true,
                    responsive:{  0:{items:2},  600:{items:4}, 1000:{items:7} }
                });
            }});
    }
/**
 * Changes the route
 *
 * @param  {string} route The route we want to go to
 */
openRoute = (route) => {
  this.props.changeRoute(route);
};
searchUpdated (classnm, e) {
    this.setState({searchbox: e.target.value})
}
/**
 * Changed route to '/features'
 */
openFeaturesPage = () => {
  this.openRoute('/features');
};

openAboutPage = () => {
  this.openRoute('/about');
};

submitdata(value, event) {
if(event.keyCode == 13 || value == 'click'){
var searchstring = this.state.searchbox;
  this.props.changeRoute('/search/'+searchstring);
}
}


render() {
  const actions = [
    <FlatButton
      label="Cancel"
      primary={true}
      onTouchTap={this.handleClose}
    />,
    <FlatButton
      label="Submit"
      primary={true}
      onTouchTap={this.handleClose}
    />
  ];


  return (
    <div>
    <section className="view-port">
    <div className="container-fluid topStrip  hidden-xs">
<div className="navigation2Left">
  <ul><li><a>The Professional Home for India's Artists, Performers and Technicians</a></li></ul>
</div>
<div className="navigation2Right">
  <ul>
    <li><a href="">PROJECTS</a></li>
    <li><a href="">Founders and Partners</a></li>
    <li><a href="">Videos</a></li>
    <li><a href="/testimonials">TESTIMONIALS</a></li>
  </ul>
</div>
</div>
<div id="logoicon"><img src={require('./img/logoIcon.png')} alt="Kakalar "/></div>
<div id="blankupperhn"></div>
    <div id="bgVideo" className="player"
   data-property="{videoURL:'https://youtu.be/imGvN_zdaWE',containment:'#bgVideo',autoPlay:true, mute:true, startAt:0, opacity:1}"> </div>
    <div className="search_con_wrapper">
    <div className="search_con">
    <div id="search-container">
    <p>Search by Keywords, Media, Projects</p>

    <div className="search-form">
      <div>
    <label htmlFor="search_field">
      <input type="text"  title="Search for:" value={this.state.searchbox}  onChange={this.searchUpdated.bind(this,'searchbox')} onKeyDown={this.submitdata.bind(this,'keydown')}   placeholder="Profession, Age, City" className="search-field" id="search_field" />
    </label>
    <input type="submit" value="Search" onClick={this.submitdata.bind(this,'click')} className="search-submit" />
</div>
    <div className="searchFilterDrop">
      <div className="dropdown">
          <button className=" dropdown-toggle" type="button" data-toggle="dropdown">
          <span className="caret"></span></button>
          <ul className="dropdown-menu">
            <li><a href="#">Keywords</a></li>
            <li><a href="#">Media</a></li>
            <li><a href="#">Projects</a></li>
          </ul>
        </div>
      </div>



    </div>
    </div>
    <div className="search_othres active">
    <p>Search by Profession</p>

    <ul className="search_keywords">
        {this.state.parentCategory.map(c =>
    <li  key={c.category_id} className={'kl'+c.category_id}><a href="javascript:void(0)"  data-id={c.category_id} >{c.category_name}</a>
      <div className="search_desc" id={c.category_id}>
          {this.state.child[c.category_id].map(d =>
        <div className="search_dd_cat" key={d.category_id}>
          <h3><a href="javascript:void(0)">{d.category_name}</a> <span className="mobile_back_btn"></span> </h3>
          <ul className="aaa">
              {this.state.subchild[d.category_id].map(L =>
            <li key={L.category_id}><a href={"/search/profession/"+L.category_name} className="subcategory_search" data-id={L.category_id} >{L.category_name}</a></li>
              )}
          </ul></div>
                )}


      </div>

    </li>)}
    </ul>
  </div>
</div>
</div>
</section>
<div className="MediaPartaner">
<h3>Media Partners</h3>
  <div className="MediaPartanerInner">
    <div id="homeScroller">

      <div className="item"><img src={require('./img/optimystix-media.jpg')} alt="optimystix-media"/></div>
      <div className="item"><img src={require('./img/contiloe.jpg')} alt="contiloe"/></div>
      <div className="item"><img src={require('./img/excel-media.jpg')} alt="excel-media"/></div>
      <div className="item"><img src={require('./img/percept-media.jpg')} alt="percept-media"/></div>
      <div className="item"><img src={require('./img/wizfilms.jpg')} alt="wizfilms"/></div>

      <div className="item"><img src={require('./img/cintaa-media.jpg')} alt="cintaa-media"/></div>

      <div className="item"><img src={require('./img/fx-school-media.jpg')} alt="fx-school-media"/></div>
      <div className="item"><img src={require('./img/whistling-woods.jpg')} alt="whistling-woods"/></div>
      <div className="item"><img src={require('./img/red-digital-cinema-media.jpg')} alt="red-digital-cinema"/></div>
      <div className="item"><img src={require('./img/wion-media.jpg')} alt="wion-media"/></div>
    </div>
  </div>
</div>




</div>
  );
}
}

HomePage.propTypes = {
changeRoute: React.PropTypes.func,
loading: React.PropTypes.bool,
error: React.PropTypes.oneOfType([
  React.PropTypes.object,
  React.PropTypes.bool,
]),
repos: React.PropTypes.oneOfType([
  React.PropTypes.array,
  React.PropTypes.bool,
]),
onSubmitForm: React.PropTypes.func,
username: React.PropTypes.string,
onChangeUsername: React.PropTypes.func,
};

function mapDispatchToProps(dispatch) {
return {
  onChangeUsername: (evt) => dispatch(changeUsername(evt.target.value)),
  changeRoute: (url) => dispatch(push(url)),
  onSubmitForm: (evt) => {
    if (evt !== undefined && evt.preventDefault) evt.preventDefault();
    dispatch(loadRepos());
  },

  dispatch,
};
}

const mapStateToProps = createStructuredSelector({
repos: selectRepos(),
username: selectUsername(),
loading: selectLoading(),
error: selectError(),
});

// Wrap the component to inject dispatch and state into it
export default connect(mapStateToProps, mapDispatchToProps)(HomePage);
