/**
 * Created by Neeru on 7/13/2016.
 */
//import React from 'react';
import React, { Component } from 'react';
import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
import {DashboardHeader} from 'components/DashboardHeader_Component';
import {DashboardClassified} from 'components/DashboardClassified_Component';
import {DashboardClassifiedPopUp} from 'components/DashboardClassifiedPopUp_Component';
import {ClassifiedAddEditDialog} from 'components/ClassifiedAddEditDialog_Component'
var base64 = require('base-64');
import cookie from 'react-cookie';
var util = require('utils/request');

export class DashBoardOrders extends React.Component {
    constructor(props) {
        super(props);
        this.state =
        {
            user_id: cookie.load('userId'),
            orders_data: [],
            open: false,
            orderStatus: 0,
            openOrder: false


        }
    }

    componentDidMount() {
        var queryString = this.props.location.query.q;
        if (queryString === undefined) {
            this.setState({orderStatus: 0});
        }
        else {
            this.setState({
                orderStatus: queryString,
                openOrder: true,
            });

        }

        document.title = "My Dashboard | Kalakar";
        var userid = this.state.user_id;
        var formState = this;
        var param = {action: 'orders', user_id: userid}
        util.getSetData(param, function (data) {
            if (data.status == 'success') {
                formState.setState({orders_data: data.data});
            }

            else {
                formState.setState({message: data.data});

            }
        });
    }

    orderdetail(id) {
        window.open('http://kalakar.pro:90/kalakar/order-invoice/?order_id=' + id, 'Ratting', 'width=800,height=600,0,status=0,');
    }

    handleOpen = () => {
        this.setState({open: true});
    };

    handleClose = () => {
        this.setState({open: false});
    };

    handleCloseorder = () => {
        this.setState({openOrder: false});
    };

    render() {
        return (
            <div className="PageMinHeight">
                <DashboardHeader page="Orders"/>

                <div className='container'>
                    <div className='dash_clssifield'>


                        <div className='recent_classified'>
                            <h2>Order Invoice</h2>
                            <p>{this.state.message}</p>
                            <br></br>
                            <ul>
                                <li className='heading'>
                                    <span className='classified_name'>Invoice Name</span>
                                    <span className='classified_date'>Date</span>
                                    <span className='classified_amount'>Amount</span>
                                    <span className='classified_action'></span>
                                </li>
                                {this.state.orders_data.map(c =>

                                        <li key={c.order_id}>
                                            <span className='classified_name'
                                                  data-title='Invoice Name'>{c.category_name}</span>
                                            <span className='classified_date' data-title='Date'>{c.order_date}</span>
                                            <span className='classified_amount' data-title='Amount'>{c.amount}</span>
                 <span className='classified_action' data-title=''>
                 <a className='action_btn modalPopup' href='javascript:void(0)'
                    onClick={this.orderdetail.bind(this, base64.encode(base64.encode(base64.encode(base64.encode(c.order_id)))))}
                    data-size='size-mediam' data-title='Details'>Details</a>
                </span>
                                        </li>
                                )}
                            </ul>
                        </div>


                    </div>
                </div>
                <Dialog className="pay-ads-pop"
                        modal={false}
                        open={this.state.openOrder}
                        onRequestClose={this.handleCloseorder}
                        autoScrollBodyContent={true}>
                    {(this.state.orderStatus == 1) &&

                    <div className="ViewProfileContact">Your order has been canceled
                        <div>
                            <button className="alertOkBtn" onClick={this.handleCloseorder}>Ok</button>
                        </div>
                    </div>}
                    {(this.state.orderStatus == 2) &&

                    <div className="ViewProfileContact">Your order has been success
                        <div>
                            <button className="alertOkBtn" onClick={this.handleCloseorder}>Ok</button>
                        </div>
                    </div>}
                    {(this.state.orderStatus == 3) &&

                    <div className="ViewProfileContact">Your order has been failed
                        <div>
                            <button className="alertOkBtn" onClick={this.handleCloseorder}>Ok</button>
                        </div>
                    </div>}

                    <RaisedButton label="X" primary={true} className="cancelBtnPopup"
                                  onTouchTap={this.handleCloseorder}/>

                </Dialog>

            </div>
        );
    }
}

export default DashBoardOrders;
