/*** Created by vinay on 7/13/2016. */
import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import {DashboardHeader} from 'components/DashboardHeader_Component';
import Img from 'components/Img';
import TextField from 'material-ui/TextField';
import ActionFavorite from 'material-ui/svg-icons/action/favorite';
import ActionFavoriteBorder from 'material-ui/svg-icons/action/favorite-border';
import FontIcon from 'material-ui/FontIcon';
import IconButton from 'material-ui/IconButton';
import ActionGrade from 'material-ui/svg-icons/action/grade';
import {BookmarkList} from 'components/BookmarkList';
import SearchInput, {createFilter} from 'react-search-input';
import cookie from 'react-cookie';
import {DashboardMenu} from 'components/DashboardMenu';
var util = require('utils/request');

export class Bookmark extends React.Component {
    openRoute = (route) => {
        this.props.changeRoute(route);
    };


    constructor(props) {
        super(props);
        this.state =
        {
            user_id: cookie.load('userId'),
            bookmark_list: [],
            searchTerm: '',
            openDialog:false
        }
    }

    componentDidMount() {
       document.title = "My Dashboard | Kalakar";
        var userid = this.state.user_id;
        var formState = this;
        $("[data-toggle='tooltip']").tooltip();
        var param = {action: 'bookmarks_list', user_id: userid}

        util.getSetData(param, function (data) {
            if (data.status == "success") {
                var bookmark_list = data.data;

                formState.setState({
                    bookmark_list: data.data
                })
            } else {
                if(data.message == "No record found.") {
                    formState.setState({
                        bookmark_list: []
                    })
                }
            }
        });
    }

    profileBookmark(profileId,formstate){
          var param = {action: 'bookmark', profile_id: profileId, user_id: cookie.load('userId')}
          util.getSetData(param, function (data) {
              if (data.status == "success") {
                if(data.code == 201){
                  formstate.componentDidMount();
                }
              }
          });
    }

    searchUpdated(term) {
        this.setState({searchTerm: term})
    }

    render() {
        const formstate = this;
        const filteredBookmarks = this.state.bookmark_list.filter(createFilter(this.state.searchTerm, ['full_name', 'categoryname', 'city_name']));
        return (
            <div className="PageMinHeight">
                <DashboardHeader page="Bookmark"/>


                <div className="container">
                    <div className="dashBookmark">
                        <div className="row">
                            <div className="col-sm-6">
                                <div className="search_bookmark">
                                    <label>Search Bookmark</label>
                                    <SearchInput className="search-input" className="SearchPgInputTxt"
                                                 placeholder="eg: Name Profession, Tags, City"
                                                 onChange={this.searchUpdated.bind(this)}/>
                                    <a href="#" className="tooltip2" data-toggle="tooltip" data-placement="top" title=""
                                       data-original-title="Search Bookmark" aria-describedby="tooltip748746"><Img
                                        src={require('./img/icon-tooltip.png')} alt="kalakar"/></a>
                                    <IconButton className="submit_book"></IconButton>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <div>
                    <div className="results">
                        <div className="container">
                            <div className="row">
                                <div className="col-xs-12 search_result_out">
                                    <ul>
                                        {filteredBookmarks.map(function (obj, i) {
                                            return <BookmarkList key={i} formstate = {formstate}
                                            bookmark={obj} profile_id={obj.profile_id} profileBookmark={formstate.profileBookmark} />
                                        })}
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
Bookmark.propTypes = {
    changeRoute: React.PropTypes.func,
};

function mapDispatchToProps(dispatch) {
    return {
        changeRoute: (url) => dispatch(push(url)),
    };
}

export default connect(null, mapDispatchToProps)(Bookmark);
