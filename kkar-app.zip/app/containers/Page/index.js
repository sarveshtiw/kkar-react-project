import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import { API_URL } from 'containers/App/constants'


export class Page extends React.Component {
  constructor(props) {
      super(props);
      this.state = {pageTitle:'', pageContent:'',
        Loader:true,
      }
    }
    componentDidMount(){
      var currentRoutes = this.props.location.pathname;
      var arr = currentRoutes.split('/page/');
      var pageTitle = decodeURIComponent(arr[1]);
      document.title = pageTitle  + " | Kalakar";
        var param = {action: 'getPage', pageTitle: pageTitle};
        var formState = this;
        $.ajax({
            url: API_URL,
            type: "POST",
            dataType: 'json',
            data: param,
            success: function (data) {
                formState.setState({
                    pageTitle:data.data.title,
                    pageContent:data.data.content,
                    Loader:false
                });
            }.bind(this)

        });

    }
    openRoute = (route) => {
        this.props.changeRoute(route);
    };


    render() {
        return (
            <div className="inner-page testimonialPage" style={{'minHeight':'400px'}}>
{(this.state.Loader===true)?<div className="bigLoader"> <i><img src='http://kalakar.pro:90/kalakar/demo/other/assets/img/loader.svg'/></i></div>: ''}
                <div className="container cinta"  >

                                <article className="article"  >
                                        <h1>{this.state.pageTitle}</h1>

                                    <div className="entry-content" dangerouslySetInnerHTML={{__html: this.state.pageContent}}>

                                    </div>
                                </article>
                            </div>
                </div>

        )
    }
}
Page.propTypes = {
    changeRoute: React.PropTypes.func,
};

function mapDispatchToProps(dispatch) {
    return {
        changeRoute: (url) => dispatch(push(url)),
    };
}

export default connect(null,
    mapDispatchToProps)(Page);
