import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import Button from 'components/Button';
import Dialog from 'material-ui/Dialog';
import RaisedButton from 'material-ui/RaisedButton';
import cookie from 'react-cookie';
var util = require('utils/request');

export class verification extends React.Component {
    constructor(props) {
        super(props);
        this.state ={userId : cookie.load('userId'),
            Code : cookie.load('code'),
            open:false, OTPINI:'',
            resend_otp:'', otpverifiedmsg:'', resetsucess:'', resetinuse:'',
            resetfailure:'',reset:'', newphone: '',resendsucess:'',resendfail:''}}
    /**
     * Changes the route
     *
     * @param  {string} route The route we want to go to
     */
    componentDidMount() {
        if(this.state.Code===202  ){
            this.setState({open:true});
        } else if(this.state.Code===203){
            this.setState({open:false, otpverifiedmsg:"Your phone number has been already verified, Please verify your Email ID(Please check your promotions and spam folder as well).",
                reset:1});
        }
        else {
            this.setState({open:false, otpverifiedmsg:"Your phone number and email have been already verified.",
                reset:1});
        }
    }
    openRoute = (route) => {
        this.props.changeRoute(route);
    };
    /**
     * Changed route to '/'
     */
    openHomePage = () => {
        this.openRoute('/');
    };
    handleClose = () => {
        this.setState({open: false});
    };
    handleOpen = () => {
        this.setState({open: true});
    };
    changeehandler(value, e){
        if(value=='newphone'){
            this.setState({newphone : e.target.value});
        }
        else {
            this.setState({OTPINI : e.target.value});
        }
    }
    verifyOTP(){
        var local = this;
        var userid = this.state.userId;
        var OTPINI = this.state.OTPINI;
        var param = {action:'otp_verification', user_id: userid, mobile_otp:OTPINI}
        util.getSetData(param, function (data) {
            if(data.status == "success"){
                local.setState({otpverifiedmsg:data.message, reset:1,
                    resendsucess:''});
                var param = {action: 'get_basic_profile', user_id: userid};
                util.getSetData(param, function (data) {

                    if (data.status == "success") {
                        cookie.save('code', data.code, {path:'/'});
                        local.setState({Code: data.code});
                    }
                });
            }
            else{
                local.setState({otpverifiedmsg:data.message});
            }
        });
    }
    resetphone(){
        this.setState({reset:'open'})
    }
    resendOTP(){
        var local = this;
        var userid = this.state.userId;
        var newphone = this.state.newphone;
        var param = {action:'resent_otp', user_id: userid, new_ph:newphone}
        util.getSetData(param, function (data) {
            local.setState({resetinuse: '', reset:1, resetsucess: ''});
            if(data.status == "success"){
                local.setState({resetsucess: data.message, });
            }
            else{
                local.setState({resetinuse: data.message});
            }

        });
    }
    resendemail(){
        var formState=this;
        var param = {action:'resendEmail',userID:this.state.userId}
        util.getSetData(param, function (data) {
            if(data.status == "success"){
                formState.setState({
                    emailMessage:data.message
                })
            }})
    }
    resendmsg(){
        var newphone = cookie.load('mobile')
        var local = this;
        var userid = this.state.userId;
        var param = {action:'resent_otp', user_id: userid, new_ph:newphone}
        util.getSetData(param, function (data) {
            local.setState({resetinuse: '', resetsucess: ''});
            if(data.status == "success"){
                local.setState({resendsucess: "OTP has been sent"});
            }
            else{
                local.setState({resendfail: "OTP not successfully sent. Please try later."});
            }

        });
    }
    handleCancelClick(){
        this.setState({reset:''});
    }
    render() {

        return (

            <section className="inner_page">

                <Dialog
                    className="pay-ads-pop"
                    modal={false}  open={this.state.open} autoScrollBodyContent={true}>
                    <div className="pay_ads_con">
                        <h2>Thank you</h2>
                        <p>Thank you for signing up with Kalakar.pro, Please check your email inbox for the confirmation,
                            And your Phone messages for your OTP verification!</p>
                        <RaisedButton className="cancelBtnPopup" onTouchTap={this.handleClose} primary={true} label="X"/>
                    </div>
                </Dialog>
                <div className="container">
                    <div className="row">
                        <div className="col-xs-12">
                            <div className="varification_main">
                                <div className="varification_con">
                                    <div className="entry-header">
                                        <h1 className="entry-title">Verification</h1>
                                    </div>
                                    <div className="entry-content">
                                        <p>{this.state.otpverifiedmsg}</p>
                                        {this.state.Code == 203  && <div>
                                            <input type="button" alt="Resend"  value="Resend Email" className="resend_otp" onClick={this.resendemail.bind(this)}/>
                                            <br></br>&nbsp;
                                            <div className="GreenText"> {this.state.emailMessage} </div>
                                        </div>}

                                        {(this.state.reset =='')?<div id="done">
                                            <p>You have used <span>{cookie.load('mobile')}</span> for your OTP verification.</p>
                                            <p>If you have entered a wrong phone number please <a href="javascript:void(0)" onClick={this.resetphone.bind(this)}>Click Here</a></p>
                                            <p>To resend OTP to <span>{cookie.load('mobile')}</span> <a href="javascript:void(0)" onClick={this.resendmsg.bind(this)}>Click Here</a></p>
                                        </div>:''}
                                        {(this.state.resendfail!=='') ? <div className="RedText"> {(this.state.resendfail!=='') ?  this.state.resendfail : ''} </div>:''}
                                        {(this.state.resendsucess!=='') ? <div className="GreenText"> {(this.state.resendsucess!=='') ?  this.state.resendsucess : ''} </div>:''}
                                        {(this.state.resetsucess!=='') ? <div className="GreenText"> {(this.state.resetsucess!=='') ?  this.state.resetsucess : ''} </div>:''}
                                        {(this.state.resetinuse!=='') ? <div className="RedText"> {(this.state.resetinuse!=='') ?  this.state.resetinuse : ''} </div>:''}
                                        <div className="mobile_verication_form">
                                            {(this.state.reset =='')?  <span id="resend_phone1">
                  <label htmlFor="mobile_otp">OTP Code*</label>
                    <input value={this.state.OTPINI} onChange={this.changeehandler.bind(this,'OTPINI')} type="text" placeholder="Please enter six digit otp code" className="required " />
                </span>:''}

                                            {(this.state.reset !=='' && this.state.reset !== 1)?<span id="resend_phone">
                    <label for="mobile_otp">Re-enter Phone*</label>
                    <input  type="text" value={this.state.newphone} onChange={this.changeehandler.bind(this,'newphone')} placeholder="Please enter your valid phone number"  className="required " />
                </span>:''}
                                        </div>

                                        <div className="submit_btns">

                                            {(this.state.reset!==''  && this.state.reset !== 1) ?<input type="button" alt="Resend"  value="Cancel" className="resend_otp" onClick={this.handleCancelClick.bind(this)}/>:''}&nbsp;
                                            {(this.state.reset!==''  && this.state.reset !== 1) ?<input type="button" alt="Resend"  value="Resend OTP" className="resend_otp" onClick={this.resendOTP.bind(this)} />:''}
                                            {(this.state.reset =='') ?<input type="submit" alt="submit" value="Verify" className="" onClick={this.verifyOTP.bind(this)} />:''}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </section>

        );
    }
}

verification.propTypes = {
    changeRoute: React.PropTypes.func,
};

function mapDispatchToProps(dispatch) {
    return {
        changeRoute: (url) => dispatch(push(url)),
    };
}

export default connect(null, mapDispatchToProps)(verification);