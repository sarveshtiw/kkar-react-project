import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import {DashboardHeader} from 'components/DashboardHeader_Component';
import {DashboardMenu} from 'components/DashboardMenu';
import TextField from 'material-ui/TextField';
import SelectField from 'material-ui/SelectField';
import Checkbox from 'material-ui/Checkbox';
import {RadioButton, RadioButtonGroup} from 'material-ui/RadioButton';
import {ProgressSlider} from 'components/ProgressSlider';
var util = require('utils/request');
import cookie from 'react-cookie';


export class DashboardContactdetails extends React.Component {

    openRoute = (route) => {
        this.props.changeRoute(route);
    };

    constructor(props) {
        super(props);
        this.state = {
            stateUpdate:false,
            user_id:cookie.load('userId'),
            contact_data: {
                "user_phone": "",
                "user_email": "",
                "agent_phone": "",
                "agent_email": "",
                "my_website": "",
                "phone_visibility_to": "",
                "email_visibility_to": "",
                "agent_phone_visibility_to": "",
                "agent_email_visibility_to": ""

            }
        }

    }

    componentDidMount() {
      document.title = "Extended Profile | Kalakar";
        $("[data-toggle='tooltip']").tooltip();
        var userid = this.state.user_id;

        var param = {action: 'get_intro_profile', user_id: userid, profile_id: this.props.params.profileId}
        var formState = this;
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                var contactdata = data.data;
                formState.setState({
                    contact_data: {
                        user_phone: contactdata.user_phone,
                        user_email: contactdata.user_email,
                        agent_phone: contactdata.agent_phone,
                        agent_email: contactdata.agent_email,
                        my_website: contactdata.my_website,
                        phone_visibility_to: contactdata.phone_visibility_to,
                        email_visibility_to: contactdata.email_visibility_to,
                        agent_phone_visibility_to: contactdata.agent_phone_visibility_to,
                        agent_email_visibility_to: contactdata.agent_email_visibility_to
                    }
                })
            }

        });

            jQuery('#lightgallery').lightGallery();
            jQuery('.lightgallery-single-image').lightGallery();
            jQuery('.lightgallery-single-video').lightGallery();


    }

    handleInputChange(name, e) {
        var change = {};
        change.contact_data = this.state.contact_data;
        change.contact_data[name] = e.target.value;
        this.setState(change);
    }
    handleChangeradio1(name, e) {
        var change = {};
        change.contact_data = this.state.contact_data;
        change.contact_data[name] =  e.target.value;
        this.setState(change);
    }


    submitContact(e){
        e.preventDefault();
        if(!(this.isDisabled()  && this.isDisabledWebsite()  && this.isDisabledphone()  &&
            this.isDisabledphone1() && this.isDisabled1()  )) {
            this.isDisabled();
            this.isDisabledWebsite();
            this.isDisabledphone();
            this.isDisabledphone1();
            this.isDisabled1();
            return;
        }
        var p_id = this.props.params.profileId;
        var userid = this.state.user_id;
        this.state.contact_data.action = 'set_extended_intro';
        this.state.contact_data.user_id = userid;
        this.state.contact_data.profile_id = p_id;
        var param =  this.state.contact_data;
        var formState = this;
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                formState.state.stateUpdate = true;
               formState.props.changeRoute('/my-accounts/extended-profile/'+ p_id +'/intro');
            }

        })

    }

    validateEmail (value) {
        // regex from http://stackoverflow.com/questions/46155/validate-email-address-in-javascript
        var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(value);
    }
    isDisabled() {
        let emailIsValid = false;
        if (this.state.contact_data.user_email == null || this.state.contact_data.user_email === "") {
            this.setState({
                email_error_text: "Required"
            });
        } else {
            if (this.validateEmail(this.state.contact_data.user_email)) {
                emailIsValid = true
                this.setState({
                    email_error_text: null
                });
            } else {
                this.setState({
                    email_error_text: "Sorry, this is not a valid email"
                });
            } return emailIsValid;
        }}
    validateWebsite(value){
        var exp =/^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/
        return exp.test(value);
    }
    isDisabledWebsite() {
        let urlIsValid = false;

        if (this.state.contact_data.my_website== null || this.state.contact_data.my_website === "") {
            urlIsValid=true;
            this.setState({
                website_error_text: null
            });
        } else {

            if (this.validateWebsite(this.state.contact_data.my_website)) {
                urlIsValid = true;
                this.setState({
                    website_error_text: null
                });
            }
            else {
                this.setState({
                    website_error_text: "Sorry, this is not a valid format"
                });
            }

        }
        return urlIsValid;
    }
    validatePhone(value) {
        var reg = /^(?:(?:\+|0{0,2})91(\s*[\ -]\s*)?|[0]?)?[789]\d{9}|(\d[ -]?){10}\d$/;
        return reg.test(value);
    }
    isDisabledphone() {
        let phoneIsValid = false;

        if (this.state.contact_data.user_phone == null ||this.state.contact_data.user_phone === "") {
            this.setState({
                phone_error_text: "Required"
            });
        } else {
            if (this.validatePhone(this.state.contact_data.user_phone)) {
                phoneIsValid = true
                this.setState({
                    phone_error_text: null
                });
            } else {
                this.setState({
                    phone_error_text: "Sorry, this is not a valid format"
                });
            }

        }
        return phoneIsValid;
    }
    isDisabledphone1() {
        let phoneIsValid = false;
        if (this.state.contact_data.agent_phone==null || this.state.contact_data.agent_phone == "") {

            this.setState({
                aphone_error_text: null
            });
            return true;
        } else {
            if (this.validatePhone(this.state.contact_data.agent_phone)) {
                phoneIsValid = true
                this.setState({
                    aphone_error_text: null
                });
            } else {
                this.setState({
                    aphone_error_text: "Sorry, this is not a valid format"
                });
            }

        }
        return phoneIsValid;
    }
    isDisabled1() {
        let emailIsValid = false;
        if (this.state.contact_data.agent_email==null || this.state.contact_data.agent_email === '') {
            this.setState({
                aemail_error_text: null
            });
            return true;
        } else {
            if (this.validateEmail(this.state.contact_data.agent_email)) {
                emailIsValid = true
                this.setState({
                    aemail_error_text: null
                });
            } else {
                this.setState({
                    aemail_error_text: "Sorry, this is not a valid email"
                });
            }

        }
        return emailIsValid;
    }
    render() {
        var updateState = false;
        if(this.state.stateUpdate)
        {
            updateState = true;
            this.state.stateUpdate = false;
        }
        return (
            <div>
                <section className="inner-page basic-profile">
                    <DashboardMenu page="ContactDetails" profileId = {this.props.params.profileId}/>

                    <div className="pageRest cell">
                        <div className="basic-profile-inner contactDetail">
                            <form onSubmit={this.submitContact.bind(this)}>
                                <div className="row">
                                    <div className="btn_inline_view">
                                        <h1 className="h1_btn">Contact Details</h1>
                            <span className="lightgallery-single-video">
                             <li className="video" data-src="https://www.youtube.com/watch?v=j2nbx7Hpzgg&feature=youtu.be">
                                 <button type="button" className=" btn video_assist_btn">Video Assist <i className="fa fa-play-circle"></i></button>
                             </li></span>

                                    </div>
                                    <div className="col-sm-6">
                                        <h3>Step 2/14</h3>
                                    </div>

                                </div>

                                <div className="minBox">

                                    <div className="row">
                                        <div className="col-lg-4 col-md-5 col-sm-6 col-xs-12">
                                            <label>My Phone Number</label>
                                            <TextField
                                                id="text-field1"
                                                className="ContactDetInputTxt"
                                                hintText="e.g.9999999999"
                                                type="tel"
                                                floatingLabelFixed={false}
                                                fullWidth={true}
                                                errorText={this.state.phone_error_text}
                                                onBlur={this.isDisabledphone.bind(this,'user_phone')}
                                                value={this.state.contact_data.user_phone}
                                                onChange={this.handleInputChange.bind(this,'user_phone')}
                                                />


                                        </div>
                                        <div className="col-lg-4 col-md-5 col-xs-12 lastCol">
                                            <label>My Email ID</label>

                                            <TextField
                                                id="text-field1"
                                                hintText=" xyz@gmail.com"
                                                className="ContactDetInputTxt"
                                                floatingLabelFixed={false}
                                                fullWidth={true}
                                                errorText={this.state.email_error_text}
                                                onBlur={this.isDisabled.bind(this,'user_email')}
                                                value={this.state.contact_data.user_email}
                                                onChange={this.handleInputChange.bind(this,'user_email')}
                                                />


                                            <i className="fa fa-info" data-toggle="tooltip" title="EmailId"></i>
                                        </div>
                                    </div>

                                    <div className="row">
                                        <div className="col-lg-4 col-md-5 col-sm-6 col-xs-12">
                                            <label>Show Phone Detail to</label>
                                            <RadioButtonGroup name="shipSpeed" defaultSelected="not_light"
                                                              onChange={this.handleChangeradio1.bind(this,'phone_visibility_to')}
                                                              valueSelected={this.state.contact_data.phone_visibility_to}>
                                                <RadioButton value="public" label="Everyone"
                                                             className="ContactproRadio"/>
                                                           <RadioButton value="none" label="None"
                                                             className="ContactproRadio"/>
                                                <RadioButton value="register_users" label="Members"
                                                             className="ContactproRadio"/>
                                            </RadioButtonGroup>



                                        </div>
                                        <div className="col-lg-4 col-md-5 col-sm-6 col-xs-12">
                                            <label>Allow Email Access to</label>
                                            <RadioButtonGroup name="shipSpeed" defaultSelected="not_light"
                                                              onChange={this.handleChangeradio1.bind(this,'email_visibility_to')}
                                                              valueSelected={this.state.contact_data.email_visibility_to}>
                                                <RadioButton value="public" label="Everyone"
                                                             className="ContactproRadio"/>
                                                <RadioButton value="none" label="None"
                                                             className="ContactproRadio"/>
                                                <RadioButton value="register_users" label="Members"
                                                             className="ContactproRadio"/>
                                            </RadioButtonGroup>



                                        </div>
                                    </div>

                                    <div className="spacer"></div>

                                    <div className="row">
                                        <div className="col-lg-4 col-md-5 col-sm-6 col-xs-12">
                                            <label>Agent's Phone Number</label>

                                            <TextField
                                                id="text-field1"
                                                hintText="e.g.9999999999"
                                                className="ContactDetInputTxt"
                                                floatingLabelFixed={false}
                                                fullWidth={true}
                                                errorText={this.state.aphone_error_text}
                                                onBlur={this.isDisabledphone1.bind(this,'agent_phone')}
                                                value={this.state.contact_data.agent_phone}
                                                onChange={this.handleInputChange.bind(this,'agent_phone')}
                                                />

                                        </div>
                                        <div className="col-md-4 col-sm-6 col-xs-12 lastCol">
                                            <label>Agent's My Email ID</label>

                                            <TextField
                                                id="text-field1"
                                                hintText="xyz@gmail.com"
                                                className="ContactDetInputTxt"
                                                floatingLabelFixed={false}
                                                fullWidth={true}
                                                errorText={this.state.aemail_error_text}
                                                onBlur={this.isDisabled1.bind(this,'agent_email')}
                                                value={this.state.contact_data.agent_email}
                                                onChange={this.handleInputChange.bind(this,'agent_email')}
                                                />
                                            <i className="fa fa-info" data-toggle="tooltip" title="Agent EmailId"></i>
                                        </div>
                                    </div>

                                    <div className="row">
                                        <div className="col-lg-4 col-md-5 col-sm-6 col-xs-12">
                                            <label>Show Phone Detail to</label>
                                            <RadioButtonGroup name="shipSpeed" defaultSelected="not_light"
                                                              onChange={this.handleChangeradio1.bind(this,'agent_phone_visibility_to')}
                                                              valueSelected={this.state.contact_data.agent_phone_visibility_to}>
                                                <RadioButton value="public" label="Everyone"
                                                             className="ContactproRadio"/>
                                                <RadioButton value="none" label="None"
                                                             className="ContactproRadio"/>
                                                <RadioButton value="register_users" label="Members"
                                                             className="ContactproRadio"/>
                                            </RadioButtonGroup>


                                        </div>
                                        <div className="col-lg-4 col-md-5 col-sm-6 col-xs-12">
                                            <label>Allow Email Access to</label>
                                            <RadioButtonGroup name="shipSpeed" defaultSelected="not_light"
                                                              onChange={this.handleChangeradio1.bind(this,'agent_email_visibility_to')}
                                                              valueSelected={this.state.contact_data.agent_email_visibility_to}>
                                                <RadioButton value="public" label="Everyone"
                                                             className="ContactproRadio"/>
                                                <RadioButton value="none" label="None"
                                                             className="ContactproRadio"/>
                                                <RadioButton value="register_users" label="Members"
                                                             className="ContactproRadio"/>
                                            </RadioButtonGroup>

                                        </div>
                                    </div>


                                    <div className="spacer"></div>
                                    <div className="row">

                                        <div className="col-lg-8 col-md-10 col-sm-8 col-xs-12 lastCol">
                                            <label>My Website</label>

                                            <TextField
                                                id="text-field1"
                                                hintText="Enter your website url"
                                                className="ContactDetInputTxt"
                                                floatingLabelFixed={false}
                                                fullWidth={true}
                                                errorText={this.state.website_error_text}
                                                onBlur={this.isDisabledWebsite.bind(this,'my_website')}
                                                value={this.state.contact_data.my_website}
                                                onChange={this.handleInputChange.bind(this,'my_website')}
                                                />

                                            <i className="fa fa-info" data-toggle="tooltip" title="Your Website"></i>
                                        </div>
                                    </div>

                                </div>

                                <div className="row">
                                    <div className="col-sm-12 col-xs-12 alignRigh1">

                                        <button  className="btn btn-profile2 big noMargin">Continue <i
                                            className="fa fa-chevron-right"></i></button>
                                    </div>
                                </div>


                                <ProgressSlider profileId = {this.props.params.profileId} stateUpdate={updateState}/>
                            </form>
                        </div>

                    </div>
                </section>
            </div>
        );
    }
}

DashboardContactdetails.propTypes = {
    changeRoute: React.PropTypes.func,
};

function mapDispatchToProps(dispatch) {
    return {
        changeRoute: (url) => dispatch(push(url)),
    };
}

export default connect(null,
    mapDispatchToProps)(DashboardContactdetails);
