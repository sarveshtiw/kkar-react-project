import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import {DashboardMenu} from 'components/DashboardMenu';
import {DialogConfirm} from 'components/TagDelete';
import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
import {ProgressSlider} from 'components/ProgressSlider';

var util = require('utils/request');
var ProgressStyle = {
    width: '70%'
};

export class Tags extends React.Component {

    openRoute = (route) => {
        this.props.changeRoute(route);
    };

    constructor(props) {
        super(props);
        this.state = {
            stateUpdate : false,
            confirmOpen: false,
            tagdata: [],
            form_data: {
                id_tags: '',
                profile_id: '',
                tags: ''
            }
        }
    }

    handleOpen(tid, formState) {
        formState.setState({dtid: tid, confirmOpen: true});
    }

;

    handleClose = () => {
        this.setState({confirmOpen: false});
    };

    handleInputChange(name, e) {
        var change = {};
        change.form_data = this.state.form_data;
        change.form_data[name] = e.target.value;
        this.setState(change);
        if (name == 'tags') {
            this.validate1();
        }
    }


    componentDidMount() {
      document.title = "Extended Profile | Kalakar";
        var param = {action: 'tags_list', profile_id: this.props.params.profileId}
        var formState = this;
        util.getSetData(param, function (data) {

            if (data.status == "success") {
                formState.setState({
                    tagdata: data.data
                })
            }
        });
        jQuery('#lightgallery').lightGallery();
        jQuery('.lightgallery-single-image').lightGallery();
        jQuery('.lightgallery-single-video').lightGallery();
    }

    validate1() {
        let valid = false;
        if (this.state.form_data.tags == "") {
            this.setState({
                error_text: "Required"
            });
        } else {
            valid = true
            this.setState({
                error_text: null
            })

        }
        return valid;
    }

    delete(formState) {
        var param = {action: 'tags_delete', profile_id: formState.props.params.profileId, tag_id: formState.state.dtid}
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                formState.state.stateUpdate = true;
                formState.handleClose();
                var param = {action: 'tags_list', profile_id: formState.props.params.profileId}
                util.getSetData(param, function (data) {
                    if (data.status == "success") {
                        formState.setState({
                            tagdata: data.data
                        })
                    }
                    else {
                        formState.setState({
                            tagdata: []
                        })
                    }
                });
            }
            else {
                alert("Please try again.");
            }
        });
    }

    submitTags(e) {
        e.preventDefault();
        if (!(this.validate1())) {
            return
        }
        var formState = this;
        this.state.form_data.action = 'tag';
        this.state.form_data.profile_id = this.props.params.profileId;
        var param = this.state.form_data;
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                 formState.state.stateUpdate = true;
                var param = {action: 'tags_list', profile_id: formState.props.params.profileId}
                util.getSetData(param, function (data) {
                    if (data.status == "success") {
                        formState.setState({
                            tagdata: data.data,
                            form_data: {
                                tags: ''
                            }

                        })
                    }
                });

            }
            
        });

    }

    Continue() {
        var p_id = this.props.params.profileId;
        this.props.changeRoute('/my-accounts/extended-profile/' + p_id + '/circle');
    }

    render() {
        var updateState = false;
        if(this.state.stateUpdate)
        {
            updateState = true;
            this.state.stateUpdate = false;
        }
        var local = this;
        return (<section className="inner-page basic-profile">

                <DashboardMenu page="Tags" profileId={this.props.params.profileId}/>

                <div className="pageRest cell">
                    <div className="basic-profile-inner">
                        <form onSubmit={this.submitTags.bind(this)}>

                            <div className="row">
                                <div className="col-sm-6 ">
                                    <div className="btn_inline_view">
                                        <h1 className="h1_btn">Tags</h1>
                            <span className="lightgallery-single-video">
                             <li className="video" data-src="https://www.youtube.com/watch?v=X_0IAHeDky0&feature=youtu.be">
                                 <button type="button" className=" btn video_assist_btn">Video Assist <i className="fa fa-play-circle"></i></button>
                             </li></span>

                                    </div>
                                </div>
                                <div className="col-sm-6">
                                    <h3>Step 8/14</h3>
                                </div>
                                <div className="col-xs-12"><p className="video_assist_subtitle">Add your tags</p></div>
                            </div>

                            <div className="row">
                                <div className="col-xs-12">
                                    <div className="tagInput">
                                        <input type="text" placeholder="Add your tags"
                                               value={this.state.form_data.tags}
                                               onChange={this.handleInputChange.bind(this,'tags')}/>
                                        <small className="errorMsg">{this.state.error_text}</small>
                                        <span className="glyphicon glyphicon-plus" aria-hidden="true"></span>
                                    </div>
                                </div>
                            </div>

                            <div className="row">
                                <div className="col-md-8 col-xs-8">
                                    <div className="tagsItems marginTopBott4">
                                        <ul>
                                            {this.state.tagdata.map(t =>
                                                    <li key={t.id_tags}>
                                                        {t.tags}
                                                        <button type="button"
                                                                onTouchTap={local.handleOpen.bind(null,t.id_tags,local)}>
                                                            x
                                                        </button>
                                                    </li>
                                            )}
                                        </ul>
                                        <DialogConfirm open={local.state.confirmOpen} title="Delete Tag"
                                                       body="Do you really want to delete?"
                                                       onSubmit={local.delete.bind(null,local)}
                                                       onClose={local.handleClose}/>
                                    </div>
                                </div>

                                <div className="col-md-4 col-xs-4 alignRigh1">
                                    <button className="add_val_btn marginTopBott4">ADD</button>
                                </div>
                            </div>


                            <div className="row">
                                <div className="col-sm-12 col-xs-12 alignRigh1">
                                    <button onClick={this.Continue.bind(this)} className="btn btn-profile2 big ">
                                        Continue <i
                                        className="fa fa-chevron-right"></i></button>
                                </div>
                            </div>

                            <ProgressSlider profileId = {local.props.params.profileId} stateUpdate={updateState}/>
                        </form>
                    </div>

                </div>

            </section>
        )
    }
}
Tags.propTypes = {
    changeRoute: React.PropTypes.func,
};

function mapDispatchToProps(dispatch) {
    return {
        changeRoute: (url) => dispatch(push(url)),
    };
}

export default connect(null,
    mapDispatchToProps)(Tags);
