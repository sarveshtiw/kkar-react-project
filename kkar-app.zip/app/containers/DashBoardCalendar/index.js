import React from 'react';

var util = require('utils/request');
import cookie from 'react-cookie';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import {DashboardHeader} from 'components/DashboardHeader_Component';

export class DashBoardCalendar extends React.Component {

    openRoute = (route) => {
        this.props.changeRoute(route);
    };

    constructor(props) {
        super(props);
        this.state = {
           profileData : [],
           selectedProfileId : 0
        };
    }

    componentDidMount() {
       document.title = "My Dashboard | Kalakar";
      var profileParam = {action: 'profilesList', user_id: cookie.load('userId')}
      var formState = this;
      util.getSetData(profileParam, function (data) {
          if (data.status == "success") {
              formState.setState({
                  profileData : data.data
              })
          }
          else {
              console.log(data);
          }

      });

      var param = {action: 'getCalendar',user_id: cookie.load('userId')}
      this.showEventsInCalender(param);
    }

    profileClick(profileID){
      $('#calendar').fullCalendar('destroy');
      var param = {action: 'calendar', profile_id: profileID, user_id: cookie.load('userId'), type: 'fetch'}
      this.showEventsInCalender(param);
    }

    showEventsInCalender(param){
         var formState = this;
         var events = [];
          util.getSetData(param, function (data) {
                formState.setState({selectedProfileId : param.profile_id});
                  if (data.data != null) {
                      for (var i = 0; i < data.data.length; i++) {
                          var event = {};
                          event["id"] = data.data[i].id;
                          event["title"] = data.data[i].title;
                          event["start"] = data.data[i].startdate;
                          event["end"] = data.data[i].enddate;
                          events.push(event);
                        }
                      }
                       jQuery('#calendar').fullCalendar({
                            events: events,
                            eventRender: function(event, element, view) {
                               var dataToFind = moment(event.start).format('YYYY-MM-DD');
                              // $("td.fc-day-number[data-date='"+dataToFind+"']").html('');
                            //   $("td.fc-day-number[data-date='"+dataToFind+"']").append("<a href='javascript:void(0)' class='fc-event'>"+new Date(dataToFind).getDate()+"</a>");
                             },
                             dayClick: function (date) {
                                 var currDate = moment(new Date()).format("YYYY-MM-DD");
                                if(date.format() < currDate) {
                                  return;
                                }

                                var events = $('#calendar').fullCalendar('clientEvents');
                                var flag = false;
                                for (var i = 0; i < events.length; i++) {
                                    if (moment(date).isSame(moment(events[i].start)))
                                    {
                                        flag = true;
                                        formState.setCalenderEvent(date.format(),events[i].id);
                                        // var dataToFind = moment(events[i].start).format('YYYY-MM-DD');
                                        // var dd = moment(events[i].start).format('D');
                                        // $("td.fc-day-number[data-date='"+dataToFind+"']").html('' + dd);
                                        // $('#calendar').fullCalendar('removeEvents',events[i].id);
                                        break;
                                    }
                                }
                                if (!flag)
                                {
                                  formState.setCalenderEvent(date.format(),0);
                                }
                            }
                         });
          });

      }


       setCalenderEvent(startDate,id){
         if(this.state.selectedProfileId == 0 || this.state.selectedProfileId == undefined){
           alert("Please select Profile first.");
           return;
         }
         var param = {action: 'calendar', profile_id: this.state.selectedProfileId, user_id: cookie.load('userId'), type: 'new', startdate: startDate }
         util.getSetData(param, function (data) {
             if (data.status == "success") {
                 if(data.eventid != undefined){
                    var event = {};
                    event["id"] = data.eventid;
                    event["title"] = "Not available";
                    event["start"] = startDate;
                    event["end"] = startDate;
                    $("#calendar").fullCalendar('renderEvent', event, true);
                    alert(data.message);
                }
                else {
                    var dataToFind = moment(startDate).format('YYYY-MM-DD');
                    var dd = moment(startDate).format('D');
                    $('#calendar').fullCalendar('removeEvents',id);
                    alert(data.message);
                }
             }
             else {
                alert(data.message);
             }
         });
       }

    render(){
      return(
        <div className="PageMinHeight">
        <DashboardHeader page="Calendar" />
        <div className="container">
              <div className="dashMsg">
                          <div className="row">
                            <div className="col-sm-12">
                              <div className="filterMsgOuter">
                                <ul className="filterMsg">
                                {this.state.profileData.map(ph =>
                                  <li key={ph.profile_id} className="theatreColor"><a href="javascript:void(0)" onClick={this.profileClick.bind(this,ph.profile_id)}>{ph.profileName}</a></li>
                                )}

                                </ul>
                              </div>
                            </div>
                          </div>

                        <div className="row">
                          <div className="col-xs-12">
                            <div className="page-template-dashboard">
                              <div id='calendar'> </div>
                            </div>
                          </div>
                        </div>
               </div>
         </div>
         </div>
      )

    }
  }

  DashBoardCalendar.propTypes = {
      changeRoute: React.PropTypes.func,
  };

  function mapDispatchToProps(dispatch) {
      return {
          changeRoute: (url) => dispatch(push(url)),
      };
  }

  export default connect(null, mapDispatchToProps)(DashBoardCalendar);
