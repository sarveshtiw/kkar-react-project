/**
 * NotFoundPage
 *
 * This is the page we show when the user visits a url that doesn't have a route
 */

import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import Button from 'components/Button';
import H1 from 'components/H1';

export function NotFound(props) {
  return (
    <div className="page-content">
    <div id="bannerBG" className="active">
    <div className="error_page">
    	<div className="errot_title">
        	<h1>404 Page Not Found !</h1>
          <p>The Page You have Requested can not be found.</p>

          <Button className="btn big   btn-profile2" handleRoute={function redirect() { props.changeRoute('/'); }}>  Home Page </Button>
      </div>
    </div>

      </div>
    </div>
  );
}

NotFound.propTypes = {
  changeRoute: React.PropTypes.func,
};

// react-redux stuff
function mapDispatchToProps(dispatch) {
  return {
    changeRoute: (url) => dispatch(push(url)),
  };
}

// Wrap the component to inject dispatch and state into it
export default connect(null, mapDispatchToProps)(NotFound);
