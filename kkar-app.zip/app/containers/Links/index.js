import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import {DashboardMenu} from 'components/DashboardMenu';
import TextField from 'material-ui/TextField';
import {ViewEdit} from 'components/ViewEdit_Component';
import {ProgressSlider} from 'components/ProgressSlider';
var util = require('utils/request');


export class Links extends React.Component {
    openRoute = (route) => {
        this.props.changeRoute(route);
    };

    constructor(props) {
        super(props);
        this.state = {
            stateUpdate:false,
            linkdata: [],
            form_data: {
                id_link: 0,
                profile_id: "",
                link: "",
                about_link: "",
                button_text : 'ADD',
                result : null,
                resultMsg : ''
            }
        }
    }

    componentDidMount() {

document.title = "Extended Profile | Kalakar";
      (function($){
             $(window).load(function(){
             $(".scroller335").mCustomScrollbar({
                 setHeight:335,
                 theme:"dark-3"
               });
             });

         })(jQuery);

        var param = {action: 'link_list', profile_id: this.props.params.profileId}
        var formState = this;
        util.getSetData(param, function (data) {

            if (data.status == "success") {
                formState.setState({
                    linkdata: data.data
                })
            }

        });
        jQuery('#lightgallery').lightGallery();
        jQuery('.lightgallery-single-image').lightGallery();
        jQuery('.lightgallery-single-video').lightGallery();

    }
 handleEditClicked(obj){
        this.setState({
                form_data:{
                    id_link:obj.id_link,
                    link:obj.link,
                    about_link:obj.about_link,
                    button_text : "UPDATE"
                }
            });
           }


    handleInputChange(name, e) {
        var change = {};
        change.form_data = this.state.form_data;
        change.form_data[name] = e.target.value;
        this.setState(change);
        if(name == 'link'){
            this.isDisabledWebsite();
        }

        if(name == 'about_link'){
            this.validate2();
        }
    }
    validateWebsite(value){
        var exp =/^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?.*$/
        return exp.test(value);
    }
    isDisabledWebsite() {
        let urlIsValid = false;
        if (this.state.form_data.link === "") {
            urlIsValid=true;
            this.setState({
                website_error_text: "Reqiured"
            });
        } else {
            if (this.validateWebsite(this.state.form_data.link)) {
                urlIsValid = true;
                this.setState({
                    website_error_text: null
                });
            }
            else {
                this.setState({
                    website_error_text: "Sorry, this is not a valid format"
                });
            }
        }
        return urlIsValid;
    }
    validate2() {
        let valid=false;
        if(this.state.form_data.about_link == ""){
            this.setState({
                about_link_for_error: "Required"
            });
        } else {
            valid=true
            this.setState({
                about_link_for_error: null
            })

        }return valid;
    }
    submitLinks(e){
        e.preventDefault();
        if(!(this.validate2() && this.isDisabledWebsite() )){
            this.validate2();
            this.isDisabledWebsite();
            return;
        }

        this.state.form_data.action = 'links';
        this.state.form_data.profile_id = this.props.params.profileId;
        if(this.state.form_data.id_link != 0){
            this.state.form_data.link_id = this.state.form_data.id_link;
        }
        var param =  this.state.form_data;
        var formState = this;
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                formState.state.stateUpdate = true;
                var param = {action: 'link_list', profile_id: formState.props.params.profileId}
                util.getSetData(param, function (data1) {
                    if (data1.status == "success") {
                        formState.setState({
                            linkdata: data1.data,
                            form_data: {
                                id_link: '',
                                profile_id: "",
                                link: "",
                                about_link: "",
                                button_text : "Add",
                                result : true,
                                resultMsg : data.message
                            }
                        })
                    }});

            }
            else {
                var change = {};
                change.form_data = formState.state.form_data;
                change.form_data["result"] = false;
                change.form_data["resultMsg"] = data.message
                formState.setState(change);
            }
        });

    }

    Continue()
    {
        var p_id = this.props.params.profileId;
        this.props.changeRoute('/my-accounts/extended-profile/'+ p_id +'/tags');
    }

    render() {
        var updateState = false;
        if(this.state.stateUpdate)
        {
            updateState = true;
            this.state.stateUpdate = false;
        }
        return (
            <section className="inner-page basic-profile">

                <DashboardMenu page="Links" profileId = {this.props.params.profileId}/>

                <div className="pageRest cell">
                    <div className="basic-profile-inner">
                        {this.state.form_data.result == true &&
                        <div className="sucess_ep">{this.state.form_data.resultMsg}</div> }
                        {this.state.form_data.result == false &&
                        <div className="error_ep">{this.state.form_data.resultMsg}</div> }
                        <form onSubmit={this.submitLinks.bind(this)}>
                        <div className="row">

                            <div className="col-sm-6 ">
                                <div className="btn_inline_view">
                                    <h1 className="h1_btn">Links</h1>
                            <span className="lightgallery-single-video">
                             <li className="video" data-src="https://www.youtube.com/watch?v=hwirncW2nuM&feature=youtu.be">
                                 <button type="button" className=" btn video_assist_btn">Video Assist <i className="fa fa-play-circle"></i></button>
                             </li></span>

                                </div>
                            </div>
                            <div className="col-sm-6">
                                <h3>Step 7/14</h3>
                            </div>
                            <div>
                            <div className="col-xs-12"><p className="video_assist_subtitle">Add your links</p></div></div>
                        </div>

                        <div className="row">
                            <div className="col-xs-12 ">
                                <input type="text" placeholder="Paste your link"
                                       value={this.state.form_data.link}
                                       onBlur={this.handleInputChange.bind(this,'link')}
                                       onChange={this.handleInputChange.bind(this,'link')} />
                                <small className="errorMsg">{this.state.website_error_text}</small>
                            </div>

                            <div className="col-xs-12 ">
                                <input type="text" placeholder="About your link"
                                       value={this.state.form_data.about_link}
                                       onBlur={this.handleInputChange.bind(this,'about_link')}
                                       onChange={this.handleInputChange.bind(this,'about_link')}/>
                                <small className="errorMsg">{this.state.about_link_for_error}</small>
                            </div>
                        </div>

                        <div className="row">
                            <div className=" col-xs-12 alignRigh1">
                                <button type="submit" className="add_val_btn marginTopBott4">{this.state.form_data.button_text}</button>
                            </div>
                        </div>

                        <div className="row linkListing">
                            <div className="col-sm-6 col-xs-6">
                                <h6>My Links</h6>
                            </div>
                            <div className="col-sm-6 col-xs-6 alignRigh1">
                                <p>Change Order</p>
                            </div>
                            <div className="col-xs-12">
                            <div className="scroller335">
                                <ul>
                                    {this.state.linkdata.map(l =>
                                           <li key={l.id_link}>
                                       <span>
                                         <a href={l.link} target="_blank">{l.link}</a>
                                        <p>{l.about_link}</p>
                                       </span>
                                                <button type="button" onClick={this.handleEditClicked.bind(this,l)} className="editLink">Edit</button>
                                            </li>
                                    )}

                                </ul>
                              </div>
                            </div>

                        </div>
                            <div className="row">
                                <div className="col-xs-12 lastCol">
                                    <div className="spacerLine" style={{border:'none'}}></div>
                                </div>
                            </div>

                        <div className="row">
                            <div className="col-sm-12 col-xs-12 alignRigh1">
                            <button onClick={this.Continue.bind(this)} className="btn btn-profile2 noMargin big ">Continue <i
                                className="fa fa-chevron-right"></i></button>
                            </div>
                        </div>

                            <ProgressSlider profileId = {this.props.params.profileId} stateUpdate={updateState}/>
                        </form>
                    </div>

                </div>

            </section>
        )
    }

}
Links.propTypes = {
    changeRoute: React.PropTypes.func,
};

function mapDispatchToProps(dispatch) {
    return {
        changeRoute: (url) => dispatch(push(url)),
    };
}

export default connect(null,
    mapDispatchToProps)(Links);
