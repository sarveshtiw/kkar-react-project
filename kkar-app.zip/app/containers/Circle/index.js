import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import {DashboardMenu} from 'components/DashboardMenu';
import TextField from 'material-ui/TextField';
import {ViewEdit} from 'components/ViewEdit_Component';
import {ProgressSlider} from 'components/ProgressSlider';
var util = require('utils/request');
import cookie from 'react-cookie';

export class Circle extends React.Component {
    openRoute = (route) => {
        this.props.changeRoute(route);
    };

    constructor(props) {
        super(props);
        this.state = {
            stateUpdate:false,
            user_id:cookie.load('userId'),
            requestList:[],
            category:{},
            searchdata:[],
            keywords:'',
            result : null,
            resultMsg : ''
        }

    }
    componentDidMount() {
      document.title = "Extended Profile | Kalakar";
        var formstate=this;
        var param = {action: 'get_circle_request', profile_id:formstate.props.params.profileId}
        util.getSetData(param, function (data) {
            var requestList = data.data;
            if (data.status == "success" && data.data!=null) {
                formstate.setState({
                    requestList:data.data
                })
            }
        });
        jQuery('#lightgallery').lightGallery();
        jQuery('.lightgallery-single-image').lightGallery();
        jQuery('.lightgallery-single-video').lightGallery();

    }
    handleOptionChange(user_id,e){
        var change = {
            category:this.state.category
        };
        change['category'][user_id] = e.target.value;
        this.setState(change);

    }

    handleChange(name,e){
        var change = {};
        change[name] = e.target.value;
        this.setState(change);
        var userid = this.state.user_id;
        var formstate=this;
        if(e.target.value.length >3){
        var param = {action: 'circle_requests_search', user_id: userid, keywords:e.target.value}
        util.getSetData(param, function (data) {
            var searchdata= data.data;
            if (data.status == "success" && data.data!=null) {
                formstate.setState({
                    searchdata:data.data
                })
            }
        });}
    }

request(id){
    var inviteId=this.state.category[id];
    var userid = this.state.user_id;
    if(inviteId ==null){
    alert(' please select a category');
        return;
    }
    var formstate=this;
    var param = {action: 'circle_request_sent', user_id: userid, invited_id:inviteId, profile_id: formstate.props.params.profileId}
    util.getSetData(param, function (data) {
        if (data.status == "success") {
            formstate.state.stateUpdate = true;
            formstate.setState({searchdata:[], keywords:''

            });
            var param = {action: 'get_circle_request', profile_id:formstate.props.params.profileId}
            util.getSetData(param, function (data1) {
               var requestList = data1.data;
                if (data1.status == "success" && data1.data!=null) {
                    formstate.setState({
                        requestList:data1.data,
                        resultMsg:data.message,
                        result : true
                    });
                }
                 else{
                    formstate.setState({
                        resultMsg:data.message,
                        result : false
                    })

                }
            });
        }
    });
}


Continue()
{
    var p_id = this.props.params.profileId;
    this.props.changeRoute('/my-accounts/extended-profile/'+ p_id +'/photos');
}


    render() {
        var updateState = false;
        if(this.state.stateUpdate)
        {
            updateState = true;
            this.state.stateUpdate = false;
        }


        return (
            <div>
                <section className="inner-page basic-profile">
                    <DashboardMenu page="Circle" profileId = {this.props.params.profileId}/>

                    <div className="pageRest cell">
                        <div className="basic-profile-inner">
                            {this.state.result == true &&
                            <div className="sucess_ep">{this.state.resultMsg}</div> }
                            {this.state.result == false &&
                            <div className="error_ep">{this.state.resultMsg}</div> }
                            <div className="row">
                                <div className="col-sm-6 ">
                                    <div className="btn_inline_view">
                                        <h1 className="h1_btn">Circle of Peers</h1>
                            <span className="lightgallery-single-video">
                             <li className="video" data-src="https://www.youtube.com/watch?v=Cv3NThnhwwM&feature=youtu.be">
                                 <button type="button" className=" btn video_assist_btn">Video Assist <i className="fa fa-play-circle"></i></button>
                             </li></span>

                                    </div>
                                </div>
                                <div className="col-sm-6">
                                    <h3>Step 9/14</h3>
                                </div>

                            </div>

                            <div className="row">
                                <div className="col-sm-10 col-xs-12">
                                    <div className="searchCircle">
                                        <input type="text"
                                               placeholder="Please enter the name of a coworker from whom you would like to recieve a testimonial"
                                            value={this.state.keywords}
                                            onChange={this.handleChange.bind(this,'keywords')}/>
                                        <button type="button"><i className="fa fa-search" aria-hidden="true"></i></button>
                                    </div>

                                </div>
                            </div>

                            {this.state.searchdata.length > 0 &&
                            <div className="row">
                                <div className="col-xs-12">
                                    <div className="circleResults">
                                        <ul>
                                            {this.state.searchdata.map(s =>
                                            <li  key={s.user_id}>
                                                <img src={(s.photo == '0' ||s.photo==null ||s.photo==undefined)?require('./no-img-pro.png'):s.photo} />
                                                    <div className="row">
                                                        <div className="col-md-8 col-xs-8">
                                                        <div className="row">
                                                          <div className="col-sm-6">
                                                            <span> {s.user_name} {s.city} </span>
                                                          </div>
                                                          <div className="col-sm-6">
                                                            <span>
                                                            <select value={this.state.category[s.user_id]}
                                                                    onChange={this.handleOptionChange.bind(this, s.user_id)}>
                                                                <option value="">Select</option>
                                                               { s.category.map(c =>
                                                                <option  key={c.profile_id} value={c.profile_id}>{c.cat_name}</option>
                                                                )}
                                                            </select>
                                                            </span>
                                                            </div>
                                                            </div>
                                                        </div>
                                                        <div className="col-md-4 col-xs-4">
                                                            <button  className="add_val_btn" onClick={this.request.bind(this,s.user_id)}>request</button>
                                                        </div>
                                                        </div>
                                                    </li>
                                            )}
                                                </ul>
                                            </div>
                                        </div>
                                    </div>

                            }
                            <div className="row">
                                <div className="col-xs-12">
                                    <div className="circleResults">
                                        <h3>My Requests</h3>
                                        <ul>
                                            {this.state.requestList.map(s =>
                                            <li key={s.first_name}>
                                                <img src={s.photo}
                                                    alt="" title="" className="img-responsive mCS_img_loaded" />
                                                    <span>{s.first_name + s.last_name}</span>
                                                    <span className="pending">{s.status}</span>
                                                </li>)}
                                            </ul>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="row">
                                        <div className="col-sm-12 col-xs-12 alignRigh1">
                                        <button onClick={this.Continue.bind(this)} className="btn btn-profile2 big ">Continue <i
                                            className="fa fa-chevron-right"></i></button>
                                        </div>
                                    </div>

                            <ProgressSlider profileId = {this.props.params.profileId} stateUpdate={updateState}/>
                        </div>

                    </div>

                </section>

            </div>
        );
    }
}

Circle.propTypes = {
    changeRoute: React.PropTypes.func,
};

function mapDispatchToProps(dispatch) {
    return {
        changeRoute: (url) => dispatch(push(url)),
    };
}

export default connect(null,
    mapDispatchToProps)(Circle);
