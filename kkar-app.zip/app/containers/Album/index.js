import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import {DashboardMenu} from 'components/DashboardMenu';
import TextField from 'material-ui/TextField';
import {ViewEdit} from 'components/ViewEdit_Component';
import {ProgressSlider} from 'components/ProgressSlider';
import {UploadVideo} from 'components/UploadVideo';
import {DialogConfirm} from 'components/TagDelete';
import Dialog from 'material-ui/Dialog';
import cookie from 'react-cookie';
import Cropper from 'react-cropper';
import RaisedButton from 'material-ui/RaisedButton';
var util = require('utils/request');
var iframeStyle={
    height: "140px",
    width: "100%",
    position: "absolute",
    zIndex: 1
};

export class Album extends React.Component {

    openRoute = (route) => {
        this.props.changeRoute(route);
    };

    constructor(props) {
        super(props);
        this.state = {
            stateUpdate:false,
            confirmOpen: false,
            user_id:cookie.load('userId'),
            photoOpen:false,
            albumData: [],
            albumDetail: [],
            subpage:"list",
            title:'',
            albumName:'',
            photoSrc :'',
            albumname:'',
            album_id:'',
            requiredFlag:false,
            disabled:true,
            media_id:'',
            albumtag:'',
            croperstate:false,
            IMGSrc: '',
            uploadingImg:'',
            Message:'',
            photoUrl:'',
            open:false,
            imgTags:'',
            Filename:'',
            picState:'',
            tagError:''
        }
    }

    componentDidMount() {
      document.title = "Extended Profile | Kalakar";
        (function($){
            $(window).load(function(){
                $(".scroller335").mCustomScrollbar({
                    setHeight:335,
                    theme:"dark-3"
                });
            });

        })(jQuery);


            var param = {action: 'get_albums', profile_id: this.props.params.profileId}
            var formState = this;
            util.getSetData(param, function (data) {
                if (data.status == "success") {
                    if(data.data !== undefined){
                    formState.setState({
                        albumData: data.data,
                        subpage:"list",
                        album_id:''
                    })}
                }
            });
        jQuery('#lightgallery').lightGallery();
        jQuery('.lightgallery-single-image').lightGallery();
        jQuery('.lightgallery-single-video').lightGallery();

    };
    handleInputChange(name, e) {
        var change = {};
        change[name] = e.target.value;
        change.requiredFlag=false;
        this.setState(change);

    };
    handleInputChange1(index, e) {
        this.setState({albumtag : e.target.value});

    };
    handleValidation(e) {
        if(this.state.title=="") {
            this.setState({
                requiredFlag:true
            });
            e.preventDefault();
            return false;
        }
        return true;
    }


    handleOpenPhoto(tid, formState) {
        formState.setState({photoOpen: true,dtid: tid});
    };
    handleClosePhoto = () => {
        this.setState({photoOpen: false});
    };
    handleOpenAlbum(phid, formState) {
        formState.setState({dtid: phid, confirmOpen: true});
    };
    handleCloseAlbum = () => {
        this.setState({confirmOpen: false});
    };

    deletePhoto(local) {
        var param = {action : 'deletePhoto',photoId : local.state.dtid ,user_id : cookie.load('userId')
            ,mediaId : local.state.dtid, album_media: 1}
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                local.handleClosePhoto();
                var id=local.state.album_id;
                var param = {action: 'get_album_details', profile_id: local.props.params.profileId, album_id: id}
                util.getSetData(param, function (data) {
                    if (data.status == "success") {
                        local.setState({
                            albumDetail : data.data[0].album_details
                        });
                    }
                });
            }
            else {
            }
        });

    };
    deleteAlbum(local) {
        var albumId=local.state.dtid;
        var param = {action : 'deleteAlbum',albumId:albumId }
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                local.handleCloseAlbum();
               local.state.stateUpdate = true;
                var param = {action: 'get_albums', profile_id: local.props.params.profileId}
                util.getSetData(param, function (data) {
                    if(data.data === undefined){
                    local.setState({
                        albumData: []
                    })
                  }
                  else if (data.status == "success" ) {
                        local.setState({
                            albumData: data.data
                        })
                    }
                });


            }
            else {
            }
        });

    };
    albumClicked(id,name) {
        var param = {action: 'get_album_details', profile_id: this.props.params.profileId, album_id: id}
        var formState = this;
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                formState.setState({
                    title:name,
                    album_id:id,
                    albumDetail : data.data[0].album_details,
                    subpage:"detail",
                    open:false
                });
                jQuery(".scroller335").mCustomScrollbar({
                    setHeight:335,
                    theme:"dark-3"
                });
            }
        });

    };

    VideoComponent(id,name) {

        var formState = this;
        var param = {action: 'get_album_details', profile_id: formState.props.params.profileId, album_id: this.state.album_id}
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                formState.setState({
                    albumDetail : data.data[0].album_details
                });

            }
        });

    };


    createAlbum(){
        var albumId = this.state.album_id;
        var albumname=this.state.title;
        if(albumname==""){
            return;
        }
        var param = {action: 'add_albums', profile_id: this.props.params.profileId, title:albumname}
        if(albumId!="") {
            param.album_id = albumId
        }
        var formState = this;
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                formState.state.stateUpdate = true;
                formState.setState({
                    album_id:data.data.album_id
                });
            }
        });
    };
    createClick(){
        this.setState({
            subpage:"detail",
            open:false,
            album_id:"",
            title:"",
            albumDetail:undefined
        });
    };
    openAlbum(name) {
        this.setState({
            subpage:"list"
        });
        var param = {action: 'get_albums', profile_id: this.props.params.profileId}
        var formState = this;
        util.getSetData(param, function (data) {
            console.log(data);
            if (data.status == "success") {
                formState.setState({
                    albumData: data.data,
                    album_id:"",
                    title:"",
                    albumDetail:undefined,
                    requiredFlag:false
                });
                jQuery(".scroller335").mCustomScrollbar({
                            setHeight:335,
                            theme:"dark-3"
                        });

            }
        });
    };


    uploadImage(){
        if(this.state.imgTags===''){this.setState({tagError:'Photo tags required!'}); return false;}
        var cropperDAta = this.refs.cropper.getCroppedCanvas().toDataURL();
        this.setState({croperstate:false, picState:1, uploadingImg:cropperDAta});
        var formState = this;
        var userid = this.state.user_id;
        var albumid=this.state.album_id;
        var profileId = this.props.params.profileId;
        var params1 = {action:'images', profile_id:profileId, userId: userid, file: cropperDAta, imgtgs:this.state.imgTags, f_name:this.state.Filename,
            album:this.state.album_id}
            util.getSetData(params1, function (data) {
            if(data.status == "success"){
                var param = {action: 'get_album_details', profile_id: formState.props.params.profileId, album_id: formState.state.album_id}
                util.getSetData(param, function (data) {
                    if (data.status == "success") {
                        formState.setState({
                            albumDetail : data.data[0].album_details,picState:2,uploadingImg:''
                        });

                    }
                });

            }
            else {
                formState.setState({picState:3, Message:data.message});
            }
        });
    }

    RotateR(){
        this.refs.cropper.rotate(90);
    }
    _crop(e){
    }
    RotateL(){
        this.refs.cropper.rotate(-90);
    }

    handleImageChange (e) {
        e.preventDefault();
        let reader = new FileReader();
        let file = e.target.files[0];
        reader.onloadend = () => {
            this.setState({croperstate:true, IMGSrc:reader.result, Filename:file.name});
        }
        reader.readAsDataURL(file);
    }
    changeText(e){
        this.setState({imgTags:e.target.value})
    }

    handleOpen(e) {
        if(this.handleValidation(e)) {
            this.setState({croperstate:true
            });
        }

    };
    handleClose() {
    this.setState({croperstate:false});
};
    handleOpenV(e) {
        if(this.handleValidation(e)) {
            this.setState({open: true,
                confirmOpen:false,
                croperstate:false
            });
        }

    };
    retryImage(e){
        if(e===3)
        {
            this.setState({picState:1});
            var formState = this;
            var userid = this.state.user_id;
            var profileId = this.props.params.profileId;
            var params1 = {action:'images', profile_id:profileId, userId: userid, file: this.state.uploadingImg, imgtgs:this.state.imgTags, f_name:this.state.Filename, album:this.state.album_id}
            util.getSetData(params1, function (data) {
                if(data.status == "success"){
                    var param = {action: 'get_album_details', profile_id: formState.props.params.profileId, album_id: formState.state.album_id}
                    util.getSetData(param, function (data) {
                        if (data.status == "success") {
                            formState.setState({
                                albumDetail : data.data[0].album_details,picState:2,uploadingImg:''
                            });

                        }
                    });
                }
                else {
                    formState.setState({picState:3});
                }
            });
        }
    }


    handleCloseV() {
        this.setState({open: false});
    };
    editTag(id){
        document.getElementById("tag"+id).disabled = false;
        this.setState({
            media_id:id
        })
    }
    saveTag(e){
        if(e.keyCode == 13 || e.keyCode == undefined){
            var formState = this;
            var tagdata=this.state.albumtag;
            var mediaId= formState.state.media_id;
            var param = {action: 'editAlbumTag', profile_id: formState.props.params.profileId, mediaTag:tagdata,mediaId:mediaId }
            util.getSetData(param, function (data) {
                document.getElementById("tag"+mediaId).disabled = false;
                if (data.status == "success") {
                    formState.setState({

                    });
                }
            });

        }
        else{

        }
    }
    Continue()
    {
        var p_id = this.props.params.profileId;
        this.props.changeRoute('/my-accounts/extended-profile/'+ p_id +'/deck');
    }
    removeImg(){
      this.setState({uploadingImg:'', picState:0, })
    }

    render() {
        (function($){
            $(window).load(function(){
                $(".scroller336").mCustomScrollbar({
                    setHeight:336,
                    theme:"dark-3"
                });
            });

        })(jQuery);
        var updateState = false;
        if(this.state.stateUpdate)
        {
            updateState = true;
            this.state.stateUpdate = false;
        }
        var local = this;
        return (
            <div>
                <Dialog title="Upload Image" modal={true} open={this.state.croperstate}  className="croperPopup" autoScrollBodyContent={false}>
                    <button onClick={this.uploadImage.bind(this)}  className="uploadBtnCrop"><span className="fa fa-check"></span></button>
                    <p>(min size 800px X 600px)</p>
                    <small className='errorMsg'>{this.state.tagError}</small>
                    <input type='text' placeholder="Photo Tags" value={this.imgTags} onChange={this.changeText.bind(this)}/>
                    <Cropper
                        ref='cropper'
                        src={this.state.IMGSrc}
                        style={{height: 400, width: '100%'}}
                        guides={false}
                        />
              <span className="RotateBtnCropOuter">
                <button title='Rotate Left' onClick={this.RotateL.bind(this)} className="RotateBtnCrop"><span className="fa fa-rotate-left"></span></button>
                <button title='Rotate Right' onClick={this.RotateR.bind(this)} className="RotateBtnCrop"><span className="fa fa-rotate-right"></span></button>
              </span>
                    <RaisedButton className="cancelBtnPopup" primary={true} onTouchTap={this.handleClose.bind(this)} label="X"/>
                </Dialog>
                {local.state.subpage == "list" &&
                <div>
                    <section className="inner-page basic-profile">
                        <DashboardMenu page="Albums" profileId={this.props.params.profileId}/>

                        <div className="pageRest cell">
                            <div className="basic-profile-inner">
                                <div className="row">
                                    <div className="col-sm-6 ">
                                        <div className="btn_inline_view">
                                            <h1 className="h1_btn">Albums</h1>
                            <span className="lightgallery-single-video">
                             <li className="video" data-src="https://www.youtube.com/watch?v=ysE7eo5Zn-M&feature=youtu.be">
                                 <button type="button" className=" btn video_assist_btn">Video Assist <i className="fa fa-play-circle"></i></button>
                             </li></span>

                                        </div>
                                    </div>
                                    <div className="col-sm-6">
                                        <h3>
                                            Step 12/14
                                        </h3>
                                    </div>
                                </div>
                                <div className="scroller335">
                                    <div className="row">
                                        <div className="col-xs-12">
                                            <div className="albums-data">
                                                <div
                                                    className="albums-data__inner"
                                                    id="photo-block1">
                                                    <div className="photo-block">
                                                        <div className="photo-block__img">
                                                            <div className="upload">
                                                              <span className="fileUploadBtn"><a href="javascript:void(0);"
                                                                                                 onClick={this.createClick.bind(this)}>+</a></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="album_title">
                                                        Create New Album
                                                    </div>
                                                </div>

                                                {this.state.albumData.map(a =>
                                                    <div
                                                        className="albums-data__inner"
                                                        id="photo-block1" key={a.album_id}>
                                                        <div className="photo-block">
                                                            <a href="javascript:void(0);"
                                                               onClick={this.albumClicked.bind(this,a.album_id,a.album_name)}>
                                                                <div style={iframeStyle}></div>
                                                                <div className="photo-block__img">
                                                                    {a.album_details !== undefined && a.album_details[0] &&
                                                                    a.album_details[0].type === "video" &&
                                                                    <iframe width="100%" height="140px"
                                                                            src={a.album_details[0].location} frameBorder="0"
                                                                            allowFullScreen>
                                                                    </iframe>
                                                                    }
                                                                    { a.album_details !== undefined && a.album_details[0] &&
                                                                    a.album_details[0].type === "image" &&
                                                                    <img
                                                                        src={a.album_details[0].location}
                                                                        alt=""
                                                                        title
                                                                        className="img-responsive mCS_img_loaded"/>

                                                                    }

                                                                </div>
                                                                <div className="album_title">{a.album_name}</div>
                                                            </a>
                                                            <a href = "javascript:void(0)" onTouchTap={this.handleOpenAlbum.bind(null,a.album_id,this)} title="Delete">
                                                                <span className="pic-delt"/>
                                                            </a>
                                                        </div>
                                                    </div>)}
                                            </div>
                                            <DialogConfirm open={local.state.confirmOpen} title="Delete Album"
                                                           body="Do you really want to delete?"
                                                           onSubmit={local.deleteAlbum.bind(null,local)}
                                                           onClose={local.handleCloseAlbum}/>
                                        </div>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-sm-12 col-xs-12 alignRigh1">
                                        <button className="btn btn-profile2 big noMargin" onClick={this.Continue.bind(this)}>
                                            Continue <i className="fa fa-chevron-right"/>
                                        </button>
                                    </div>
                                </div>
                                <ProgressSlider profileId={this.props.params.profileId} stateUpdate={updateState}/>
                            </div>
                        </div>
                    </section>
                </div>}

                {local.state.subpage == "detail" &&
                <div>
                    <section className="inner-page basic-profile">
                        <DashboardMenu page="Albums" profileId={this.props.params.profileId}/>
                        <div className="pageRest cell">
                            <div className="basic-profile-inner">
                                <div className="row">
                                    <div className="col-sm-6">
                                        <h1>Albums</h1>
                                    </div>
                                    <div className="col-sm-6">
                                        <h3>
                                            Step 12/14
                                        </h3>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-xs-12">
                                        <input type="text" placeholder="Name Album" value={this.state.title}
                                               onChange={this.handleInputChange.bind(this,'title')}
                                               onBlur={this.createAlbum.bind(this)}/>
                                        {this.state.requiredFlag == true && <small className="errorMsg">Please enter album name first!</small>}
                                        <p>&nbsp; </p>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-xs-12">
                                        <div className="scroller336 albums-data">
                                            <div
                                                className="albums-data__inner"
                                                id="photo-block1">
                                                <div className="photo-block">
                                                    <div className="photo-block__img">
                                                        <div className="upload">
                                                    <span className="fileUploadBtn">+<input id="file"
                                                                                  type="file" onChange={this.handleImageChange.bind(this)}
                                                                                  onClick={this.handleValidation.bind(this)}
                                                                                  accept="image/*"/>
                                                    </span>
                                                        </div>
                                                        </div>
                                                </div>
                                                <input
                                                    type="text"
                                                    placeholder="Upload Image"
                                                    readOnly/>
                                            </div>
                                            <div
                                                className="albums-data__inner"
                                                id="photo-block1">
                                                <div className="photo-block">
                                                    <div className="photo-block__img">
                                                        <div className="upload">
                                          <span className="fileUploadBtn">
                                              <a href="javascript:void(0);"  onTouchTap={this.handleOpenV.bind(this)}  >+</a></span>
                                                            <UploadVideo open={this.state.open} close={this.handleCloseV.bind(this)} albumId={this.state.album_id}
                                                                         profileId={this.props.params.profileId} detailAlbum={this.VideoComponent.bind(this)} />
                                                        </div>
                                                    </div>
                                                </div>
                                                <input
                                                    type="text"
                                                    placeholder="Upload Video"
                                                    readOnly/>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="scroller335">
                                    <div className="row">
                                        <div className="col-xs-12">
                                            {this.state.albumDetail != undefined && this.state.album_id!="" &&
                                            <div className=" albums-data">

                                                {this.state.albumDetail.map((detail, i) =>

                                                    <div
                                                        className="albums-data__inner"
                                                        id="photo-block1"  key={detail.media_id}>
                                                        <div className="photo-block">

                                                            <div className="photo-block__img">
                                                                {(detail.type === "video")?
                                                                    <iframe width="100%" height="140px"
                                                                            src={detail.location} frameBorder="0"
                                                                            allowFullScreen>
                                                                    </iframe>
                                                                    :<img
                                                                    src={detail.location}
                                                                    alt=""
                                                                    title
                                                                    className="img-responsive mCS_img_loaded"/>

                                                                }
                                                            </div>
                                                            <a href="javascript:void(0)" onTouchTap={this.handleOpenPhoto.bind(null,detail.media_id,this)} title="Delete">
                                                                <span className="pic-delt"/>
                                                            </a>
                                                            <input
                                                                id={"tag"+detail.media_id}
                                                                type="text"
                                                                className=" editbox"
                                                                placeholder="Tag this photo, seperate tags by comma"
                                                                defaultValue={detail.tag}
                                                                onChange={this.handleInputChange1.bind(this, i)}
                                                                disabled={this.state.disabled}
                                                                onBlur={this.saveTag.bind(this)}
                                                                onKeyDown = {this.saveTag.bind(this)}

                                                                />
                                                            <span className="pic-edit"  onClick={this.editTag.bind(this,detail.media_id)}/>
                                                        </div>
                                                    </div>)}
                                                    {(this.state.picState!=='' && this.state.picState!==2)?
                                                      <div className="albums-data__inner"
                                                          id="photo-block1"  key={this.state.media_id}>
                                                          <div className="photo-block">
                                                              <div className="photo-block__img">
                                                                <div className={(this.state.picState==1)? 'ajax_loading_loader_image':(this.state.picState==3)?
                                                                 'ajax_retry':(this.state.picState==2)?'ajax_complete':''} ></div>
                                                                <img
                                                      src={this.state.uploadingImg}
                                                      alt=""
                                                      title
                                                      className="img-responsive "/></div>
                                                    <a href="javascript:void(0)" onTouchTap={this.removeImg.bind(this, this.state.media_id)} title="Delete">
                                                          <span className="pic-delt"/>
                                                      </a>
                                                      <input
                                                          type="text"
                                                          className=" editbox"
                                                          placeholder="Tag this photo, seperate tags by comma"
                                                          value={this.state.imgTags}
                                                          />
                                                          <div style={{position: 'relative', bottom: '2px', fontSize: '12px', lineHeight: '12px', color: 'rgb(244, 67, 54)', transition: 'all 450ms cubic-bezier(0.23, 1, 0.32, 1) 0ms'}}>{this.state.Message}</div>

                                                                </div></div>:''}
                                            </div>}

                                        </div>
                                        <DialogConfirm open={local.state.photoOpen} title="Delete Photo"
                                                       body="Do you really want to delete?"
                                                       onSubmit={local.deletePhoto.bind(null,local)}
                                                       onClose={local.handleClosePhoto}/>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-sm-12 col-xs-12 alignRigh1">
                                        <button className="btn btn-profile2 big noMargin" onClick={this.openAlbum.bind(this)}>
                                            <i className="fa fa-chevron-left"/> Back
                                        </button>
                                        <button className="btn btn-profile2 big noMargin" onClick={this.createClick.bind(this)}>
                                            Create New Album <i className="fa fa-chevron-right"/>
                                        </button>
                                        <button className="btn btn-profile2 big noMargin" onClick={this.Continue.bind(this)}>
                                            Continue <i className="fa fa-chevron-right"/>
                                        </button>
                                    </div>
                                </div>
                                <ProgressSlider profileId={this.props.params.profileId} stateUpdate={updateState}/>
                            </div>
                        </div>
                    </section>
                </div>}


            </div>


        )
    }
}
Album.propTypes = {
    changeRoute: React.PropTypes.func,
};

function mapDispatchToProps(dispatch) {
    return {
        changeRoute: (url) => dispatch(push(url)),
    };
}

export default connect(null,
    mapDispatchToProps)(Album);
