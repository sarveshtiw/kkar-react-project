import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import Button from 'components/Button';
import Dialog from 'material-ui/Dialog';
import RaisedButton from 'material-ui/RaisedButton';
import cookie from 'react-cookie';
var util = require('utils/request');

export class emailVerification extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            userId: cookie.load('userId'),
            Code: cookie.load('code'),
            open: false, OTPINI: '',
            resend_otp: ''
        }
    }

    componentDidMount() {
        if (this.state.Code === 202 || this.state.Code === 203) {
            this.setState({open: false});
        }
        else {
            this.setState({open: true});
        }
        var local = this;
        var emailid = this.props.location.query.email;
        var email_verication_code = this.props.location.query.email_verication_code;
        var param = {action: 'verifyEmail', email: emailid, email_verification_otp: email_verication_code}
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                local.setState({otpverifiedmsg: data.message});
            }
            else {
                local.setState({otpverifiedmsg: data.message});
            }
        });

    }

    openRoute = (route) => {
        this.props.changeRoute(route);
    };
    /**
     * Changed route to '/'
     */
    openHomePage = () => {
        this.openRoute('/');
    };

    //verifyOTP(){
    // var local = this;
    // var emailid = this.props.location.query.email;
    // var email_verication_code = this.props.location.query.email_verication_code;
    // var param = {action:'verifyEmail', email: emailid, email_verification_otp:email_verication_code}
    //  util.getSetData(param, function (data) {
    //  if(data.status == "success"){
    //    local.setState({otpverifiedmsg:data.message, reset:1,});
    //       }
    //       else{
    //           local.setState({otpverifiedmsg:data.message});
    //       }
    //   });
    //   }

    CreateProfile(formName) {
        if (this.state.userId === null || this.state.userId === undefined || this.state.userId === "") {
            $('#loginWrap').show();
            $('#loginWrap').toggleClass('fadeOutDown fadeInUp');
        } else {
            cookie.save('create_profile', true, {path: '/'});
            $(location).attr('href', '/my-dashboard/');
        }
    }

    render() {

        return (
            <section className="inner_page">
                <div className="container">
                    <div className="row">
                        <div className="col-xs-12">
                            <div className="varification_main">
                                <div className="varification_con">
                                    <div className="entry-header">
                                        <h1 className="entry-title">Email Verification</h1>
                                    </div>
                                    <div className="entry-content">
                                        <p>{this.state.otpverifiedmsg}</p>

                                        <div className="submit_btns">
                                            <button type="submit" className=" btn alertOkBtn "
                                                    onTouchTap={this.CreateProfile.bind(this,'home')}> Create your basic
                                                profile
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </section>

        );
    }
}

emailVerification.propTypes = {
    changeRoute: React.PropTypes.func,
};

function mapDispatchToProps(dispatch) {
    return {
        changeRoute: (url) => dispatch(push(url)),
    };
}

export default connect(null, mapDispatchToProps)(emailVerification);
