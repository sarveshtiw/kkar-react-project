import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import {DashboardMenu} from 'components/DashboardMenu';
import {ProgressSlider} from 'components/ProgressSlider';
var util = require('utils/request');


export class DashboardIntro extends React.Component {

    openRoute = (route) => {
        this.props.changeRoute(route);
    };

    constructor(props) {
        super(props);
        this.state = {
            about_us: '',
            stateUpdate:'',
            keypress:""
        }
    }

    componentDidMount() {
      document.title = "Extended Profile | Kalakar";
        $("[data-toggle='tooltip']").tooltip();
        var param = {action: 'about_get', profile_id: this.props.params.profileId}
        var formState = this;
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                var dataAbout = decodeURI(data.data.about_us.replace(/<br\s*[\/]?>/gi, "\n"));
                formState.setState({
                    about_us:dataAbout
                })
            }

        });
        jQuery('#lightgallery').lightGallery();
        jQuery('.lightgallery-single-image').lightGallery();
        jQuery('.lightgallery-single-video').lightGallery();


    }

    handleInputChange(name, e) {
        var change = {};
        change[name] = e.target.value;
        this.setState(change);
        this.validateIntro();
    }

    validateIntro() {
        let valid = true;
        if (this.state.about_us.length < 100 || this.state.about_us.length > 1500) {
            valid = false;
            this.setState({
                errortext: "Enter Text between 100 to 1500"
            });
        }else{
            this.setState({
                errortext: null
            });
        }
        return valid;
    }

    submitAbout() {
        if (this.validateIntro() == false) {
            return;
        }
        const p_id = this.props.params.profileId;
        const aboutus = this.state.keypress;
        var param = {action: 'about_us', profile_id: p_id, about_us: aboutus};
        var formState = this;
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                formState.state.stateUpdate = true;
                formState.props.changeRoute('/my-accounts/extended-profile/'+ p_id +'/workcred');
            }

        });
    }
    saveTag(e){
        var keyed =e.target.value.replace(/[\n]/g,'<br/>');
        this.setState({
           keypress:keyed
        })


    }



    render() {
        var updateState = false;
        if(this.state.stateUpdate)
        {
            updateState = true;
            this.state.stateUpdate = false;
        }
        return (
            <div>
                <section className="inner-page basic-profile">
                 <DashboardMenu page="Intro" profileId = {this.props.params.profileId}/>
                    <div className="pageRest cell">
                        <div className="basic-profile-inner intro">
                            <form onSubmit={this.submitAbout.bind(this)}>
                                <div className="row">
                                    <div className="col-sm-6 ">
                                        <div className="btn_inline_view">
                                            <h1 className="h1_btn">Intro</h1>
                            <span className="lightgallery-single-video">
                             <li className="video" data-src="https://www.youtube.com/watch?v=1NHDoPCy47A&feature=youtu.be">
                                 <button type="button" className=" btn video_assist_btn">Video Assist <i className="fa fa-play-circle"></i></button>
                             </li></span>

                                        </div>
                                    </div>
                                    <div className=" col-sm-6">
                                        <h3>Step 3/14</h3>
                                    </div>

                                </div>

                                <div className="minBox">

                                    <div className="row">
                                        <div  className="col-md-10 col-sm-12 col-xs-12">

                                        <textarea
                                            id="txtArea"
                                            placeholder="About Me"
                                                  className="aboutMe"
                                                  value={this.state.about_us}
                                            onKeyDown = {this.saveTag.bind(this)}
                                                  onChange={this.handleInputChange.bind(this,'about_us')}
                                            ></textarea>

                                            <span className="errorMsg"> {this.state.errortext} </span>

                                            <small>Between 100 to 1500 Words <i className="fa fa-info"
                                                                                data-toggle="tooltip"
                                                                                title="About Yourself"></i></small>
                                        </div>

                                    </div>

                                </div>

                                <div className="row">
                                    <div className="col-md-10 col-sm-12 col-xs-12 alignRigh1">
                                        <button type="button" className="btn btn-profile2 big noMargin" onClick={this.submitAbout.bind(this)}>Continue <i
                                            className="fa fa-chevron-right"></i></button>
                                    </div>
                                </div>



                            </form>
                            <ProgressSlider profileId = {this.props.params.profileId} stateUpdate={updateState}/>

                        </div>

                    </div>

                </section>
            </div>
        )
    }
}

DashboardIntro.propTypes = {
    changeRoute: React.PropTypes.func,
};

function mapDispatchToProps(dispatch) {
    return {
        changeRoute: (url) => dispatch(push(url)),
    };
}

export default connect(null, mapDispatchToProps)(DashboardIntro);
