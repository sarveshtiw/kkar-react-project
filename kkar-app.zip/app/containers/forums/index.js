import React, { Component } from 'react';
import RaisedButton from 'material-ui/RaisedButton';
import {DashboardHeader} from 'components/DashboardHeader_Component';
import {DashboardEditProfile} from 'components/DashboardEditProfile_Component';
var util = require('utils/request');
import cookie from 'react-cookie';
import { connect } from 'react-redux';
export class forums extends React.Component {

    openRoute = (route) => {
        this.props.changeRoute(route);
    };
  constructor(props) {
    super(props);
    this.state =
    {
        user_id:cookie.load('userId')

    }
 }

  componentDidMount() {
     document.title = "My Dashboard | Kalakar";
  }

  render() {
    return (
      <div className="PageMinHeight">
          <DashboardHeader page="Forums"/>
          <div className="container">
            <div className="comming_soon_page">
              <div className="comming_soon_con">
                  <h2>Coming Soon...</h2>
                  <p>To be launch in the 2nd Phase</p>
              </div>
            </div>
        </div>
      </div>
    );
  }
}

forums.propTypes = {
    changeRoute: React.PropTypes.func,
};

function mapDispatchToProps(dispatch) {
    return {
        changeRoute: (url) => dispatch(push(url)),
    };
}

export default connect(null,
    mapDispatchToProps)(forums);
