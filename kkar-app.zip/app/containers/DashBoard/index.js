/**
 * Created by Neeru on 7/13/2016.
 */
//import React from 'react';
import React, { Component } from 'react';
import style from '../App/assets/css/stylesheet_vinay.css';
/*import ImgPro from "../App/assets/img/mansi-profile-pic.png";*/
import RaisedButton from 'material-ui/RaisedButton';
import {DashboardHeader} from 'components/DashboardHeader_Component';
import {DashboardEditProfile} from 'components/DashboardEditProfile_Component';
var util = require('utils/request');
import cookie from 'react-cookie';
import {CreateProfile} from 'components/CreateProfile_Component'
//var Carousel = require('react-responsive-carousel').Carousel;

export class DashBoard extends React.Component {
  constructor(props) {
    super(props);
    this.state =
    {
      user_id:cookie.load('userId'),
      user_name : "",
      user_info : [],
      showHideDiv : false,
      openState : false,
        pageLoader:true
    }
 }
    componentDidUpdate(){$('.pageloader').remove();}
  componentDidMount() {
     document.title = "My Dashboard | Kalakar";
      var userid = this.state.user_id;
      var param = {action:'dashboard',user_id: userid}
      var formState = this;
      util.getSetData(param,function (data) {
      if(data.status == "success"){
          if(data.data !== undefined){
            formState.setState({user_info : data.data});
           }
           else{
              formState.setState({showHideDiv : true});
              //console.log(data.message);
           }}
       });
  }

  handleOpen = () => {
       this.setState({openState: true});
     };

  handleClose = () => {
      this.setState({openState: false});
  };

  render() {
    return (
      <div className="PageMinHeight">
          <div className="pageloader"><img src="http://kalakar.pro:90/kalakar/demo/other/assets/img/loader.svg"/></div>
        <DashboardHeader page="EditProfile" />

          <div className="container">
          { (this.state.showHideDiv == true) &&
            <div style={{textAlign:"center"}}>
            <div style={{paddingTop:"160px",paddingBottom:"80px"}}>You do not have any profile. Please create a profile.
            </div>
            <RaisedButton label="Create New Profile" primary={true} onTouchTap={this.handleOpen}/>

            </div>
          }
            <div className="owl-carousel dash_profileItem">
            {this.state.user_info.map(function(object, i){
              return <DashboardEditProfile key = {i} profile_id={object.profile_id} category={object.category}
                                           bigimage={object.image} smallimages={object.images}  />
            })}
          </div>
          <CreateProfile open={this.state.openState} close={this.handleClose}/>
        </div>
      </div>
    );
  }
}

export default DashBoard;
