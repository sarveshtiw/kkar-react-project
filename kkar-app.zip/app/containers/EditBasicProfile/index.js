/*
 * FeaturePage
 *
 * List all the features
 */
import React from 'react';
import {connect} from 'react-redux';
import RaisedButton from 'material-ui/RaisedButton';
import {push} from 'react-router-redux';
import TextField from 'material-ui/TextField';
import SelectField from 'material-ui/SelectField';
import MenuItem from 'material-ui/MenuItem';
import Dialog from 'material-ui/Dialog';
import {RadioButton, RadioButtonGroup} from 'material-ui/RadioButton';
import ActionFavorite from 'material-ui/svg-icons/action/favorite';
import ActionFavoriteBorder from 'material-ui/svg-icons/action/favorite-border';
import cookie from 'react-cookie';
import { API_URL } from 'containers/App/constants';
import DatePicker from 'material-ui/DatePicker';
var util = require('utils/request');
import Cropper from 'react-cropper';
import {ResultMsg} from 'components/ResultMsg';


export default class EditBasicProfile extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            kalakar: 'http://kalakar.pro/',
            open: false,
            user_id: cookie.load('userId'),
            country_error_text: null,
            state_error_text: null,
            primary_language_text: null,
            countrys: [],
            lang: [],
            statesdata: [],
            citydata: [],
            croperstate: false,
            message: '',
            Message:'',
            pageLoader: true,
            resultDialogOpen: false,
            form_data: {
                profile_photo: '',
                first_name: '',
                middle_name: '',
                last_name: '',
                full_name: '',
                profile_url: '',
                email: '',
                exist_gender: '',
                exist_dob: '',
                country: '',
                state: '',
                city: '',
                exist_phone: '',
                company_name: '',
                primary_language: '',
                secondary_language: '',
                zip_code: '',
                facebook: '',
                twitter: '',
                google: '',
                instagram: '',
                wikipedia: '',
                youtube: '',
                watsapp: '',
                IMGSrc: '',
                uploadingImg: '',
                picState: 0,
                profileUrl: ''

            }

        }
    }

    componentDidUpdate() {
        $('.pageloader').remove();
    }

    componentDidMount() {
        document.title = "My Accounts | Kalakar";
        var userid = this.state.user_id;
        var param = {action: 'get_basic_profile', user_id: userid}
        $.ajax({
            url: API_URL,
            type: "POST",
            dataType: 'json',
            data: param,
            success: function (data) {

                if (data.code === 202) {
                    cookie.save('code', 202, {path: '/'});
                    $(location).attr('href', '/verification/');//  this.props.changeRoute('/verification/');
                } else if (data.code === 203) {
                    cookie.save('code', 203, {path: '/'});
                    $(location).attr('href', '/emailVerification/');
                }else{
                    var CountryData = data.country_data[0];
                    var ProObj = data.profile_data[0];
                    var languages = {action: 'get_languages'};
                    this.setState({
                        countrys: data.country_data,
                        lang: data.language_data,
                        photoUrl: (data.profile_photo === null || data.profile_photo === '') ? require('./user-profile.png') : data.profile_photo,
                        media_id: ProObj.profile_photo,
                        form_data: {
                            first_name: data.first_name,
                            middle_name: data.middle_name,
                            last_name: data.last_name,
                            profile_url: ProObj.profile_url,
                            full_name: ProObj.full_name,
                            email: data.email,
                            exist_gender: ProObj.gender,
                            exist_dob: ProObj.date_of_birth,
                            country: ProObj.country,
                            state: ProObj.state,
                            city: ProObj.city,
                            exist_phone: ProObj.phone_no,
                            company_name: ProObj.company,
                            primary_language: ProObj.primary_language,
                            secondary_language: ProObj.secondary_language,
                            zip_code: ProObj.pincode,
                            facebook: (ProObj.facebook_profile == null) ? "" : decodeURIComponent(ProObj.facebook_profile),
                            twitter: (ProObj.twitter_profile == null) ? "" : decodeURIComponent(ProObj.twitter_profile),
                            google: (ProObj.google_profile == null) ? "" : decodeURIComponent(ProObj.google_profile),
                            instagram: (ProObj.instagram_profile == null) ? "" : decodeURIComponent(ProObj.instagram_profile),
                            wikipedia: (ProObj.wikipidea_profile == null) ? "" : decodeURIComponent(ProObj.wikipidea_profile),
                            youtube: (ProObj.youtube_profile == null) ? "" : decodeURIComponent(ProObj.youtube_profile),
                            watsapp: (ProObj.whatsapp_profile == null) ? "" : decodeURIComponent(ProObj.whatsapp_profile),
                            uploadingImg: ''
                        }


                    });

                    var statesdatas = {action: 'get_states', country: ProObj.country};
                    $.ajax({
                        url: API_URL,
                        type: "POST",
                        dataType: 'json',
                        data: statesdatas,
                        success: function (data) {

                            this.setState({
                                statesdata: data.states
                            })
                        }.bind(this)


                    });

                    var citydatas = {action: 'get_cities', state: ProObj.state};

                    $.ajax({
                        url: API_URL,
                        type: "POST",
                        dataType: 'json',
                        data: citydatas,
                        success: function (data) {
                            if (data.status == "success") {
                                var citydata = data.cities;
                                this.setState({
                                    citydata: data.cities
                                });
                            }

                        }.bind(this)

                    });
                }



            }.bind(this)
        });
        jQuery('#lightgallery').lightGallery();
        jQuery('.lightgallery-single-image').lightGallery();
        jQuery('.lightgallery-single-video').lightGallery();

    }

    handleImageChange(e) {
        e.preventDefault();
        let reader = new FileReader();
        let file = e.target.files[0];
        reader.onloadend = () => {
            this.setState({croperstate: true, IMGSrc: reader.result, Filename: file.name});
        }
        reader.readAsDataURL(file);
    }

    redirectDashboard(){
        this.props.changeRoute('/my-dashboard/');
    }

    commonValidate() {
        let valid = false;
        if (this.state.form_data.first_name === "" || this.state.form_data.first_name === null || this.state.form_data.first_name === undefined) {
            this.setState({
                firstName_error_text: "Required"
            });
        } else {
            valid = true
            this.setState({
                firstName_error_text: null
            })

        }
        return valid;
    }

    commonValidate1() {
        let valid = false;
        if (this.state.form_data.last_name === "" || this.state.form_data.last_name === null || this.state.form_data.last_name === undefined) {
            this.setState({
                lastName_error_text: "Required"
            });
        } else {
            valid = true
            this.setState({
                lastName_error_text: null
            })

        }
        return valid;
    }



    validatePincode(value) {
        var re = /^\d{6}$/;
        return re.test(value);
    }

    commonValidate3() {
        let valid = false;
        if (this.state.form_data.zip_code === "" || this.state.form_data.zip_code === null || this.state.form_data.zip_code === undefined) {
            this.setState({
                pincode_error_text: "Required"
            });
        }
        else {
            if (this.validatePincode(this.state.form_data.zip_code)) {
                valid = true
                this.setState({
                    pincode_error_text: null
                });
            }
            else {

            }
        }
        return valid;
    }

    validateSelect() {
        let valid = false;
        if (this.state.form_data.country === "" || this.state.form_data.country === null || this.state.form_data.country === undefined) {
            this.setState({
                    country_error_text: "Required"
                }
            );

        } else {
            valid = true
            this.setState({
                country_error_text: null
            })

        }
        return valid;
    }

    validateSelectlang1() {
        let valid = false;
        if (this.state.form_data.primary_language == "" || this.state.form_data.primary_language == null || this.state.form_data.primary_language == undefined) {
            this.setState({
                    primary_language_text: "Required"
                }
            );

        } else {
            valid = true
            this.setState({
                primary_language_text: null
            })

        }
        return valid;
    }

    validateSelectlang2() {
        let valid = false;
        if (this.state.form_data.secondary_language === "" || this.state.form_data.secondary_language === null || this.state.form_data.secondary_language === undefined) {
            this.setState({
                    secondary_language_text: "Required"
                }
            );

        } else {
            valid = true
            this.setState({
                secondary_language_text: null
            })

        }
        return valid;
    }

    validateSelect1() {
        let valid = false;
        if (this.state.form_data.state === "" || this.state.form_data.state === null || this.state.form_data.state === undefined) {
            this.setState({
                    state_error_text: "Required"
                }
            );

        } else {
            valid = true
            this.setState({
                state_error_text: null
            })

        }
        return valid;
    }

    validateSelect2() {
        let valid = false;
        if (this.state.form_data.city === "" || this.state.form_data.city === null || this.state.form_data.city === undefined) {
            this.setState({
                    city_error_text: "Required"
                }
            );

        } else {
            valid = true;
            this.setState({
                city_error_text: null
            });

        }
        return valid;
    }

    validateTwitter(value) {
        var exp = /(?:http|https):\/\/(?:www.)?twitter\.com\/(#!\/)?[a-zA-Z0-9_]+/;
        return exp.test(value);
    }

    isDisabledTwitter() {
        let urlIsValid = false;
        if (this.state.form_data.twitter === "" || this.state.form_data.twitter === null || this.state.form_data.twitter === undefined) {
            urlIsValid = true;
            this.setState({
                twebsite_error_text: null
            });
        } else {
            if (this.validateTwitter(this.state.form_data.twitter)) {
                urlIsValid = true;
                this.setState({
                    twebsite_error_text: null
                });
            }
            else {
                this.setState({
                    twebsite_error_text: "Sorry, this is not a valid format"
                });
            }
        }
        return urlIsValid;
    }

    validateWatsapp(value) {
        var e = /^([0|\+[0-9]{1,5})?([7-9][0-9]{9})$/;
        return e.test(value);
    }

    isDisabledphone() {
        let phoneIsValid = false;
        if (this.state.form_data.watsapp == null || this.state.form_data.watsapp === "" || this.state.form_data.watsapp === undefined) {
            this.setState({
                phone_error_text: null
            });
            phoneIsValid=true;
        } else {
            if (this.validateWatsapp(this.state.form_data.watsapp)) {
                phoneIsValid = true;
                this.setState({
                    phone_error_text: null
                });
            } else {
                this.setState({
                    phone_error_text: "Sorry, this is not a valid format"
                });
            }

        }
        return phoneIsValid;
    }

    //isDisabledMobile() {
    //    let phoneIsValid = false;
    //    if (this.state.form_data.exist_phone === null || this.state.form_data.exist_phone === "" || this.state.form_data.exist_phone === undefined) {
    //        this.setState({
    //            exist_phoneerror_text: "Required"
    //        });
    //    } else {
    //        if (this.validateWatsapp(this.state.form_data.exist_phone)) {
    //            phoneIsValid = true
    //            this.setState({
    //                exist_phoneerror_text: null
    //            });
    //        } else {
    //            this.setState({
    //                exist_phoneerror_text: "Sorry, this is not a valid format"
    //            });
    //        }
    //
    //    }
    //    return phoneIsValid;
    //}

    validateFacebook(value) {
        var exp = /(?:(?:http|https):\/\/)?(?:www.)?facebook.com\/(?:(?:\w)*#!\/)?(?:pages\/)?(?:[?\w\-]*\/)?(?:profile.php\?id=(?=\d.*))?([\w\-]*)?/;
        return exp.test(value);
    }

    isDisabledFacebook() {
        let urlIsValid = false;
        if (this.state.form_data.facebook === "" || this.state.form_data.facebook === null || this.state.form_data.facebook === undefined) {
            urlIsValid = true;
            this.setState({
                fwebsite_error_text: null
            });
        } else {
            if (this.validateFacebook(this.state.form_data.facebook)) {
                urlIsValid = true;
                this.setState({
                    fwebsite_error_text: null
                });
            }
            else {
                this.setState({
                    fwebsite_error_text: "Sorry, this is not a valid format"
                });
            }
        }
        return urlIsValid;
    }

    validateWiki(value) {
        var exp = /(?:(?:http|https):\/\/)?(?:www.)?(?:wikipedia.com)\/([A-Za-z0-9-_]+)/
        return exp.test(value);
    }

    isDiasbleWiki() {
        let urlIsValid = false;
        if (this.state.form_data.wikipedia === "" || this.state.form_data.wikipedia === null || this.state.form_data.wikipedia === undefined) {
            urlIsValid = true;
            this.setState({
                wikiwebsite_error_text: null
            });
        } else {
            if (this.validateWiki(this.state.form_data.wikipedia)) {
                urlIsValid = true;
                this.setState({
                    wikiwebsite_error_text: null
                });
            }
            else {
                this.setState({
                    wikiwebsite_error_text: "Sorry, this is not a valid format"
                });
            }
        }
        return urlIsValid;
    }

    validateInstagram(value) {
        var exp = /(?:(?:http|https):\/\/)?(?:www.)?(?:instagram.com|instagr.am)\/([A-Za-z0-9-_]+)/;
        return exp.test(value);
    }

    isDisabledInsta() {
        let urlIsValid = false;
        if (this.state.form_data.instagram === "" || this.state.form_data.instagram === null || this.state.form_data.instagram === undefined) {
            urlIsValid = true;
            this.setState({
                iwebsite_error_text: null
            });
        } else {
            if (this.validateInstagram(this.state.form_data.instagram)) {
                urlIsValid = true;
                this.setState({
                    iwebsite_error_text: null
                });
            }
            else {
                this.setState({
                    iwebsite_error_text: "Sorry, this is not a valid format"
                });
            }
        }
        return urlIsValid;
    }

    validateGoogle(value) {
        var exp = /(?:(?:http|https):\/\/)?plus\.google\.com\/.?\/?.?\/?([0-9]*)/;
        return exp.test(value);
    }

    isDisabledGoogle() {
        let urlIsValid = false;
        if (this.state.form_data.google === "" || this.state.form_data.google === null || this.state.form_data.google === undefined) {
            urlIsValid = true;
            this.setState({
                gwebsite_error_text: null
            });
        } else {
            if (this.validateGoogle(this.state.form_data.google)) {
                urlIsValid = true;
                this.setState({
                    gwebsite_error_text: null
                });
            }
            else {
                this.setState({
                    gwebsite_error_text: "Sorry, this is not a valid format"
                });
            }
        }
        return urlIsValid;
    }

    validateYoutube(value) {
        var exp = /(?:(?:http|https):\/\/)?(?:www\.)?(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))((\w|-){11})(?:\S+)?$/;
        ;
        return exp.test(value);
    }

    isDisabledYoutube() {
        let urlIsValid = false;
        if (this.state.form_data.youtube === "" || this.state.form_data.youtube === null || this.state.form_data.youtube === undefined) {
            urlIsValid = true;
            this.setState({
                ywebsite_error_text: null
            });
        } else {
            if (this.validateYoutube(this.state.form_data.youtube)) {
                urlIsValid = true;
                this.setState({
                    ywebsite_error_text: null
                });
            }
            else {
                this.setState({
                    ywebsite_error_text: "Sorry, this is not a valid format"
                });
            }
        }
        return urlIsValid;
    }

    validateRadio() {
        let valid = false;
        if (this.state.form_data.exist_gender === "" || this.state.form_data.exist_gender === null || this.state.form_data.exist_gender === undefined) {
            this.setState({
                radio_error_text: "Required"
            });
        } else {
            valid = true
            this.setState({
                radio_error_text: null
            })

        }
        return valid;
    }

    validateDate() {
        let valid = false;
        if (this.state.form_data.exist_dob === null || this.state.form_data.exist_dob === "") {
            this.setState({
                exist_dob_error_text: "Required"
            });
        } else {
            valid = true;
            this.setState({
                exist_dob_error_text: null
            })

        }
        return valid;
    }

    changeProfileUrl() {
        var userid = this.state.user_id;
        var keyword = this.state.form_data.profile_url;
        var param = {action: 'changeUrl', user_id: userid, keywords: keyword}
        var formState = this;
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                formState.setState({ open: false})
            }
        });
    }

    submitdata(e) {

        e.preventDefault();
        if (!(this.commonValidate() && this.commonValidate1() && this.commonValidate3()
                && this.validateSelect() && this.validateSelectlang1() && this.validateSelectlang2() && this.validateSelect1() && this.validateSelect2()
                && this.isDisabledFacebook() && this.isDisabledTwitter() && this.isDisabledInsta() && this.isDisabledGoogle()
                && this.isDisabledYoutube() && this.isDiasbleWiki() && this.isDisabledphone() && this.validateDate()
                && this.validateRadio()
            )) {
            this.commonValidate();
            this.commonValidate1();

            this.commonValidate3();
            this.validateSelect();
            this.validateSelectlang1();
            this.validateSelectlang2();
            this.validateSelect1();
            this.validateSelect2();
            this.isDisabledFacebook();
            this.isDisabledTwitter();
            this.isDisabledInsta();
            this.isDisabledGoogle();
            this.isDisabledYoutube();
            this.isDiasbleWiki();
            this.isDisabledphone();
            this.validateDate();
            this.validateRadio();

            return;
        }

        var userid = this.state.user_id;
        this.state.form_data.action = 'set_basic_profile';
        if (this.state.media_id != null || this.state.media_id != "") {
            this.state.form_data.media_id = this.state.media_id;
        }
        this.state.form_data.user_id = userid;
        var param = this.state.form_data;
        var local = this;
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                local.setState({
                    resultDialogOpen: true,
                    resultMessage: data.message
                });

            }

        })

    }

    handleChange(name, e) {
        var change = {};
        change.form_data = this.state.form_data;
        change.form_data[name] = e.target.value;
        this.setState(change);
    }

    formatDate(date) {
        var dd = date.getDate();
        var mm = date.getMonth() + 1;
        var yyyy = date.getFullYear();
        if (dd < 10) {
            dd = '0' + dd
        }
        if (mm < 10) {
            mm = '0' + mm
        }
        var dob = dd + '/' + mm + '/' + yyyy;
        return dob;
    }

    handleScheduleChange = (event, date) => {
        var change = {};
        change.form_data = this.state.form_data;
        change.form_data["exist_dob"] = date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate();
        this.setState(change);
        this.validateDate();
    }

    handleChangeradio(event:object, value:string) {
        var change = {};
        change.form_data = this.state.form_data;
        change.form_data['exist_gender'] = value;
        this.setState(change);
        this.validateRadio();

    }

    handleOptionChange(name, event, index, value) {
        var change = {};
        change.form_data = this.state.form_data;
        change.form_data[name] = value;
        this.setState(change);
        if (name == 'country') {
            var statesdatas = {action: 'get_states', country: value};
            $.ajax({
                url: API_URL,
                type: "POST",
                dataType: 'json',
                data: statesdatas,
                success: function (data) {
                    change = {};
                    change.form_data = this.state.form_data;
                    change.form_data["city"] = "";
                    change.form_data["state"] = "";
                    change.citydata = [];
                    if (!data.states) {
                        change.statesdata = [];
                    } else {
                        change.statesdata = data.states;
                    }
                    this.setState(change);
                    this.validateSelect();
                    this.validateSelect1();
                    this.validateSelect2();
                }.bind(this),


            });
        }
        if (name == 'primary_language') {
            this.validateSelectlang1();
        }
        if (name == 'secondary_language') {
            this.validateSelectlang2();
        }
        if (name == 'city') {
            this.validateSelect2();
        }
        if (name === 'state') {

            var citydatas = {action: 'get_cities', state: value};
            $.ajax({
                url: API_URL,
                type: "POST",
                dataType: 'json',
                data: citydatas,
                success: function (data) {
                    change = {};
                    change.form_data = this.state.form_data;
                    change.form_data["city"] = "";
                    if (!data.cities) {
                        change.citydata = [];
                    } else {
                        change.citydata = data.cities;
                    }
                    this.setState(change);
                    this.validateSelect1();
                    this.validateSelect2();
                }.bind(this)

            });

        }

    }

    handleOpen() {
        this.setState({open: true});
    }

    handleClose = () => {
        this.setState({open: false});
    };

    _crop(e) {
    }

    uploadImage() {
        this.setState({picState: 1});
        var cropperDAta = this.refs.cropper.getCroppedCanvas().toDataURL();
        this.setState({croperstate: false, uploadingImg: cropperDAta, photoUrl: ''});
        var formState = this;
        var userid = formState.state.user_id;
        var params1 = {action: 'images', prof_ref: 'basic_profile', userId: userid, file: cropperDAta}
        util.getSetData(params1, function (data) {

            if (data.status == "success") {
                formState.setState({
                    media_id: data.media_id,
                    IMGSrc: '',
                    picState: 2
                });
            }
            else {
                formState.setState({picState: 3, Message:data.message});
            }
        });
    }

    RotateR() {
        this.refs.cropper.rotate(90);
    }

    RotateL() {
        this.refs.cropper.rotate(-90);
    }

    handleCOpen = () => {
        this.setState({croperstate: true});
    };

    handleCClose = () => {
        this.setState({croperstate: false});
    };

    removeImg() {
        this.setState({uploadingImg: '', picState: 0})
    }

    retryImage(e) {
        if (e === 3) {
            this.setState({picState: 1});
            var formState = this;
            var userid = formState.state.user_id;
            var params1 = {action: 'images', prof_ref: 'basic_profile', userId: userid, file: this.state.IMGSrc}
            util.getSetData(params1, function (data) {
                if (data.status == "success") {
                    formState.setState({IMGSrc: '', picState: 2});
                }
                else {
                    formState.setState({picState: 3});
                }
            });
        }
    }

    render() {
        return (
            <section className="inner_page">
                <div className="pageloader"><img src="http://kalakar.pro:90/kalakar/demo/other/assets/img/loader.svg"/></div>
                <div className="basic_profile">
                    <div className="container">
                        <div className="basic_profile_inner">

                            <div className="row">
                                <div className="col-xs-12 btn_inline_view">
                                    <h2 className="h1_btn">Basic Profile</h2>
                                     <span className="lightgallery-single-video">
                                         <li className="video" data-src="https://www.youtube.com/watch?v=61F5ZdHDdns&feature=youtu.be">
                                             <button type="button" className=" btn video_assist_btn">Video Assist <i className="fa fa-play-circle"></i></button>
                                         </li>
                                     </span>
                                </div>
                            </div>
                            <Dialog title="Upload Image" modal={true} open={this.state.croperstate}
                                    className="croperPopup" autoScrollBodyContent={false}>
                                <button onClick={this.uploadImage.bind(this)} className="uploadBtnCrop"><span
                                    className="fa fa-check"></span></button>
                                <p>(min size 300px X 200px)</p>
                                <Cropper
                                    ref='cropper'
                                    src={this.state.IMGSrc}
                                    style={{height: 385, width: '100%'}}
                                    autoCropArea={0.97}
                                    guides={false}
                                    />

                              <span className="RotateBtnCropOuter">
                                <button title='Rotate Left' onClick={this.RotateL.bind(this)} className="RotateBtnCrop">
                                    <span className="fa fa-rotate-left"></span></button>
                                <button title='Rotate Right' onClick={this.RotateR.bind(this)}
                                        className="RotateBtnCrop"><span className="fa fa-rotate-right"></span></button>
                              </span>
                                <RaisedButton className="cancelBtnPopup" primary={true} onTouchTap={this.handleCClose}
                                              label="X"/>
                            </Dialog>

                            <div className="row">
                                <div className="col-sm-6 col-xs-12">
                                    <div className="row">
                                        <div className="col-xs-12 ">
                                            <div className="proPic">
                                                <div
                                                    className={(this.state.picState==1)? 'ajax_loading_loader_image':(this.state.picState==3)? 'ajax_retry':(this.state.picState==2)?'ajax_complete':''}
                                                    onClick={this.retryImage.bind(this, this.state.picState)}></div>
                                                {(this.state.picState !== 3) ? <input type="file" id="file"
                                                                                      onChange={this.handleImageChange.bind(this)}
                                                                                      placeholder="Upload Profile photo"/> : ''}
                                                <a href="javascript:void(0)" className="fa fa-times"
                                                   onClick={this.removeImg.bind(this)}></a>
                                                <i className="fa falast_name-pencil"></i>
                                                <span><img
                                                    src={(this.state.photoUrl!=='')? this.state.photoUrl: this.state.uploadingImg}/> {(this.state.uploadingImg == '') ?
                                                    <em>Upload Profile photo</em> : ''}</span>
                                            </div>
                                            <div style={{position: 'relative', bottom: '2px', fontSize: '12px', lineHeight: '12px', color: 'rgb(244, 67, 54)', transition: 'all 450ms cubic-bezier(0.23, 1, 0.32, 1) 0ms'}}>{this.state.Message}</div>
                                        </div>
                                        <div className="col-xs-12 inputSocial OtherInputBasic">
                                            <TextField
                                                id="text-field1"
                                                hintText="First Name"
                                                hintStyle={{color:'#ccc', paddingLeft:'5px',fontSize:'14px',lineHeight: '26px'}}
                                                //floatingLabelText="First Name"
                                                floatingLabelFixed={false}
                                                fullWidth={true}
                                                errorText={this.state.firstName_error_text}
                                                value={this.state.form_data.first_name}
                                                onBlur={this.commonValidate.bind(this, 'first_name')}
                                                onChange={this.handleChange.bind(this,'first_name')}
                                                />
                                        </div>
                                        <div className="col-xs-12 inputSocial OtherInputBasic">
                                            <TextField
                                                id="text-field2"
                                                hintText="Middle Name"
                                                hintStyle={{color:'#ccc', paddingLeft:'5px',fontSize:'14px',lineHeight: '26px'}}
                                                //floatingLabelText="Middle Name"
                                                floatingLabelFixed={false}
                                                fullWidth={true}
                                                value={this.state.form_data.middle_name}
                                                onChange={this.handleChange.bind(this,'middle_name')}
                                                />
                                        </div>
                                        <div className="col-xs-12 inputSocial OtherInputBasic">
                                            <TextField
                                                id="text-field3"
                                                hintText="last Name"
                                                hintStyle={{color:'#ccc', paddingLeft:'5px',fontSize:'14px',lineHeight: '26px'}}
                                                //  floatingLabelText="Last Name"
                                                floatingLabelFixed={false}
                                                fullWidth={true}
                                                errorText={this.state.lastName_error_text}
                                                value={this.state.form_data.last_name}
                                                onBlur={this.commonValidate1.bind(this, 'last_name')}
                                                onChange={this.handleChange.bind(this,'last_name')}
                                                />
                                        </div>
                                        <div className="col-xs-12 inputSocial OtherInputBasic">
                                            <TextField
                                                id="text-field4"
                                                hintText="Email"
                                                //  floatingLabelText="Email"
                                                floatingLabelFixed={false}
                                                fullWidth={true}
                                                value={this.state.form_data.email}
                                                onChange={this.handleChange.bind(this,'email')}
                                                disabled/>

                                        </div>

                                        <div className="col-xs-12">
                                            <div className="prof_radio">
                                                <label className="labbelRadio">Gender</label>
                                                <RadioButtonGroup name="shipSpeed" defaultSelected="not_light"
                                                                  onChange={this.handleChangeradio.bind(this)}
                                                                  onBlur={this.validateRadio.bind(this)}
                                                                  valueSelected={this.state.form_data.exist_gender}
                                                                  disabled>
                                                    <RadioButton value="male" label="Male"
                                                                 className="basicproRadio"/>
                                                    <RadioButton value="female" label="Female"
                                                                 className="basicproRadio"/>
                                                    <RadioButton value="other" label="Other"
                                                                 className="basicproRadio"/>
                                                </RadioButtonGroup>
                                                <small className="errorMsg">{this.state.radio_error_text}</small>
                                            </div>
                                        </div>
                                        <div className="col-xs-12 inputSocial OtherInputBasic">
                                            <DatePicker hintText="Date of Birth"
                                                        hintStyle={{color:'#ccc', paddingLeft:'5px',fontSize:'14px',lineHeight: '26px'}}
                                                //floatingLabelText="Date of Birth"
                                                        floatingLabelFixed={false}
                                                        fullWidth={true}
                                                        disabled={false}
                                                        value={(this.state.form_data.exist_dob == "" ||this.state.form_data.exist_dob == null)?"":new Date(this.state.form_data.exist_dob)}
                                                        autoOk={true}
                                                        onChange={this.handleScheduleChange.bind(this)}
                                                        onBlur={this.validateDate.bind(this)}
                                                        errorText={this.state.exist_dob_error_text}
                                                        formatDate={this.formatDate.bind(this)}
                                                />
                                        </div>
                                        <div className="col-xs-12">
                                            <div className="filter">
                                                <SelectField value={this.state.form_data.country}
                                                             onChange={this.handleOptionChange.bind(this,'country')}
                                                             maxHeight={180} fullWidth={true}
                                                             errorText={this.state.country_error_text}
                                                    >
                                                    <MenuItem value="" primaryText="Select Country"/>
                                                    {this.state.countrys.map(c =>
                                                            <MenuItem value={c.country_id} key={c.country_name}
                                                                      primaryText={c.country_name}/>
                                                    )}
                                                </SelectField>

                                            </div>

                                        </div>
                                        <div className="col-xs-12">
                                            <div className="filter">
                                                <SelectField value={this.state.form_data.state}
                                                             onChange={this.handleOptionChange.bind(this,'state')}
                                                             maxHeight={180} fullWidth={true}
                                                             errorText={this.state.state_error_text}>
                                                    <MenuItem value={this.state.form_data.state}
                                                              primaryText="Select State"/>
                                                    {this.state.statesdata.map(s =>
                                                            <MenuItem value={s.state_id} key={s.state_name}
                                                                      primaryText={s.state_name}/>
                                                    )}
                                                </SelectField>
                                            </div>
                                        </div>
                                        <div className="col-xs-12">
                                            <div className="filter">
                                                <SelectField value={this.state.form_data.city}
                                                             onChange={this.handleOptionChange.bind(this,'city')}
                                                             errorText={this.state.city_error_text}
                                                             maxHeight={180} fullWidth={true}>
                                                    <MenuItem value={this.state.form_data.city}
                                                              primaryText="Select City"/>
                                                    {this.state.citydata.map(c =>
                                                            <MenuItem value={c.city_id} key={c.city_id}
                                                                      primaryText={c.city_name}/>
                                                    )}
                                                </SelectField>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div className="col-sm-6 col-xs-12">
                                    <div className="row">

                                        <div className="col-xs-12 inputSocial OtherInputBasic">
                                            <TextField
                                                id="text-field6"
                                                hintText="Phone Number "
                                                hintStyle={{color:'#ccc', paddingLeft:'5px',fontSize:'14px',lineHeight: '26px'}}
                                                //floatingLabelText="Phone Number"
                                                floatingLabelFixed={false}
                                                fullWidth={true}
                                                value={this.state.form_data.exist_phone}

                                                onChange={this.handleChange.bind(this,'exist_phone')}

                                                disabled />

                                        </div>

                                        <div className="col-xs-12 inputSocial OtherInputBasic">
                                            <TextField
                                                id="text-field7"
                                                hintText="Company Name "
                                                hintStyle={{color:'#ccc', paddingLeft:'5px',fontSize:'14px',lineHeight: '26px'}}
                                                //floatingLabelText="Company Name"
                                                floatingLabelFixed={false}
                                                fullWidth={true}
                                                value={this.state.form_data.company_name}
                                                onChange={this.handleChange.bind(this,'company_name')}
                                                />

                                        </div>
                                        <div className="col-xs-12">
                                            <div className="filter">

                                                <SelectField value={this.state.form_data.primary_language}
                                                             onChange={this.handleOptionChange.bind(this,'primary_language')}
                                                             maxHeight={200} fullWidth={true}
                                                             errorText={this.state.primary_language_text}
                                                    >
                                                    <MenuItem value={null} primaryText="Primary Language"/>
                                                    {this.state.lang.map(l => <MenuItem value={l.language_name}
                                                                                        key={l.language_name}
                                                                                        primaryText={l.language_name}/>
                                                    )}
                                                </SelectField>

                                            </div>
                                        </div>
                                        <div className="col-xs-12">
                                            <div className="filter">
                                                <SelectField value={this.state.form_data.secondary_language}
                                                             onChange={this.handleOptionChange.bind(this,'secondary_language')}
                                                             maxHeight={200} fullWidth={true}
                                                             errorText={this.state.secondary_language_text}
                                                    >
                                                    <MenuItem value={null} primaryText="Secondary Language"/>
                                                    {this.state.lang.map(l => <MenuItem value={l.language_name}
                                                                                        key={l.language_name}
                                                                                        primaryText={l.language_name}/>
                                                    )}
                                                </SelectField>

                                            </div>
                                        </div>

                                        <div className="col-xs-12 inputSocial OtherInputBasic">
                                            <TextField
                                                id="text-field8"
                                                hintText="Pincode "
                                                hintStyle={{color:'#ccc', paddingLeft:'5px',fontSize:'14px',lineHeight: '26px'}}
                                                //floatingLabelText="Pincode"
                                                floatingLabelFixed={false}
                                                fullWidth={true}
                                                fullWidth={true}
                                                errorText={this.state.pincode_error_text}
                                                onBlur={this.commonValidate3.bind(this,'zip_code')}
                                                value={this.state.form_data.zip_code}
                                                onChange={this.handleChange.bind(this,'zip_code')}
                                                />
                                        </div>


                                        <div className="col-xs-12 inputSocial">
                                            <TextField
                                                id="text-field9"
                                                placeholder= "http://www.facebook.com/example"
                                                fullWidth={true}
                                                value={this.state.form_data.facebook}
                                                onChange={this.handleChange.bind(this,'facebook')}
                                                onBlur={this.isDisabledFacebook.bind(this)}
                                                errorText={this.state.fwebsite_error_text}/>

                                            <i className="fa fa-facebook" aria-hidden="true"></i>

                                        </div>
                                        <div className="col-xs-12 inputSocial">
                                            <TextField
                                                id="text-field10"
                                                placeholder= "http://www.twitter.com/example"
                                                fullWidth={true}
                                                value={this.state.form_data.twitter}
                                                onChange={this.handleChange.bind(this,'twitter')}
                                                onBlur={this.isDisabledTwitter.bind(this)}
                                                errorText={this.state.twebsite_error_text}/>
                                            <i className="fa fa-twitter" aria-hidden="true"></i>
                                        </div>
                                        <div className="col-xs-12 inputSocial  ">
                                            <TextField
                                                id="text-field11"
                                                placeholder= "http://www.instagram.com/example"
                                                fullWidth={true}
                                                value={this.state.form_data.instagram}
                                                onChange={this.handleChange.bind(this,'instagram')}
                                                onBlur={this.isDisabledInsta.bind(this)}
                                                errorText={this.state.iwebsite_error_text}
                                                />
                                            <i className="fa fa-instagram" aria-hidden="true"></i>
                                        </div>

                                        <div className="col-xs-12 inputSocial">
                                            <TextField
                                                id="text-field12"
                                                placeholder= "http://plus.google.com/example"
                                                fullWidth={true}
                                                value={this.state.form_data.google}
                                                onChange={this.handleChange.bind(this,'google')}
                                                onBlur={this.isDisabledGoogle.bind(this)}
                                                />
                                            <small className="errorMsg">{this.state.gwebsite_error_text}</small>
                                            <i className="fa fa-google-plus" aria-hidden="true"></i>

                                        </div>
                                        <div className="col-xs-12 inputSocial">
                                            <TextField
                                                id="text-field10"
                                                placeholder= "http://www.wikipedia.com/example"
                                                fullWidth={true}
                                                value={this.state.form_data.wikipedia}
                                                onChange={this.handleChange.bind(this,'wikipedia')}
                                                errorText={this.state.wikiwebsite_error_text}
                                                onBlur={this.isDiasbleWiki.bind(this)}
                                                />
                                            <i className="fa fa-wikipedia-w" aria-hidden="true"></i>
                                        </div>

                                        <div className="col-xs-12 inputSocial">
                                            <TextField
                                                id="text-field10"
                                                placeholder="https://www.youtube.com/example"
                                                fullWidth={true}
                                                value={this.state.form_data.youtube}
                                                onChange={this.handleChange.bind(this,'youtube')}
                                                onBlur={this.isDisabledYoutube.bind(this)}
                                                errorText={this.state.ywebsite_error_text}
                                                />
                                            <i className="fa fa-youtube" aria-hidden="true"></i>

                                        </div>
                                        <div className="col-xs-12 inputSocial">
                                            <TextField
                                                id="text-field10"
                                                placeholder="Mobile number"
                                                fullWidth={true}
                                                value={decodeURIComponent(this.state.form_data.watsapp)}
                                                onChange={this.handleChange.bind(this,'watsapp')}
                                                errorText={this.state.phone_error_text}
                                                onBlur={this.isDisabledphone.bind(this)}
                                                />
                                            <i className="fa fa-whatsapp" aria-hidden="true"></i>

                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="row">
                                <div className="col-xs-12 rightAligh">
                                    <button className="btn btn_profile2" onClick={this.handleOpen.bind(this)}> Change
                                        Profile URL
                                    </button>
                                    <button type="button" className="btn btn_profile"
                                            onClick={this.submitdata.bind(this)}
                                        >Save
                                    </button>

                                </div>
                            </div>

                        </div>
                    </div>
                    <Dialog modal={false} open={this.state.open} onRequestClose={this.handleClose}
                            autoScrollBodyContent={true}>
                        <div style={{textAlign:"center"}}>
                            <p className="changeProfileUrlHead">CREATE YOUR PERSONAL KALAKAR URL</p><br />
                            <div className="changeProfileUrlInput">
                            <input id="profile_url" type="text"
                                   value={this.state.kalakar +this.state.form_data.full_name +'/'} disabled/>
                            <input id="profile_url" type="text"
                                   onChange={this.handleChange.bind(this,'profile_url')}
                                   value={this.state.form_data.profile_url}/>
                              </div>
                            <br /><br />
                            <RaisedButton className="profileEditbtn" primary={true} label="Save"
                                          onClick={this.changeProfileUrl.bind(this)}/>
                            <RaisedButton className="cancelBtnPopup" onTouchTap={this.handleClose.bind(this)}
                                          primary={true} label="X"/>
                        </div>
                    </Dialog>
                    <ResultMsg open={this.state.resultDialogOpen} title="Delete Tag"
                               body={this.state.resultMessage} openState={this} redDirect={true} dashboard={this.redirectDashboard.bind(this)} />

                </div>

            </section>

        );
    }
}
EditBasicProfile.propTypes = {
    changeRoute: React.PropTypes.func,
};

function mapDispatchToProps(dispatch) {
    return {
        changeRoute: (url) => dispatch(push(url)),
    };
}
export default connect(null, mapDispatchToProps)(EditBasicProfile);
//export default EditBasicProfile;
