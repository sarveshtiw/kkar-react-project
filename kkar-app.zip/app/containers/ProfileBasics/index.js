import React from 'react';
import {DashboardMenu} from 'components/DashboardMenu'
import TextField from 'material-ui/TextField';
var util = require('utils/request');
import Img from 'components/Img';
import cookie from 'react-cookie';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import {ProgressSlider} from 'components/ProgressSlider';
import Cropper from 'react-cropper';
import Dialog from 'material-ui/Dialog';
import RaisedButton from 'material-ui/RaisedButton';
 //<li><a href="#" data-color="ff8b00" onClick={this.colorChange.bind(this,'ff8b00')}></a></li>
// <li><a href="#" data-color="ff4143" onClick={this.colorChange.bind(this,'ff4143')}></a></li>
 //<li><a href="#" data-color="ff6600" onClick={this.colorChange.bind(this,'ff6600')}></a></li>


export class ProfileBasics extends React.Component {

  openRoute = (route) => {
      this.props.changeRoute(route);
  };

  constructor(props) {
      super(props);
      this.state = {
         croperstate:false,
         stateUpdate:false,
         form_data : {
          user_id:cookie.load('userId'),
         profileId : this.props.params.profileId,
          profile_color : "",
          workrate : 0,
          category_id : "",
          media_id : "",
          photo_path : "",
             profileUrl : "",
          color: "",
          Message:'',
          profile_color : "",
          profile_image : "",
          IMGSrc: '',
          uploadingImg:'',
          picState:0,
      }
      }
 }

componentDidMount() {
    $('#videos').trigger('click');
    jQuery('#lightgallery').lightGallery();
    jQuery('.lightgallery-single-image').lightGallery();
    jQuery('.lightgallery-single-video').lightGallery();
    jQuery('.videos-for-album').lightGallery();
    jQuery('#videos-without-poster').lightGallery();
    jQuery('#videos-without-poster2').lightGallery();
    jQuery('.album_box_tabcontainer').find('.album_box').children('a').click(function () {
        jQuery(this).siblings('.demo-gallery').children('ul').children('li').first().children('a').trigger('click');
    });
  document.title = "Extended Profile | Kalakar";
  $('[data-toggle="tooltip"]').tooltip();
  $('.swatches li').each(function(index) {
	 	var clr = $(this).find('a').attr('data-color');
		$(this).find('a').css({'background': '#'+clr});
	});

      var formState = this;
      var change = {};
      change.form_data = this.state.form_data;
      var param = {action:'extended_basic_get',profile_id : this.props.params.profileId, user_id: this.state.form_data.user_id}
      util.getSetData(param,function (data) {
      if(data.status == "success"){
         var result = data.data;
         if(result.profile_color == ""){
           result.profile_color = "d01d15"}
         change.form_data["category_id"] = result.category_id;
         change.form_data["workrate"] = result.workrate;
         change.form_data["photo_path"] = (result.photo_path=='' || result.photo_path===null)? (require('./user-profile.png')): result.photo_path;
         change.form_data["media_id"] = result.photo;
         change.form_data["profile_color"] = result.profile_color;
         change.form_data["profile_image"] = (require('./img/' + result.profile_color +'.jpg'));
         change.form_data["profileUrl"] = data.profile_url;
         formState.setState(change);
         formState.setState({uploadingImg:(result.photo_path=='' || result.photo_path===null)? (require('./user-profile.png')): result.photo_path})
      }
      else{
          alert("Please try again.");
      }
    });
}
_crop(e){
 }
uploadImage(){

var cropperDAta = this.refs.cropper.getCroppedCanvas().toDataURL();
this.setState({picState:1,croperstate:false, uploadingImg:cropperDAta});
var formState = this;
var params = {action:'images',profile_id : this.props.params.profileId, user_id: this.state.user_id, file: cropperDAta}
util.getSetData(params, function (data) {
  if(data.status == "success"){
formState.setState({IMGSrc:'',  picState:2})
     }
     else {
       formState.setState({picState:3, Message:data.message});
     }

 });

 }
 retryImage(e){
   if(e===3)
   {
   this.setState({picState:1});
   var formState = this;
   var userid = formState.state.user_id;
   var params1 = {action:'images', prof_ref:'basic_profile', userId: userid, file:this.state.IMGSrc}
   util.getSetData(params1, function (data) {
   if(data.status == "success"){
   formState.setState({IMGSrc:'',picState:2});
      }
      else {
        formState.setState({picState:3});
      }
    });
   }
 }

RotateR(){
this.refs.cropper.rotate(90);
}

RotateL(){
this.refs.cropper.rotate(-90);
}

removeImg(){
this.setState({uploadingImg:'', picState:0})
}
handleImageChange (e) {
 e.preventDefault();
let reader = new FileReader();
let file = e.target.files[0];
reader.onloadend = () => {
  this.setState({croperstate:true, IMGSrc:reader.result});
  };
reader.readAsDataURL(file);

           }

colorChange(data){
  var imgSrc = require('./img/'+data+'.jpg');
  var change = {};
  change.form_data = this.state.form_data;
  change.form_data["profile_color"] = data;
  change.form_data["profile_image"] = imgSrc;
  this.setState(change);
}

handleChange(name, e) {
  var change = {};
  change.form_data = this.state.form_data;
  change.form_data[name] = e.target.value;
  this.setState(change);
}

submitData() {
  var p_id = this.props.params.profileId;
   this.state.form_data.action = 'extended_basic_set';
   this.state.form_data.user_id = this.state.form_data.user_id;
   this.state.form_data.profile_id = p_id;
  //  this.state.form_data.profileUrl=this.state.form_data.profileUrl;
   var formState = this;
   util.getSetData(formState.state.form_data,function (data) {
     if(data.status == "success"){
         formState.state.stateUpdate = true;
        //browserHistory.push('/my-accounts/extended-profile/'+ p_id +'/training');
        formState.props.changeRoute('/my-accounts/extended-profile/'+ p_id +'/details');
        }
        else{
           alert("Please fill Manadatory fields.");
        }
    });
}
handleCClose = () => {
  this.setState({croperstate: false});
};
    onCLick(){
        $('#videos').trigger('click');

    }
render() {
    var updateState = false;
    if(this.state.stateUpdate)
    {
        updateState = true;
        this.state.stateUpdate = false;
    }
    jQuery('#lightgallery').lightGallery();
    jQuery('.lightgallery-single-image').lightGallery();
    jQuery('.lightgallery-single-video').lightGallery();
    jQuery('.videos-for-album').lightGallery();
    jQuery('#videos-without-poster').lightGallery();
    jQuery('#videos-without-poster2').lightGallery();
    jQuery('.album_box_tabcontainer').find('.album_box').children('a').click(function () {
        jQuery(this).siblings('.demo-gallery').children('ul').children('li').first().children('a').trigger('click');
    });

    return (
    <div>
      <section className="inner-page basic-profile">
          <DashboardMenu page="ProfileBasic" profileId = {this.props.params.profileId}/>

          <div className="pageRest cell">
                   <div className="basic-profile-inner">
                      <div className="row">
                          <div className="col-sm-6 ">
                           <div className="btn_inline_view">
                          	<h1 className="h1_btn">Profile Basics</h1>
                            <span className="lightgallery-single-video">
                             <li className="video" data-src="https://www.youtube.com/watch?v=dRR_g14jXK0&feature=youtu.be">
                                 <button type="button" className=" btn video_assist_btn">Video Assist <i className="fa fa-play-circle"></i></button>
                             </li></span>

                           </div>
                          </div>
                          <div className="col-sm-6">
                          	<h3>Step 1/14</h3>
                          </div>

                          <Dialog title="Upload Image" modal={true} open={this.state.croperstate} className="croperPopup" autoScrollBodyContent={false}>
                              <button onClick={this.uploadImage.bind(this)} className="uploadBtnCrop"><span className="fa fa-check"></span></button>
                              <p>(min size 300px X 200px)</p>

                              <Cropper
                              ref='cropper'
                              src={this.state.IMGSrc}
                              style={{height: 400, width: '100%'}}
                              aspectRatio={16 / 9}
                              autoCropArea={0.97}
                              guides={false}
                              crop={this._crop.bind(this)} />
                              <span className="RotateBtnCropOuter">
                                <button title='Rotate Left' onClick={this.RotateL.bind(this)} className="RotateBtnCrop"><span className="fa fa-rotate-left"></span></button>
                                <button title='Rotate Right' onClick={this.RotateR.bind(this)} className="RotateBtnCrop"><span className="fa fa-rotate-right"></span></button>
                              </span>
                              <RaisedButton className="cancelBtnPopup" primary={true} onTouchTap={this.handleCClose} label="X"/>
                              </Dialog>

                      <div className="row">
                        <div className="col-xs-12">
                          <div className="col-md-4 col-sm-12 col-xs-12">
                              <div className="row">
                                  <div className="col-xs-12">
                                      <div className="proPic">
                                          <div className={(this.state.picState==1)? 'ajax_loading_loader_image':(this.state.picState==3)? 'ajax_retry':(this.state.picState==2)?'ajax_complete':''} onClick={this.retryImage.bind(this, this.state.picState)}></div>
                                          {(this.state.picState!==3)?<input type="file" id="file"  onChange={this.handleImageChange.bind(this)} placeholder="Upload Profile photo"/>:''}
                                          <a href="javascript:void(0)" className="fa fa-times" onClick={this.removeImg.bind(this)}></a>
                                          <i className="fa fa-pencil"></i>
                                          <span><img src={this.state.uploadingImg}/> {(this.state.uploadingImg=='') ? <em>Upload Profile photo</em> : ''} </span>
                                      </div>
                                  </div>
                               </div>
                               <div style={{position: 'relative', bottom: '2px', fontSize: '12px', lineHeight: '12px', color: 'rgb(244, 67, 54)', transition: 'all 450ms cubic-bezier(0.23, 1, 0.32, 1) 0ms'}}>{this.state.Message}</div>

                          </div>
                          <div className="col-md-8 col-sm-12 col-xs-12">
                              <div className="row">
                                  <div className="col-xs-12 lastCol profession1">
                                      <label>Profile URL</label>
                                        <input id="profileurl"  type="text" placeholder value={this.state.form_data.profileUrl}  onChange={this.handleChange.bind(this,'profileUrl')}/>
                                        <i className="fa fa-info" data-toggle="tooltip" title="Profile URL"></i>
                                  </div>

                                  <div className="col-xs-12">
                                      <label>Avg Professional Fee</label>
                                      <div className="row">
                                          <div className="col-xs-12 lastCol">
                                          <input type="number" min="0" placeholder="Rs/Day" id="workrate"  value={this.state.form_data.workrate}
                                            onChange={this.handleChange.bind(this,'workrate')} />
                                              <i className="fa fa-info" data-toggle="tooltip" title="Work Rate"></i>
                                          </div>
                                      </div>
                                  </div>
                               </div>
                          </div>
                        </div>
                     </div>

                     <div className="row">
                       <div className="col-xs-12">
                         <div className="col-md-8 col-sm-12 col-xs-12">
                           <h4>Profile Color Demo</h4>
                           <div className="samplePorfile">
                           <Img src={this.state.form_data.profile_image} width="584" height="314" alt="Sample Profile" id="sampleProfileImg"/>
                           </div>
                         </div>

                         <div className="col-md-4 col-sm-12 col-xs-12">
                           <h4>Choose Color</h4>
                           <ul className="swatches">
                           	<li><a href="#" data-color="00a64e" onClick={this.colorChange.bind(this,'00a64e')}></a></li>
                           	<li><a href="#" data-color="00aa9d" onClick={this.colorChange.bind(this,'00aa9d')}></a></li>
                           	<li><a href="#" data-color="00b5f3" onClick={this.colorChange.bind(this,'00b5f3')}></a></li>
                           	<li><a href="#" data-color="1b1e27" onClick={this.colorChange.bind(this,'1b1e27')}></a></li>
                           	<li><a href="#" data-color="1bbab4" onClick={this.colorChange.bind(this,'1bbab4')}></a></li>

                           	<li><a href="#" data-color="002f5b" onClick={this.colorChange.bind(this,'002f5b')}></a></li>
                           	<li><a href="#" data-color="2c3094" onClick={this.colorChange.bind(this,'2c3094')}></a></li>
                           	<li><a href="#" data-color="2e0726" onClick={this.colorChange.bind(this,'2e0726')}></a></li>
                           	<li><a href="#" data-color="2f0827" onClick={this.colorChange.bind(this,'2f0827')}></a></li>
                           	<li><a href="#" data-color="3a2512" onClick={this.colorChange.bind(this,'3a2512')}></a></li>

                           	<li><a href="#" data-color="3b1e00" onClick={this.colorChange.bind(this,'3b1e00')}></a></li>
                           	<li><a href="#" data-color="3b91dc" onClick={this.colorChange.bind(this,'3b91dc')}></a></li>
                           	<li><a href="#" data-color="3c6070" onClick={this.colorChange.bind(this,'3c6070')}></a></li>
                           	<li><a href="#" data-color="3e0c27" onClick={this.colorChange.bind(this,'3e0c27')}></a></li>
                           	<li><a href="#" data-color="004b8f" onClick={this.colorChange.bind(this,'004b8f')}></a></li>

                           	<li><a href="#" data-color="5a6060" onClick={this.colorChange.bind(this,'5a6060')}></a></li>
                           	<li><a href="#" data-color="5b8428" onClick={this.colorChange.bind(this,'5b8428')}></a></li>
                           	<li><a href="#" data-color="5e0000" onClick={this.colorChange.bind(this,'5e0000')}></a></li>
                           	<li><a href="#" data-color="5e5a57" onClick={this.colorChange.bind(this,'5e5a57')}></a></li>
                           	<li><a href="#" data-color="6e7376" onClick={this.colorChange.bind(this,'6e7376')}></a></li>

                           	<li><a href="#" data-color="7e8aa4" onClick={this.colorChange.bind(this,'7e8aa4')}></a></li>
                           	<li><a href="#" data-color="8a1856" onClick={this.colorChange.bind(this,'8a1856')}></a></li>
                           	<li><a href="#" data-color="8d6239" onClick={this.colorChange.bind(this,'8d6239')}></a></li>
                           	<li><a href="#" data-color="8e8e8e" onClick={this.colorChange.bind(this,'8e8e8e')}></a></li>
                           	<li><a href="#" data-color="8f441c" onClick={this.colorChange.bind(this,'8f441c')}></a></li>

                           	<li><a href="#" data-color="8fc83e" onClick={this.colorChange.bind(this,'8fc83e')}></a></li>
                           	<li><a href="#" data-color="9a96a4" onClick={this.colorChange.bind(this,'9a96a4')}></a></li>
                           	<li><a href="#" data-color="9a8874" onClick={this.colorChange.bind(this,'9a8874')}></a></li>
                           	<li><a href="#" data-color="9f0038" onClick={this.colorChange.bind(this,'9f0038')}></a></li>
                           	<li><a href="#" data-color="0055a9" onClick={this.colorChange.bind(this,'0055a9')}></a></li>

                           	<li><a href="#" data-color="0070dc" onClick={this.colorChange.bind(this,'0070dc')}></a></li>
                           	<li><a href="#" data-color="080f29" onClick={this.colorChange.bind(this,'080f29')}></a></li>
                           	<li><a href="#" data-color="284a00" onClick={this.colorChange.bind(this,'284a00')}></a></li>
                           	<li><a href="#" data-color="301b08" onClick={this.colorChange.bind(this,'301b08')}></a></li>
                           	<li><a href="#" data-color="00356a" onClick={this.colorChange.bind(this,'00356a')}></a></li>

                           	<li><a href="#" data-color="425a8f" onClick={this.colorChange.bind(this,'425a8f')}></a></li>
                           	<li><a href="#" data-color="450f61" onClick={this.colorChange.bind(this,'450f61')}></a></li>
                           	<li><a href="#" data-color="652b92" onClick={this.colorChange.bind(this,'652b92')}></a></li>
                           	<li><a href="#" data-color="735f3a" onClick={this.colorChange.bind(this,'735f3a')}></a></li>
                           	<li><a href="#" data-color="00736a" onClick={this.colorChange.bind(this,'00736a')}></a></li>

                           	<li><a href="#" data-color="754b24" onClick={this.colorChange.bind(this,'754b24')}></a></li>
                           	<li><a href="#" data-color="784d3a" onClick={this.colorChange.bind(this,'784d3a')}></a></li>
                           	<li><a href="#" data-color="002155" onClick={this.colorChange.bind(this,'002155')}></a></li>
                           	<li><a href="#" data-color="5574b9" onClick={this.colorChange.bind(this,'5574b9')}></a></li>
                           	<li><a href="#" data-color="005850" onClick={this.colorChange.bind(this,'005850')}></a></li>

                           	<li><a href="#" data-color="007136" onClick={this.colorChange.bind(this,'007136')}></a></li>
                           	<li><a href="#" data-color="9861a9" onClick={this.colorChange.bind(this,'9861a9')}></a></li>
                           	<li><a href="#" data-color="010713" onClick={this.colorChange.bind(this,'010713')}></a></li>
                           	<li><a href="#" data-color="16193c" onClick={this.colorChange.bind(this,'16193c')}></a></li>
                           	<li><a href="#" data-color="017670" onClick={this.colorChange.bind(this,'017670')}></a></li>

                           	<li><a href="#" data-color="23262d"onClick={this.colorChange.bind(this,'23262d')}></a></li>
                           	<li><a href="#" data-color="36302d" onClick={this.colorChange.bind(this,'36302d')}></a></li>
                           	<li><a href="#" data-color="67053e" onClick={this.colorChange.bind(this,'67053e')}></a></li>
                           	<li><a href="#" data-color="070707" onClick={this.colorChange.bind(this,'070707')}></a></li>
                           	<li><a href="#" data-color="131720" onClick={this.colorChange.bind(this,'131720')}></a></li>

                           	<li><a href="#" data-color="183440" onClick={this.colorChange.bind(this,'183440')}></a></li>
                           	<li><a href="#" data-color="253149" onClick={this.colorChange.bind(this,'253149')}></a></li>
                           	<li><a href="#" data-color="300049" onClick={this.colorChange.bind(this,'300049')}></a></li>
                           	<li><a href="#" data-color="393745" onClick={this.colorChange.bind(this,'393745')}></a></li>
                           	<li><a href="#" data-color="460002" onClick={this.colorChange.bind(this,'460002')}></a></li>

                           	<li><a href="#" data-color="465864" onClick={this.colorChange.bind(this,'465864')}></a></li>
                           	<li><a href="#" data-color="542700" onClick={this.colorChange.bind(this,'542700')}></a></li>
                           	<li><a href="#" data-color="613813" onClick={this.colorChange.bind(this,'613813')}></a></li>
                           	<li><a href="#" data-color="636363" onClick={this.colorChange.bind(this,'636363')}></a></li>
                           	<li><a href="#" data-color="643000" onClick={this.colorChange.bind(this,'643000')}></a></li>

                           	<li><a href="#" data-color="736257" onClick={this.colorChange.bind(this,'736257')}></a></li>
                           	<li><a href="#" data-color="790027" onClick={this.colorChange.bind(this,'790027')}></a></li>
                           	<li><a href="#" data-color="922691" onClick={this.colorChange.bind(this,'922691')}></a></li>
                           	<li><a href="#" data-color="960502" onClick={this.colorChange.bind(this,'960502')}></a></li>
                           	<li><a href="#" data-color="a1a195" onClick={this.colorChange.bind(this,'a1a195')}></a></li>

                           	<li><a href="#" data-color="a92e4d" onClick={this.colorChange.bind(this,'a92e4d')}></a></li>
                           	<li><a href="#" data-color="a47952" onClick={this.colorChange.bind(this,'a47952')}></a></li>
                           	<li><a href="#" data-color="aa003f" onClick={this.colorChange.bind(this,'aa003f')}></a></li>
                           	<li><a href="#" data-color="b08bc0" onClick={this.colorChange.bind(this,'b08bc0')}></a></li>
                           	<li><a href="#" data-color="b3226f" onClick={this.colorChange.bind(this,'b3226f')}></a></li>

                           	<li><a href="#" data-color="c49c6c" onClick={this.colorChange.bind(this,'c49c6c')}></a></li>
                           	<li><a href="#" data-color="c80501" onClick={this.colorChange.bind(this,'c80501')}></a></li>
                           	<li><a href="#" data-color="cc3083" onClick={this.colorChange.bind(this,'cc3083')}></a></li>
                           	<li><a href="#" data-color="d01d15" onClick={this.colorChange.bind(this,'d01d15')}></a></li>
                           	<li><a href="#" data-color="d43400" onClick={this.colorChange.bind(this,'d43400')}></a></li>

                           	<li><a href="#" data-color="dc0000" onClick={this.colorChange.bind(this,'dc0000')}></a></li>
                           	<li><a href="#" data-color="dc5100" onClick={this.colorChange.bind(this,'dc5100')}></a></li>
                           	<li><a href="#" data-color="e06d00" onClick={this.colorChange.bind(this,'e06d00')}></a></li>
                           	<li><a href="#" data-color="ee1b25" onClick={this.colorChange.bind(this,'ee1b25')}></a></li>
                           	<li><a href="#" data-color="ee008d" onClick={this.colorChange.bind(this,'ee008d')}></a></li>

                           	<li><a href="#" data-color="f76c8d" onClick={this.colorChange.bind(this,'f76c8d')}></a></li>
                           	<li><a href="#" data-color="f0135b" onClick={this.colorChange.bind(this,'f0135b')}></a></li>
                           	<li><a href="#" data-color="f5661f" onClick={this.colorChange.bind(this,'f5661f')}></a></li>
                           	<li><a href="#" data-color="f69779" onClick={this.colorChange.bind(this,'f69779')}></a></li>
                            <li><a href="#" data-color="fe2900" onClick={this.colorChange.bind(this,'fe2900')}></a></li>


                           </ul>
                         </div>
                       </div>
                     </div>

                    <div className="spacer"></div>
                      <div className="row">
                       <div className="col-xs-12 alignRigh1">
                          <button onClick={this.submitData.bind(this)} className="btn btn-profile2  big">Continue <i className="fa fa-chevron-right"></i></button>
                       </div>
                     </div>

                          <ProgressSlider profileId = {this.props.params.profileId} stateUpdate={updateState}/>

              </div>
              </div>
          </div>
      </section>
    </div>
);
}
}
ProfileBasics.propTypes = {
    changeRoute: React.PropTypes.func,
};

function mapDispatchToProps(dispatch) {
    return {
        changeRoute: (url) => dispatch(push(url)),
    };
}

export default connect(null, mapDispatchToProps)(ProfileBasics);
//export default ProfileBasics;
