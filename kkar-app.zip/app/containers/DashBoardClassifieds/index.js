/**
 * Created by Neeru on 7/13/2016.
 */
//import React from 'react';
import React, { Component } from 'react';
import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
import {DashboardHeader} from 'components/DashboardHeader_Component';
import {DashboardClassified} from 'components/DashboardClassified_Component';
import {DashboardClassifiedPopUp} from 'components/DashboardClassifiedPopUp_Component';
import {ClassifiedAddEditDialog} from 'components/ClassifiedAddEditDialog_Component'
var util = require('utils/request');
import cookie from 'react-cookie';
export class DashBoardClassifieds extends React.Component {
constructor(props) {
    super(props);
    this.state =
    {
      user_id:cookie.load('userId'),
      classified_data : [],
      open: false
    }
 }

componentDidMount() {
   document.title = "My Dashboard | Kalakar";
    var userid = this.state.user_id;
    var param1 = {action:'classifieds',user_id: userid}
    var formState = this;
    util.getSetData(param1,function (data) {
      if(data.status == "success"){
          formState.setState({classified_data : data.data});
         }
         
     });
  }

  handleOpen = () => {
       this.setState({open: true});
     };

  handleClose = (s) => {
    if(s == "SUCCESS")
    {
       this.componentDidMount();
       this.setState({open: false});
     }
     else
     {
        this.setState({open: false});
      }
   };

  render() {
    const local = this;
    return (
      <div className="PageMinHeight">
     <DashboardHeader page="Classified" />
        <div className="container">
          <div className="dash_clssifield">
            <div className="row">
               <div className="col-xs-12 dash_clssi_addbtn">
               <RaisedButton label="Post new Classfied" primary={true} onTouchTap={this.handleOpen} />
            </div>
          </div>

         <div className="recent_classified">
          <ul>
              <li className="heading">
                <span className="classified_name">Classifieds</span>
                <span className="classified_date">Date</span>
                <span className="classified_amount">Amount</span>
                <span className="classified_action"></span>
              </li>


      {this.state.classified_data.map(function(object, i){
          return <DashboardClassified key={i} classi_id = {object.classified_id} title={object.title} category_name={object.category_name}
          schedule_work_dates={object.schedule_work_dates} avg_rate={object.avg_rate} display_status={object.display_status == 0 ? "edit/repost" : "draft"}
          close = {local.handleClose}/>
        })}
        </ul>

        <ClassifiedAddEditDialog title = {"New Classified Ad"} classi_id = {0} stat = {this.state.open}  close = {this.handleClose}/>
        </div>
        </div>
        </div>
      </div>
      );
  }
}

export default DashBoardClassifieds;
