import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import {DashboardMenu} from 'components/DashboardMenu';
import {ProgressSlider} from 'components/ProgressSlider';
var util = require('utils/request');
import { API_URL } from 'containers/App/constants'
import {DialogConfirm} from 'components/TagDelete';
import cookie from 'react-cookie';
import Cropper from 'react-cropper';
import RaisedButton from 'material-ui/RaisedButton';
import Dialog from 'material-ui/Dialog';
import ReactDOM from 'react-dom';
import Draggable from 'react-draggable';

export class Deck extends React.Component {
  eventLogger = (e: MouseEvent, data: Object) => {
   console.log('Event: ', event);
   console.log('Data: ', data);
 };

    constructor(props) {
        super(props);
        this.state = {
            stateUpdate:false,
            user_id:cookie.load('userId'),
            subpage:"list",
            deckData:[],
            open:false,
            video_link:'',
            croperstate:false,
            IMGSrc: '',
            uploadingImg:'',
            photoUrl:'',
            open:false,
            imgTags:'',
            Filename:'',
            picState:'',
            tagError:'',
            mediaId:'',
            text1:'',
            text2:'',
            text3:'',
            font1:'',
            font2:'',
            font3:'',
            size1:'10',
            size2:'10',
            size3:'10',
            color1:'#000',
            color2:'#000',
            color3:'#000',
            Orientation:''
        }
    }
    componentDidMount() {
      document.title = "Extended Profile | Kalakar";
        var param = {action: 'deckList', profile_id: this.props.params.profileId};
        var formState = this;
        $.ajax({
            url: API_URL,
            type: "POST",
            dataType: 'json',
            data: param,
            success: function (data) {
                formState.setState({
                    deckData:data.slidesData,
                    open:false
                });
            }.bind(this)

        });
        (function($){
            $(window).load(function(){
                $(".slider-table").mCustomScrollbar({
                    setHeight:235,
                    theme:"dark-3"
                });
            });

        })(jQuery);
        jQuery('#lightgallery').lightGallery();
        jQuery('.lightgallery-single-image').lightGallery();
        jQuery('.lightgallery-single-video').lightGallery();

    }

    createVideo(){
        this.setState({
            subpage:"addVideo"
        });
    };
    createImage(){
        this.setState({
            subpage:"addImage"
        });
    };
    createMainClick(){
        this.setState({
            open:false,
            subpage:"list",
            requiredFlag:false
        });
        var param = {action: 'deckList', profile_id: this.props.params.profileId};
        var formState = this;
        $.ajax({
            url: API_URL,
            type: "POST",
            dataType: 'json',
            data: param,
            success: function (data) {
                formState.setState({
                    deckData:data.slidesData,
                    open:false
                });
                jQuery(".slider-table").mCustomScrollbar({
                    setHeight:235,
                    theme:"dark-3"
                });
            }.bind(this)

        });

    }
    handleOpen(tid, formState) {
        formState.setState({open: true,dtid: tid, croperstate: false});
    };
    handleClose = () => {
        this.setState({open: false, croperstate: false});
    };

    deleteslide(){
        var slideId=this.state.dtid;
        var param = {action : 'deleteDeck',slideId : slideId}
        $.ajax({
            url: API_URL,
            type: "POST",
            dataType: 'json',
            data: param,
            success: function (data) {
                this.state.stateUpdate = true;
                this.handleClose();
                var param = {action: 'deckList', profile_id: this.props.params.profileId};
                var formState = this;
                $.ajax({
                    url: API_URL,
                    type: "POST",
                    dataType: 'json',
                    data: param,
                    success: function (data) {
                        formState.setState({
                            deckData:data.slidesData,
                            open:false
                        });
                    }.bind(this)
                });
            }.bind(this)
        });
        }
    handleInputChange(index, e) {
        this.setState({video_link : e.target.value});
    };
    addVideo(){
        if(!this.isDisabledWebsite()){
            this.isDisabledWebsite();
            return;
        }
    var video_link=this.state.video_link;
    var userid = this.state.user_id;
    var param = {action: 'saveDeck', profile_id: this.props.params.profileId, video_link:video_link,user_id: userid, type:'video'}
    var formState = this;
    util.getSetData(param, function (data) {
        if (data.status == "success") {
            formState.state.stateUpdate = true;
            formState.setState({
                video_link:'',
                subpage:"list"
            });
            var param = {action: 'deckList', profile_id: formState.props.params.profileId};
            $.ajax({
                url: API_URL,
                type: "POST",
                dataType: 'json',
                data: param,
                success: function (data) {
                    formState.setState({
                        deckData:data.slidesData,
                        open:false
                    });
                            jQuery(".slider-table").mCustomScrollbar({
                                setHeight:235,
                                theme:"dark-3"
                            });

                }.bind(this)

            });

        }
    });
}

uploadImage(){
var cropperDAta = this.refs.cropper.getCroppedCanvas().toDataURL();
this.setState({croperstate:false,  uploadingImg:cropperDAta, photoUrl:'', picState:1});
var formState = this;
var userid = this.state.user_id;
var profileId = this.props.params.profileId;
var params1 = {action:'uploadDeckPhoto', profile_id:profileId, user_id: userid, filed: cropperDAta, fname:this.state.Filename}
util.getSetData(params1, function (data) {
if(data.status == "success"){
    formState.state.stateUpdate = true;

formState.setState({uploadingImg:data.deck_image, mediaId:data.photomedia});
  }
  else {
 formState.setState({picState:3});
  }
});
}

RotateR(){
this.refs.cropper.rotate(90);
}
_crop(e){
    }
RotateL(){
this.refs.cropper.rotate(-90);
}

removeImg(){
 this.setState({uploadingImg:''})
}
handleImageChange (e) {
e.preventDefault();
let reader = new FileReader();
let file = e.target.files[0];
reader.onloadend = () => {

 this.setState({croperstate:true, IMGSrc:reader.result, Filename:file.name});

}
reader.readAsDataURL(file);
}
changeText(e){
 this.setState({imgTags:e.target.value})
}
retryImage(e){
 if(e===3)
 {
   this.setState({picState:1});
   var formState = this;
   var userid = this.state.user_id;
   var profileId = this.props.params.profileId;
   var params1 = {action:'photos', profile_id:profileId, userId: userid, img_data:this.state.uploadingImg, imgtgs:this.state.imgTags, f_name:this.state.Filename}
   util.getSetData(params1, function (data) {
   if(data.status == "success"){
formState.setState({uploadingImg:data.deck_image, mediaId:data.photomedia});
      }
      else {
     formState.setState({picState:3});
      }
    });
 }
}
    validateWebsite(value)
    {
        var exp =/(?:(?:http|https):\/\/)?(?:www\.)?(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))((\w|-){11})(?:\S+)?$/;;
        var exp1 =/https?:\/\/(?:www\.|player\.)?vimeo.com\/(?:channels\/(?:\w+\/)?|groups\/([^\/]*)\/videos\/|album\/(\d+)\/video\/|video\/|)(\d+)(?:$|\/|\?)/;
        if(exp.test(value))
        {
            return true;
        }
        else if( exp1.test(value))
        {
            return true;
        }
        else{
            return false;
        }

    }
    isDisabledWebsite() {
        let urlIsValid = false;
        if (this.state.video_link === "") {

            this.setState({
                website_error_text:"Required"
            });
        } else {
            if (this.validateWebsite(this.state.video_link)) {
                urlIsValid = true;
                this.setState({
                    website_error_text: null
                });
            }
            else {
                this.setState({
                    website_error_text: "Please paste youtube or vimeo link"
                });
            }
        }
        return urlIsValid;
    }

    saveSlideData(e){
      var possition = $('.handle').attr('style');
      var posArr = possition.split('transform:');
      var posTrans = posArr[1].split(';');
      var transform1 = posTrans[0];
      var possition2 = $('.handle1').attr('style');
      var posArr2 = possition2.split('transform:');
      var posTrans2 = posArr2[1].split(';');
      var transform2 = posTrans2[0];
      var possition3 = $('.handle2').attr('style');
      var posArr3 = possition3.split('transform:');
      var posTrans3 = posArr3[1].split(';');
      var transform3 = posTrans3[0];
      var formState = this;
      var userid = this.state.user_id;
      var profileId = this.props.params.profileId;
      var params1 = {action:'saveDeck', type:'image', mediaID: this.state.mediaId,
        profile_id:profileId, slide_head:this.state.text1, slide_desc:this.state.text2, slide_auth:this.state.text3, slide_hpossitn:transform1, slide_dpossitn:transform2,
        slide_apossitn:transform3, slide_orintsn:this.state.Orientation,  h_color:this.state.color1, img_data:this.state.uploadingImg,
        d_color:this.state.color2, a_color:this.state.color3, font_family1:this.state.font1, font_family2:this.state.font2, font_family3:this.state.font3,
        head_font_size:this.state.size1, desc_font_size:this.state.size2, author_font_size:this.state.size3}
      util.getSetData(params1, function (data) {
      if(data.status == "success"){
          formState.state.stateUpdate = true;
      formState.setState({subpage:"list",
      croperstate:false,
      IMGSrc: '',
      uploadingImg:'',
      photoUrl:'',
      open:false,
      imgTags:'',
      Filename:'',
      picState:'',
      tagError:'',
      mediaId:'',
      text1:'',
      text2:'',
      text3:'',
      font1:'',
      font2:'',
      font3:'',
      size1:'10',
      size2:'10',
      size3:'10',
      color1:'#000',
      color2:'#000',
      color3:'#000',
      Orientation:'',});
          var param = {action: 'deckList', profile_id: formState.props.params.profileId};
          $.ajax({
              url: API_URL,
              type: "POST",
              dataType: 'json',
              data: param,
              success: function (data) {
                  formState.setState({
                      deckData:data.slidesData,
                      open:false
                  });
                  jQuery(".slider-table").mCustomScrollbar({
                      setHeight:235,
                      theme:"dark-3"
                  });
              }.bind(this)
          });

      }
         else {
        formState.setState({picState:3});
         }
       });
    }
handleKeyUp(val, event){
var values = event.target.value;

if(val==='text1')
{this.setState({text1:values});
}
if(val==='text2')
{this.setState({text2:values});
}
if(val==='text3')
{this.setState({text3:values});
}
}
handleChange(val, event){
  var values = event.target.value;

  if(val==='font1')
  {this.setState({font1:values});
  }
  if(val==='font2')
  {this.setState({font2:values});
  }
  if(val==='font3')
  {this.setState({font3:values});
  }
}
handleSize(val, event){
  var values = event.target.value;

  if(val==='size1')
  {this.setState({size1:values});
  }
  if(val==='size2')
  {this.setState({size2:values});
  }
  if(val==='size3')
  {this.setState({size3:values});
  }
}

handlecolor(val, event){
  var values = event.target.value;

  if(val==='color1')
  {this.setState({color1:values});
  }
  if(val==='color2')
  {this.setState({color2:values});
  }
  if(val==='color3')
  {this.setState({color3:values});
  }
}
handleOrientation(e){
  this.setState({Orientation:e.target.value});
}
    Continue() {
        var p_id = this.props.params.profileId;
        this.props.changeRoute('/my-accounts/extended-profile/' + p_id + '/social');
    }
    render() {

        (function($){
            $(window).load(function(){
                $(".slider-table").mCustomScrollbar({
                    setHeight:235,
                    theme:"dark-3"
                });
            });

        })(jQuery);
        var updateState = false;
        if(this.state.stateUpdate)
        {
            updateState = true;
            this.state.stateUpdate = false;
        }

        var local = this;
        return (
            <div>
              <Dialog title="Upload Image" modal={true} open={this.state.croperstate}  className="croperPopup" autoScrollBodyContent={false}>
              <button onClick={this.uploadImage.bind(this)}  className="uploadBtnCrop"><span className="fa fa-check"></span></button>
              <p>(min size 800px X 600px)</p>
              <Cropper
              ref='cropper'
              src={this.state.IMGSrc}
              style={{height: 400, width: '100%'}}
              aspectRatio={16 / 9}
              autoCropArea={0.97}
              guides={false}
             />
              <span className="RotateBtnCropOuter">
                <button title='Rotate Left' onClick={this.RotateL.bind(this)} className="RotateBtnCrop"><span className="fa fa-rotate-left"></span></button>
                <button title='Rotate Right' onClick={this.RotateR.bind(this)} className="RotateBtnCrop"><span className="fa fa-rotate-right"></span></button>
              </span>
              <RaisedButton className="cancelBtnPopup" primary={true} onTouchTap={this.handleClose} label="X"/>
              </Dialog>
                {local.state.subpage == "list" &&
                <div>
            <section className="inner-page basic-profile">

                <DashboardMenu page="Deck" profileId={this.props.params.profileId}/>

                <div className="pageRest cell">
                    <div className="basic-profile-inner">
                        <div className="row">
                            <div className="col-sm-6 ">
                                <div className="btn_inline_view">
                                    <h1 className="h1_btn">Deck</h1>
                            <span className="lightgallery-single-video">
                             <li className="video" data-src="https://www.youtube.com/watch?v=-yEBte_IN68&feature=youtu.be">
                                 <button type="button" className=" btn video_assist_btn">Video Assist <i className="fa fa-play-circle"></i></button>
                             </li></span>

                                </div>
                            </div>
                            <div className="col-sm-6">
                                <h3>Step 13/14</h3>
                            </div>
                        </div>

                        <div className="row">
                            <div className="col-sm-12 col-xs-12 alignRigh1">
                                <a href={'/user-profile/'+this.props.params.profileId} target='_blank' className="btn btn-profile2 big noMargin">Quick View <i className="fa fa-chevron-right"></i></a>
                            </div>
                        </div>

                        <div className="row">
                            <div className="col-sm-12 col-xs-12">
                                <h2 className="sliderTableh2">Slider Table</h2>
                                <div className="slider-table">
                                    <div className="slidertableInner">
                                        <table className="table table-bordered table-responsive table-striped">
                                            <tbody>
                                            <tr>
                                                <th>Slide</th>
                                                <th>Type</th>
                                                <th width="100px">Delete</th>
                                            </tr>
                                            {this.state.deckData.map(d =>
                                            <tr key={d.slideId}>
                                                <td><span>{ d.slideOrigin === "photo" &&
                                                    <img src={d.bgImg}/>}

                                                    { d.slideOrigin === "video" &&
                                                <iframe width="58px" height="40px"
                                                        src={d.videolink} frameBorder="0"
                                                        allowFullScreen>
                                                </iframe>}</span></td>
                                                <td>{d.slideOrigin}</td>
                                                <td><a href="javascript:void(0)" onTouchTap={this.handleOpen.bind(null,d.slideId,local)} className="cancel">Delete</a></td>
                                            </tr>)}
                                            </tbody>
                                        </table>
                                        <DialogConfirm open={this.state.open} title="Delete Slide"
                                                       body="Do you really want to delete?"
                                                       onSubmit={this.deleteslide.bind(this)}
                                                       onClose={this.handleClose}/>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div className="row">
                            <div className="col-sm-12 col-xs-12 alignRigh1">
                                <button className="btn btn-profile2 big noMargin" onClick={this.createVideo.bind(this)}>Add video <i className="fa fa-chevron-right"></i></button>
                                <button className="btn btn-profile2 big noMargin" onClick={this.createImage.bind(this)}>Add Image <i className="fa fa-chevron-right"></i></button>
                                <button className="btn btn-profile2 big noMargin" onClick={this.Continue.bind(this)}>
                                    Continue <i className="fa fa-chevron-right"/>
                                </button>
                            </div>
                        </div>

                        <ProgressSlider profileId={this.props.params.profileId} stateUpdate={updateState}/>
                    </div>

                </div>

            </section>
                </div>}

                {local.state.subpage == "addVideo" &&
                <div>
                    <section className="inner-page basic-profile">
                        <DashboardMenu page="Deck" profileId={this.props.params.profileId}/>

                        <div className="pageRest cell">
                            <div className="basic-profile-inner">
                                <div className="row">
                                    <div className="col-sm-6">
                                        <h1>Deck</h1>
                                    </div>
                                    <div className="col-sm-6">
                                        <h3>Step 14/14</h3>
                                    </div>
                                </div>

                                <div className="row">
                                    <div className="col-sm-12 col-xs-12 lastCol">
                                        <input type="text" placeholder="Paste youtube or vimeo link"
                                               value={this.state.video_link}
                                               onChange={this.handleInputChange.bind(this,'video_link')}
                                               onBlur={this.isDisabledWebsite.bind(this,'video_link')}
                                            /><small className="errorMsg">{this.state.website_error_text}</small>

                                        <i className="fa fa-info" data-toggle="tooltip" title="" data-original-title="Paste youtube or vimeo link"></i>

                                    </div>
                                    <p> &nbsp;</p>
                                </div>


                                <div className="row">
                                    <div className="col-sm-12 col-xs-12 alignRigh1">
                                        <button className="btn btn-profile2 big noMargin" onClick={this.createMainClick.bind(this)}>Cancel <i className="fa fa-chevron-right"></i></button>
                                        <button className="btn btn-profile2 big noMargin" onClick={this.addVideo.bind(this)}>Add <i className="fa fa-chevron-right"></i></button>
                                    </div>
                                </div>
                                <ProgressSlider profileId={this.props.params.profileId} stateUpdate={updateState}/>
                            </div>
                        </div>
                    </section>

                </div>}
                {local.state.subpage == "addImage" &&
                <div>
                    <section className="inner-page basic-profile">
                        <DashboardMenu page="Deck" profileId={this.props.params.profileId}/>
                        <div className="pageRest cell">
                            <div className="basic-profile-inner">
                                <div className="row">
                                    <div className="col-sm-6">
                                        <h1>Deck</h1>
                                    </div>
                                    <div className="col-sm-6">
                                        <h3>Step 14/14</h3>
                                    </div>
                                </div>

                                <div className="row">
                                    <div className="col-sm-12 col-xs-12">
                                        <div className="albums-data deckBrowserImg">
                                            <div className="albums-data__inner">
                                                <div className="photo-block">
                                                    <div className="photo-block__img">
                                                      {(this.state.IMGSrc==='') ?  <div className="upload">
                         <span className="fileUploadBtn">
                         Browse Image <input type="file" id="file"  onChange={this.handleImageChange.bind(this)} accept="image/*"/>
                        </span>
                    </div>:<img src={this.state.uploadingImg}/>}  <Draggable
                   handle=".handle"
                   defaultPosition={{x: 0, y: 0}}
                   position={null}
                   grid={[50, 50]}
                   zIndex={100}
                   onStart={this.handleStart}
                   onDrag={this.handleDrag}
                   onStop={this.handleStop}>
                     <div className="handle" style={{position:'absolute', fontFamily:this.state.font1, fontSize:this.state.size1, color:this.state.color1}}>{this.state.text1}</div>
                </Draggable>
                 <Draggable
                handle=".handle1"
                defaultPosition={{x: 0, y: 25}}
                position={null}
                grid={[50, 50]}
                zIndex={100}
                onStart={this.handleStart}
                onDrag={this.handleDrag}
                onStop={this.handleStop}>
              <div className="handle1" style={{position:'absolute', fontFamily:this.state.font2, fontSize:this.state.size2, color:this.state.color2}}>{this.state.text2}</div>
                </Draggable>
              <Draggable

             handle=".handle2"
             defaultPosition={{x: 0, y: 50}}
             position={null}
             grid={[50, 50]}
             zIndex={100}
             onStart={this.handleStart}
             onDrag={this.handleDrag}
             onStop={this.handleStop}>
             <div className="handle2" style={{position:'absolute', fontFamily:this.state.font3, fontSize:this.state.size3, color:this.state.color3}}>{this.state.text3}</div>
           </Draggable>
                   </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                    <div className="row">
                                        <div className="col-sm-12 col-xs-12">
                                            <div className="slider-table">
                                                <div className="slidertableInner">
                                                    <table className="table table-bordered table-responsive table-striped">
                                                        <tbody>
                                                        <tr>
                                                            <th>Text</th>
                                                            <th>Font Family</th>
                                                            <th>Font Size</th>
                                                            <th>Font Color</th>
                                                        </tr>
                                                        <tr>
                                                            <td><input type="text" value={this.state.text1} onChange={this.handleKeyUp.bind(this, 'text1')}  placeholder="Text 1"/></td>
                                                                <td>
                                                                    <select value={this.state.font1} onChange={this.handleChange.bind(this, 'font1')}>
                                                                        <option value="Georgia">Georgia</option>
                                                                        <option value="Palatino Linotype">Palatino Linotype</option>
                                                                        <option value="Book Antiqua">Book Antiqua</option>
                                                                        <option value="Times New Roman">Times New Roman</option>
                                                                        <option value="Arial">Arial</option>
                                                                        <option value="Helvetica">Helvetica</option>
                                                                        <option value="Arial Black">Arial Black</option>
                                                                        <option value="Impact">Impact</option>
                                                                        <option value="Lucida Sans Unicode">Lucida Sans Unicode</option>
                                                                        <option value="Tahoma">Tahoma</option>
                                                                        <option value="Verdana">Verdana</option>
                                                                        <option value="Courier New">Courier New</option>
                                                                        <option value="Lucida Console">Lucida Console</option>
                                                                        <option value="initial">initial</option>
                                                                    </select>
                                                                </td>
                                                                <td>
                                                                    <select value={this.state.size1} onChange={this.handleSize.bind(this, 'size1')}>
                                                                        <option value="10">select size</option>
                                                                        <option value="18">18px</option>
                                                                        <option value="24">24px</option>
                                                                        <option value="30">30px</option>
                                                                        <option value="36">36px</option>
                                                                        <option value="42">42px</option>
                                                                        <option value="48">48px</option>
                                                                    </select>
                                                                </td>
                                                                <td>
                                                                    <p id="a_color"><input value={this.state.color1} onChange={this.handlecolor.bind(this, 'color1')} type="color" /></p>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td><input type="text" value={this.state.text2} onChange={this.handleKeyUp.bind(this, 'text2')}  placeholder="Text 2" /></td>
                                                                    <td>
                                                                        <select value={this.state.font2} onChange={this.handleChange.bind(this, 'font2')}>
                                                                            <option value="Georgia">Georgia</option>
                                                                            <option value="Palatino Linotype">Palatino Linotype</option>
                                                                            <option value="Book Antiqua">Book Antiqua</option>
                                                                            <option value="Times New Roman">Times New Roman</option>
                                                                            <option value="Arial">Arial</option>
                                                                            <option value="Helvetica">Helvetica</option>
                                                                            <option value="Arial Black">Arial Black</option>
                                                                            <option value="Impact">Impact</option>
                                                                            <option value="Lucida Sans Unicode">Lucida Sans Unicode</option>
                                                                            <option value="Tahoma">Tahoma</option>
                                                                            <option value="Verdana">Verdana</option>
                                                                            <option value="Courier New">Courier New</option>
                                                                            <option value="Lucida Console">Lucida Console</option>
                                                                            <option value="initial">initial</option>
                                                                        </select>
                                                                    </td>
                                                                    <td>
                                                                        <select value={this.state.size2} onChange={this.handleSize.bind(this, 'size2')}>
                                                                            <option value="10">select size</option>
                                                                            <option value="18">18px</option>
                                                                            <option value="24">24px</option>
                                                                            <option value="30">30px</option>
                                                                            <option value="36">36px</option>
                                                                            <option value="42">42px</option>
                                                                            <option value="48">48px</option>
                                                                        </select>
                                                                    </td>
                                                                    <td>
                                                                        <p id="a_color"><input value={this.state.color2} onChange={this.handlecolor.bind(this, 'color2')} type="color" /></p>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><input type="text" value={this.state.text3} onChange={this.handleKeyUp.bind(this, 'text3')}  placeholder="Text 3" /></td>
                                                                        <td>
                                                                            <select id="font_family" value={this.state.font3} onChange={this.handleChange.bind(this, 'font3')}>
                                                                                <option value="Georgia">Georgia</option>
                                                                                <option value="Palatino Linotype">Palatino Linotype</option>
                                                                                <option value="Book Antiqua">Book Antiqua</option>
                                                                                <option value="Times New Roman">Times New Roman</option>
                                                                                <option value="Arial">Arial</option>
                                                                                <option value="Helvetica">Helvetica</option>
                                                                                <option value="Arial Black">Arial Black</option>
                                                                                <option value="Impact">Impact</option>
                                                                                <option value="Lucida Sans Unicode">Lucida Sans Unicode</option>
                                                                                <option value="Tahoma">Tahoma</option>
                                                                                <option value="Verdana">Verdana</option>
                                                                                <option value="Courier New">Courier New</option>
                                                                                <option value="Lucida Console">Lucida Console</option>
                                                                                <option value="initial">initial</option>
                                                                            </select>
                                                                        </td>
                                                                        <td>
                                                                            <select value={this.state.size3} onChange={this.handleSize.bind(this, 'size3')}>
                                                                                <option value="10">select size</option>
                                                                                <option value="18">18px</option>
                                                                                <option value="24">24px</option>
                                                                                <option value="30">30px</option>
                                                                                <option value="36">36px</option>
                                                                                <option value="42">42px</option>
                                                                                <option value="48">48px</option>
                                                                            </select>
                                                                        </td>
                                                                        <td>
                                                                            <p id="a_color"><input value={this.state.color3} onChange={this.handlecolor.bind(this, 'color3')} type="color" /></p>
                                                                        </td>
                                                                    </tr>
                                                        </tbody>
                                                                </table>
                                                            </div>
                                                            <h2 className="sliderTableh2">Silde Orientation</h2>
                                                            <select id="slide_orintsn" value={this.state.Orientation} onChange={this.handleOrientation.bind(this)}>
                                                                <option value="">Select Orientation</option>
                                                                <option value="fade in">Fade In</option>
                                                                <option value="horizontal">Horizontal break center</option>
                                                                <option value="vertical">Vertical break center</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>


                                                <div className="row">
                                                    <div className="col-sm-12 col-xs-12 alignRigh1">
                                                        <button className="btn btn-profile2 big noMargin" onClick={this.createMainClick.bind(this)}>Cancel <i className="fa fa-chevron-right"></i></button>
                                                        <button className="btn btn-profile2 big noMargin" onClick={this.saveSlideData.bind(this)}>Add <i className="fa fa-chevron-right"></i></button>
                                                    </div>
                                                </div>

                                     <ProgressSlider profileId={this.props.params.profileId} stateUpdate={updateState}/>
                                            </div>

                                        </div>

                                    </section>
                </div>}
            </div>

        )}
        onDrop(data) {
               console.log(data)
               // => banana
           }


}

Deck.propTypes = {
    changeRoute: React.PropTypes.func,
};

function mapDispatchToProps(dispatch) {
    return {
        changeRoute: (url) => dispatch(push(url)),
    };
}

export default connect(null,
    mapDispatchToProps)(Deck);
