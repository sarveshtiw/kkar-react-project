import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import {DashboardMenu} from 'components/DashboardMenu';
import TextField from 'material-ui/TextField';
import {ViewEdit} from 'components/ViewEdit_Component';
import {ProgressSlider} from 'components/ProgressSlider';
import cookie from 'react-cookie';
var util = require('utils/request');


export class Awards extends React.Component {
    openRoute = (route) => {
        this.props.changeRoute(route);
    };

    constructor(props) {
        super(props);
        this.state = {
            stateUpdate:false,
            years: [1976, 1977, 1978, 1979, 1980, 1981, 1982, 1983, 1984, 1985, 1986, 1987, 1988, 1989, 1990, 1991, 1992, 1993, 1994, 1995,
                1996, 1997, 1998, 1999, 2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016],
            awards: [],
            award_data: {
                award_id: '',
                profile_id: "",
                award_name: "",
                award_for: "",
                award_photo: "",
                award_photo_name: "",
                year_of_award: '',
                award_video: "",
                award_link: "",
                button_text:'ADD',
                result : null,
                resultMsg : ''
            }

        }
    }

    componentDidMount() {
      document.title = "Extended Profile | Kalakar";
      (function($){
             $(window).load(function(){
             $(".scroller335").mCustomScrollbar({
                 setHeight:335,
                 theme:"dark-3"
               });
             });

         })(jQuery);




        var local=this;
        $("[data-toggle='tooltip']").tooltip();
        document.getElementById("uploadBtn").onchange = function () {
            var filename = this.value.replace(/^.*\\/, "");
            document.getElementById("uploadFile").value=filename;
            local.isDisabledImageUpload(filename);
         };
        var param = {action: 'awards_list', profile_id: this.props.params.profileId}
        var formState = this;
        util.getSetData(param, function (data) {
          if (data.status == "success") {
              if(data.data!=null){
                  formState.setState({awards : data.data});
                  formState.initializeGallery();

              }
          }
          else {
              console.log("Error in AwardList.Please try again.");
          }
        });

    }
initializeGallery(){
    jQuery('#lightgallery').lightGallery();
    jQuery('.lightgallery-single-image').lightGallery();
    jQuery('.lightgallery-single-video').lightGallery();
}
    handleEditClick(id, local) {
        var param = {action: 'award_detail', award_id: id}
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                var change = {};
                change.award_data = data.data[0];
                change.award_data["button_text"] = "UPDATE";
                local.setState(change);
            }
            else {
                alert("Please try again.");
            }
        });
    }

    handleDeleteClick(id, local) {
      var param = {action: 'deleteAward', award_id : id}
      util.getSetData(param, function (data) {
      if (data.status == "success") {
         alert("Record deleted successfully.");
       }
       else {
           alert("Please try again.");
       }
       });
    }

    handleInputChange(name, e) {
        var change = {};
        change.award_data = this.state.award_data;
        change.award_data[name] = e.target.value;
        this.setState(change);
        if(name == 'award_name'){
            this.validate1();
        }
        if(name == 'award_for'){
            this.validate2();
        }
        if(name == 'award_video'){
            this.isDisabledWebsite();
        }
        if(name == 'award_link'){
            this.isDisabledLink();
        }
    }

    handleChange(e) {
        var change = {};
        change.award_data = this.state.award_data;
        change.award_data['year_of_award'] = e.target.value;
        this.setState(change);
        this.validateSelect();
    }
    handleImageChange(e) {
        e.preventDefault();
        let reader = new FileReader();
        let file = e.target.files[0];
        reader.onloadend = () => {
            var change = {};
            change.award_data = this.state.award_data;
            change.award_data['award_photo'] = reader.result;
            change.award_data['award_photo_name'] = file.name;
            this.setState(change);
        };
        reader.readAsDataURL(file);
    }

    validate1() {
        let valid=false;
        if(this.state.award_data.award_name == ""){
            this.setState({
                award_error_text: "Required"
            });
        } else {
            valid=true
            this.setState({
                award_error_text: null
            })

        }return valid;
    }
    validate2() {
        let valid=false;
        if(this.state.award_data.award_for == ""){
            this.setState({
                award_for_error: "Required"
            });
        } else {
            valid=true
            this.setState({
                award_for_error: null
            })

        }return valid;
    }
    validateWebsite(value){
        var exp =/^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?.*$/
        return exp.test(value);
    }
    isDisabledWebsite() {
        let urlIsValid = false;
        if (this.state.award_data.award_video === "") {
            urlIsValid=true;
            this.setState({
                website_error_text: null
            });
        } else {
            if (this.validateWebsite(this.state.award_data.award_video)) {
                urlIsValid = true;
                this.setState({
                    website_error_text: null
                });
            }
            else {
                this.setState({
                    website_error_text: "Sorry, this is not a valid format"
                });
            }
        }
        return urlIsValid;
    }
    isDisabledLink() {
        let urlIsValid = false;
        if (this.state.award_data.award_link === "") {
            urlIsValid=true;
            this.setState({
                lwebsite_error_text: null
            });
        } else {
            if (this.validateWebsite(this.state.award_data.award_link)) {
                urlIsValid = true;
                this.setState({
                    lwebsite_error_text: null
                });
            }
            else {
                this.setState({
                    lwebsite_error_text: "Sorry, this is not a valid format"
                });
            }
        }
        return urlIsValid;
    }
    validateSelect() {
        let valid=false;
        if(this.state.award_data.year_of_award == ""){
            this.setState({
                    year_error_text: "Required"
                }
            );
        } else {
            valid=true;
            this.setState({
                year_error_text: null
            });

        }return valid;
    }
    validateImageUpload(value){
        var exp =/([a-zA-Z0-9\s_\\.\-:])+(.png|.jpg|.gif|.jpeg)$/;
        return exp.test(value);
    }
    isDisabledImageUpload(value) {
        let urlIsValid = false;
        if (value === "") {
            urlIsValid=true;
            this.setState({
                photo_error_text: null
            });
        } else {
            if (this.validateImageUpload(value)) {
                urlIsValid = true;
                this.setState({
                    photo_error_text: null
                });
            }
            else {
                this.setState({
                    photo_error_text: "Please upload Valid image file"
                });
            }
        }
        return urlIsValid;
    }

    uploadMedia(){
      var form = this;
      var param = {
        action : 'mediaupload',
        user_id : cookie.load('userId'),
        profile_id : this.props.params.profileId,
        file_name : this.state.award_data.award_photo_name,
        imgsrc : this.state.award_data.award_photo
      }
      util.getSetData(param, function (mediaData) {
          if (mediaData.status == "success") {
              form.uploadAward(mediaData.mediaId);
           }
          else {
              console.log("Error");
          }
      });
    }

    uploadAward(mediaId){
      var formState = this;
        var awardsParam = {
          action : "awards",
          profile_id : this.props.params.profileId,
          award_name : this.state.award_data.award_name,
          award_for : this.state.award_data.award_for,
          award_media: mediaId,
          year_of_award: this.state.award_data.year_of_award,
          award_video: this.state.award_data.award_video,
          award_link: this.state.award_data.award_link
        }

        if (this.state.award_data.award_id != 0) {
            awardsParam["award_id"] = this.state.award_data.award_id;
        }
        util.getSetData(awardsParam, function (data) {
            if (data.status == "success") {
                formState.state.stateUpdate = true;
                var param = {action: 'awards_list', profile_id: formState.props.params.profileId}
                util.getSetData(param, function (data1) {
                    document.getElementById("uploadFile").value = "";
                    if (data1.status == "success") {
                        formState.setState({
                            awards: data1.data,
                            award_data: {
                                award_name: "",
                                award_for: "",
                                award_photo: "",
                                year_of_award: '',
                                award_video: "",
                                award_link: "",
                                button_text : 'ADD',
                                result : true,
                                resultMsg : data.message
                            }
                        })
                       formState.initializeGallery();
                    }
                })

            }
            else {
                var change = {};
                change.award_data = formState.state.award_data;
                change.award_data["result"] = false;
                change.award_data["resultMsg"] = data.message
                formState.setState(change);
            }
        });
    }

    submitAwards(e) {
        e.preventDefault();
        if(!(this.validate1() && this.validate2() && this.isDisabledWebsite() && this.isDisabledLink()  && this.validateSelect())){
            this.validate1();
            this.validate2();
            this.isDisabledWebsite();
            this.isDisabledLink();
            this.validateSelect();
            return;
        }

        if(this.state.award_data.award_photo_name != undefined && this.state.award_data.award_photo_name != "" && this.state.award_data.award_photo_name != null && this.state.award_data.award_photo_name != 0)
        {
          //Media upload
          this.uploadMedia();
        }
        else
        {
          //Upload Training
          if(this.state.award_data.award_photo != "" && this.state.award_data.award_photo != null){
              this.uploadAward(this.state.award_data.award_photo);
            }
          else
          {
              this.uploadAward(0);
          }

        }

    }

    Continue()
    {
        var p_id = this.props.params.profileId;
        this.props.changeRoute('/my-accounts/extended-profile/'+ p_id +'/links');
    }

    render() {
      jQuery('#lightgallery').lightGallery();
      jQuery('.lightgallery-single-image').lightGallery();
      jQuery('.lightgallery-single-video').lightGallery();
        var updateState = false;
        if(this.state.stateUpdate)
        {
            updateState = true;
            this.state.stateUpdate = false;
        }
        var local = this;
        return (
            <section className="inner-page basic-profile">
                <DashboardMenu page="Awards" profileId = {this.props.params.profileId}/>

                <div className="pageRest cell">
                    <div className="basic-profile-inner">
                        {this.state.award_data.result == true &&
                        <div className="sucess_ep">{this.state.award_data.resultMsg}</div> }
                        {this.state.award_data.result == false &&
                        <div className="error_ep">{this.state.award_data.resultMsg}</div> }
                        <form onSubmit={this.submitAwards.bind(this)}>
                            <div className="row">
                                <div className="col-sm-6 ">
                                    <div className="btn_inline_view">
                                        <h1 className="h1_btn">Awards</h1>
                            <span className="lightgallery-single-video">
                             <li className="video" data-src="https://www.youtube.com/watch?v=ForhoPH6_FU&feature=youtu.be">
                                 <button type="button" className=" btn video_assist_btn">Video Assist <i className="fa fa-play-circle"></i></button>
                             </li></span>

                                    </div>
                                </div>
                                <div className="col-sm-6">
                                    <h3>Step 6/14</h3>
                                </div>
                            </div>

                            <div className="row">
                                <div className="col-xs-12 lastCol">
                                    <input type="text" placeholder="Name of Award eg : Filmfare Award"
                                           value={this.state.award_data.award_name}
                                           onBlur={this.handleInputChange.bind(this,'award_name')}
                                           onChange={this.handleInputChange.bind(this,'award_name')}/>
                                    <small className="errorMsg">{this.state.award_error_text}</small>
                                    <i className="fa fa-info" data-toggle="tooltip" title=""
                                       data-original-title="Award name"></i>
                                </div>
                                <div className="col-xs-12 lastCol">
                                    <input type="text" placeholder="Category of Award eg : Best Supporting Actor"
                                           value={this.state.award_data.award_for}
                                           onBlur={this.handleInputChange.bind(this,'award_for')}
                                           onChange={this.handleInputChange.bind(this,'award_for')}/>
                                    <small className="errorMsg">{this.state.award_for_error}</small>
                                    <i className="fa fa-info" data-toggle="tooltip" title=""
                                       data-original-title="Category"></i>
                                </div>
                              </div>
                          <div className="row">
                                <div className="col-md-4 col-sm-4 col-xs-12 uploadBasicPh">
                                    <input id="uploadFile" type="text" placeholder="Verify by Photo" value={this.state.value}/>
                                    <small className="errorMsg">{this.state.photo_error_text}</small>
                                    <div className="fileUpload">
                                        <span></span>
                                        <input id="uploadBtn" type="file" accept="image/*" className="upload"
                                               onChange={this.handleImageChange.bind(this)}/>

                                        <i className="fa fa-upload" aria-hidden="true"></i>
                                    </div>
                                </div>

                                <div className="col-md-4 col-sm-4 col-xs-12">
                                    <input type="text" placeholder="Verify by Video"
                                           value={this.state.award_data.award_video}
                                           onChange={this.handleInputChange.bind(this,'award_video')}/>
                                    <small className="errorMsg">{this.state.website_error_text}</small>
                                </div>
                                <div className="col-md-4 col-sm-4 col-xs-12 lastCol">
                                    <input type="text" placeholder="Verify by Link"
                                           value={this.state.award_data.award_link}
                                           onChange={this.handleInputChange.bind(this,'award_link')}/>
                                    <small className="errorMsg">{this.state.lwebsite_error_text}</small>
                                    <i className="fa fa-info" data-toggle="tooltip" title=""
                                       data-original-title="Links"></i>
                                </div>
                            </div>

                            <div className="row">
                                <div className="col-md-3 col-sm-4 col-xs-12">
                                    <select value={this.state.award_data.year_of_award}
                                            onChange={this.handleChange.bind(this)}>
                                        <option value="">Years</option>
                                        {this.state.years.map(c =>
                                                <option value={c} key={c}>{c}</option>
                                        )}

                                    </select>
                                    <small className="errorMsg">{this.state.year_error_text}</small>


                                </div>
                                <div className="col-md-9 col-sm-8 col-xs-12 lastCol alignRigh1">
                                    <button className="add_val_btn marginTopBott4">{this.state.award_data.button_text}</button>
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-xs-12 lastCol">
                                    <div className="spacerLine"></div>
                                </div>
                            </div>

                            <div className="scroller335">
                              <div className="row">
                                <div className="col-xs-12">
                                  {this.state.awards.map(function (obj, i) {
                                      return <ViewEdit key={i} award_id={obj.award_id} institute={obj.award_name}
                                       project_name={obj.award_for}
                                       year={obj.year_of_award}
                                       hPhoto={obj.photourl} hVideo={obj.award_video}
                                       hLink={obj.award_link}
                                       onClick={local.handleEditClick.bind(null,obj.award_id,local)}
                                       onDeleteClick={local.handleDeleteClick.bind(null,obj.award_id,local)} />
                                  })}
                                </div>
                              </div>
                            </div>

                            <div className="row">
                                <div className="col-sm-12 col-xs-12 alignRigh1">
                                <button onClick={this.Continue.bind(this)} className="btn btn-profile2 big " type="button">Continue <i
                                    className="fa fa-chevron-right"></i></button>
                                </div>
                            </div>

                            <ProgressSlider profileId = {this.props.params.profileId} stateUpdate={updateState}/>
                        </form>
                    </div>


                </div>

            </section>
        )
    }

}
Awards.propTypes = {
    changeRoute: React.PropTypes.func,
};

function mapDispatchToProps(dispatch) {
    return {
        changeRoute: (url) => dispatch(push(url)),
    };
}

export default connect(null,
    mapDispatchToProps)(Awards);
