/*** Created by vinay on 7/13/2016. */
import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import SelectField from 'material-ui/SelectField';
import AutoComplete from 'material-ui/AutoComplete';
import MenuItem from 'material-ui/MenuItem';
import DatePicker from 'material-ui/DatePicker';
import TextField from 'material-ui/TextField';
import Languages from 'components/Languages'
import  {createFilter} from 'react-search-input';

export class Search extends React.Component {


  constructor(props) {
   super(props);
       this.state = {
           data:[],
           open: false,
           proglob:'',
           Qparam:'',
           Gender:1,
           ageGroup:1,
           fees:1,
           Lang:'',
           dataSource1:[],
           searchbox: '',
           searchTerm:'',
       };
   }
  openRoute = (route) => {
    this.props.changeRoute(route);
  };

  componentDidMount() {

    $("[data-toggle='tooltip']").tooltip();
    $('.showFilters a').click(function(e){
		e.preventDefault();
		$(this).toggleClass('active');
		$('.results .filter').toggleClass('open');
	});

  //var url = window.location;
var currentRoutes = this.props.location.pathname;
var stringsarr = currentRoutes.replace('/search/','');
 stringsarr = stringsarr.replace('search/','');
var url = stringsarr.replace('%20',' ');
//var searchstring = this.props.location.query;
  //alert(currentRoutes);
  //console.log(searchstring);

  $.ajax({
  'url': 'http://localhost:8983/solr/kalakar/select',
  'data': {'wt':'json', 'q':'*'+url+'*', 'start':0, 'rows':10000},
  'success': function(data) { //alert(JSON.stringify(data));
    //console.log(data.response.docs);
    var queryparam = data.responseHeader.params.q;
    queryparam= queryparam.slice(1, -1);
    queryparam = queryparam.replace('%20',' ');
    this.setState({
            data: data.response.docs,
            proglob:data.response.numFound,
            Qparam:queryparam,
            searchbox:queryparam,
        }) }.bind(this),
  'dataType': 'jsonp',
  'jsonp': 'json.wrf'
});
}
searchUpdated (classnm, e) {
    this.setState({searchbox: e.target.value})
}
handleChange = (event, index, value) => this.setState({value});
changeclass(classnm, e){
  if ($('.' + classnm).hasClass('active')){
      $('.' + classnm).toggleClass('active');
      $('#bannerBG').removeClass('active');
      $('#search-container').removeClass('active');
     }
     else{
      $('.search_keywords  li').removeClass('active');
      $('.' + classnm).toggleClass('active');
      $('#search-container').addClass('active');
		  $('#bannerBG').addClass('active');
     }

}

handleScheduleChange = (event, date) => {
     this.setState({
       schedule_work_dates: date,

     });
};
submitdata() {
  var searchstring = this.state.searchbox;

    this.props.changeRoute('search/'+searchstring);
}
searchfilter (event, value) {
  if(value==1){
    alert(value);
    this.setState({searchTerm: value, Gender: 'male'});
}
}

    render () {
 const filteredProfile = this.state.data.filter(createFilter(this.state.searchTerm, ['Gender']));

        return (
          <div className="page-content">
            <div id="bannerBG">
              <div className="search_con_wrapper">
                <div className="search_con">
                  <div id="search-container">
                    <p>Search by Keywords</p>
                    <div className="search-form">
                    <label htmlFor="search_field">
                      <input type="text"  title="Search for:" value={this.state.searchbox}  onChange={this.searchUpdated.bind(this,'searchbox')} placeholder="Profession, Age, City" className="search-field" id="search_field" />
                    </label>
                    <input type="submit" value="Search" onClick={this.submitdata.bind(this)} className="search-submit" />
                    </div>
                  </div>
                  <div className="search_othres">
                  <ul className="search_keywords">
                  <li onClick={this.changeclass.bind(this,'klperformer')} className="klperformer"><a href="javascript:void(0)"  data-id="performerList">Performers</a>
                    <div className="search_desc" id="performerList">
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="2">Actors</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Screen Actor" className="subcategory_search" >Screen Actor</a></li>
                          <li><a href="/search/Theater Actor" className="subcategory_search" >Theater Actor</a></li>
                          <li><a href="/search/Agent" className="subcategory_search" data-id="4">Agent</a></li>
                          <li><a href="/search/Acting School" className="subcategory_search" >Acting School</a></li>
                          <li><a href="/search/Junior Artist" className="subcategory_search" >Junior Artist</a></li>
                        </ul>
                      </div>
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="11">Models</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Fashion Designer" className="subcategory_search" >Fashion Designer</a></li>
                          <li><a href="/search/Print/Fashion/Ad" className="subcategory_search" >Print/Fashion/Ad</a></li>
                          <li><a href="/search/Ramp" className="subcategory_search" >Ramp</a></li>
                          <li><a href="/search/Art/Body" className="subcategory_search" >Art/Body</a></li>
                          <li><a href="/search/Event" className="subcategory_search" >Event</a></li>
                          <li><a href="/search/Modeling Agency" className="subcategory_search" >Modeling Agency</a></li>
                          <li><a href="/search/Fresher" className="subcategory_search" >Fresher</a></li>
                        </ul>
                      </div>

                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="20">Dancers</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Choreographer" className="subcategory_search">Choreographer</a></li>
                          <li><a href="/search/Indian Classical" className="subcategory_search">Indian Classical</a></li>
                          <li><a href="/search/Ballet" className="subcategory_search" >Ballet</a></li>
                          <li><a href="/search/Folk" className="subcategory_search" >Folk</a></li>
                          <li><a href="/search/Modern" className="subcategory_search" >Modern</a></li>
                          <li><a href="/search/Dance Coordinator" className="subcategory_search" >Dance Coordinator</a></li>
                          <li><a href="/search/Dance School" className="subcategory_search" >Dance School</a></li>
                          <li><a href="/search/Fresher" className="subcategory_search">Fresher</a></li>
                        </ul>
                      </div>

                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="28">Musicans</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Music Composer" className="subcategory_search" data-id="29">Music Composer</a></li>
                          <li><a href="/search/Jingle/Ad Film" className="subcategory_search" data-id="30">Jingle/Ad Film</a></li>
                          <li><a href="/search/Indian Instrumentalist" className="subcategory_search" data-id="32">Indian Instrumentalist</a></li>
                          <li><a href="/search/Western Instumentalist" className="subcategory_search" data-id="31">Western Instumentalist</a></li>
                          <li><a href="/search/Rock/Pop/Indi/Band" className="subcategory_search" data-id="33">Rock/Pop/Indi/Band</a></li>
                          <li><a href="/search/Disk Jockey" className="subcategory_search" data-id="281">Disk Jockey</a></li>
                          <li><a href="/search/Folk" className="subcategory_search" data-id="282">Folk</a></li>
                          <li><a href="/search/Fresher" className="subcategory_search">Fresher</a></li>
                        </ul>
                      </div>
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="35">Singers/Vocal</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Playback Singer" className="subcategory_search" data-id="283">Playback Singer</a></li>
                          <li><a href="/search/Indian Classical" className="subcategory_search" data-id="37">Indian Classical</a></li>
                          <li><a href="/search/Rock/Pop" className="subcategory_search" data-id="38">Rock/Pop</a></li>
                          <li><a href="/search/Folk" className="subcategory_search" data-id="284">Folk</a></li>
                          <li><a href="/search/Voice Over Artist" className="subcategory_search" data-id="50">Voice Over Artist</a></li>
                          <li><a href="/search/Voice Dubbing" className="subcategory_search" data-id="250">Voice Dubbing</a></li>
                          <li><a href="/search/Voice Language Superviser" className="subcategory_search" data-id="251">Voice Language Superviser</a></li>
                          <li><a href="/search/Fresher" className="subcategory_search" data-id="40">Fresher</a></li>
                        </ul>
                      </div>
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="41">Stunt People</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Stunt Coordinator" className="subcategory_search" data-id="42">Stunt Coordinator</a></li>
                          <li><a href="/search/Fight Supervisor" className="subcategory_search" data-id="43">Fight Supervisor</a></li>
                          <li><a href="/search/Explosives Expert" className="subcategory_search" data-id="44">Explosives Expert</a></li>
                          <li><a href="/search/Martial Arts/Fighting" className="subcategory_search" data-id="45">Martial Arts/Fighting</a></li>
                          <li><a href="/search/Falling/Diving" className="subcategory_search" data-id="46">Falling/Diving</a></li>
                          <li><a href="/search/Parkour" className="subcategory_search" data-id="246">Parkour</a></li>
                          <li><a href="/search/Fresher" className="subcategory_search" data-id="248">Fresher</a></li>
                        </ul>
                      </div>
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="49">Others</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Stand Up Comedians" className="subcategory_search" data-id="52">Stand Up Comedians</a></li>
                          <li><a href="/search/Radio Jockey" className="subcategory_search" data-id="285">Radio Jockey</a></li>
                          <li><a href="/search/Puppetteers" className="subcategory_search" data-id="53">Puppetteers</a></li>
                          <li><a href="/search/Magicians" className="subcategory_search" data-id="54">Magicians</a></li>
                          <li><a href="/search/Mimes" className="subcategory_search" data-id="247">Mimes</a></li>
                          <li><a href="/search/Mimics" className="subcategory_search" data-id="55">Mimics</a></li>
                          <li><a href="/search/Street Performer" className="subcategory_search" data-id="286">Street Performer</a></li>
                          <li><a href="/search/Anchor/MC" className="subcategory_search" data-id="51">Anchor/MC</a></li>
                        </ul>
                      </div>
                    </div>
                  </li>
                  <li onClick={this.changeclass.bind(this,'klcreative')} className="klcreative"><a href="javascript:void(0)" data-id="creativeList">Creatives</a>
                    <div className="search_desc" id="creativeList">
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="58">Directors</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Cinema Director" className="subcategory_search" data-id="59">Cinema Director</a></li>
                          <li><a href="/search/Television Director" className="subcategory_search" data-id="61">Television Director</a></li>
                          <li><a href="/search/Ad Film Director" className="subcategory_search" data-id="60">Ad Film Director</a></li>
                          <li><a href="/search/Theater Director" className="subcategory_search" data-id="62">Theater Director</a></li>
                          <li><a href="/search/Corporate Films Director" className="subcategory_search" data-id="63">Corporate Films Director</a></li>
                          <li><a href="/search/Music Video Director" className="subcategory_search" data-id="64">Music Video Director</a></li>
                          <li><a href="/search/Web Content" className="subcategory_search" data-id="65">Web Content</a></li>
                          <li><a href="/search/Fresher" className="subcategory_search" data-id="66">Fresher</a></li>
                        </ul>
                      </div>
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="67">Directors Assistants</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Directors Assistant" className="subcategory_search" data-id="68">Directors Assistant</a></li>
                          <li><a href="/search/Assistant Director" className="subcategory_search" data-id="69">Assistant Director</a></li>
                          <li><a href="/search/Script Supervisor" className="subcategory_search" data-id="71">Script Supervisor</a></li>
                          <li><a href="/search/Script Doctor" className="subcategory_search" data-id="73">Script Doctor</a></li>
                          <li><a href="/search/Continuity" className="subcategory_search" data-id="72">Continuity</a></li>
                          <li><a href="/search/Fresher" className="subcategory_search" data-id="74">Fresher</a></li>
                        </ul>
                      </div>
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="75">Writers</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Screenwriter" className="subcategory_search" data-id="76">Screenwriter</a></li>
                          <li><a href="/search/Television Script Writer" className="subcategory_search" data-id="77">Television Script Writer</a></li>
                          <li><a href="/search/Ad Film Copywriter" className="subcategory_search" data-id="78">Ad Film Copywriter</a></li>
                          <li><a href="/search/Lyricist/Songwriter" className="subcategory_search" data-id="79">Lyricist/Songwriter</a></li>
                          <li><a href="/search/Fiction/Prose" className="subcategory_search" data-id="80">Fiction/Prose</a></li>
                          <li><a href="/search/Theater Playwright" className="subcategory_search" data-id="81">Theater Playwright</a></li>
                          <li><a href="/search/Poetry" className="subcategory_search" data-id="287">Poetry</a></li>
                          <li><a href="/search/Web Content" className="subcategory_search" data-id="288">Web Content</a></li>
                          <li><a href="/search/Fresher" className="subcategory_search" data-id="83">Fresher</a></li>
                        </ul>
                      </div>
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="84">Journalism</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/TV Journalist" className="subcategory_search" data-id="85">TV Journalist</a></li>
                          <li><a href="/search/TV Editor" className="subcategory_search" data-id="86">TV Editor</a></li>
                          <li><a href="/search/Print Journalist" className="subcategory_search" data-id="87">Print Journalist</a></li>
                          <li><a href="/search/Web Journalist" className="subcategory_search" data-id="88">Web Journalist</a></li>
                          <li><a href="/search/Researcher" className="subcategory_search" data-id="89">Researcher</a></li>
                          <li><a href="/search/Stringer/Fixer" className="subcategory_search" data-id="253">Stringer/Fixer</a></li>
                          <li><a href="/search/Subject Expert" className="subcategory_search" data-id="254">Subject Expert</a></li>
                          <li><a href="/search/Freelance Producer" className="subcategory_search" data-id="289">Freelance Producer</a></li>
                          <li><a href="/search/Fresher" className="subcategory_search" data-id="255">Fresher</a></li>
                        </ul>
                      </div>
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="91">Graphic Designer</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Design Studio" className="subcategory_search" data-id="92">Design Studio</a></li>
                          <li><a href="/search/Web Design, UI, UX" className="subcategory_search" data-id="93">Web Design, UI, UX</a></li>
                          <li><a href="/search/Print/Magazine Design" className="subcategory_search" data-id="94">Print/Magazine Design</a></li>
                          <li><a href="/search/Poster Art Design" className="subcategory_search" data-id="95">Poster Art Design</a></li>
                          <li><a href="/search/Advertising Design" className="subcategory_search" data-id="96">Advertising Design</a></li>
                          <li><a href="/search/Packaging Design" className="subcategory_search" data-id="97">Packaging Design</a></li>
                          <li><a href="/search/Illustrator" className="subcategory_search" data-id="338">Illustrator</a></li>
                          <li><a href="/search/Fresher" className="subcategory_search" data-id="98">Fresher</a></li>
                        </ul>
                      </div>
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="99">Animators</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Animation Technical Designer" className="subcategory_search" data-id="100">Animation Technical Designer</a></li>
                          <li><a href="/search/Animation Supervisor" className="subcategory_search" data-id="101">Animation Supervisor</a></li>
                          <li><a href="/search/Graphic Artist/Modeler" className="subcategory_search" data-id="102">Graphic Artist/Modeler</a></li>
                          <li><a href="/search/Animation Lighting" className="subcategory_search" data-id="103">Animation Lighting</a></li>
                          <li><a href="/search/3D Artist" className="subcategory_search" data-id="104">3D Artist</a></li>
                          <li><a href="/search/Videogame Designer" className="subcategory_search" data-id="105">Videogame Designer</a></li>
                          <li><a href="/search/Cell Animator" className="subcategory_search" data-id="106">Cell Animator</a></li>
                          <li><a href="/search/Story Board Artist" className="subcategory_search" data-id="107">Story Board Artist</a></li>
                          <li><a href="/search/Fresher" className="subcategory_search" data-id="256">Fresher</a></li>
                        </ul>
                      </div>
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="204">Artists</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Painters" className="subcategory_search" data-id="205">Painters</a></li>
                          <li><a href="/search/Sculptor" className="subcategory_search" data-id="206">Sculptor</a></li>
                          <li><a href="/search/Mixed Material" className="subcategory_search" data-id="207">Mixed Material</a></li>
                          <li><a href="/search/Pottery" className="subcategory_search" data-id="261">Pottery</a></li>
                          <li><a href="/search/Wood Craft" className="subcategory_search" data-id="208">Wood Craft</a></li>
                          <li><a href="/search/Metal Craft" className="subcategory_search" data-id="209">Metal Craft</a></li>
                          <li><a href="/search/Installation Artist" className="subcategory_search" data-id="210">Installation Artist</a></li>
                          <li><a href="/search/Graphic Novelist" className="subcategory_search" data-id="292">Graphic Novelist</a></li>
                        </ul>
                      </div>
                    </div>
                  </li>
                  <li onClick={this.changeclass.bind(this,'klproduction')} className="klproduction"><a href="javascript:void(0)" data-id="productionList">Production</a>
                    <div className="search_desc" id="productionList">
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="109">Producers</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Cinema" className="subcategory_search" data-id="110">Cinema</a></li>
                          <li><a href="/search/Television" className="subcategory_search" data-id="112">Television</a></li>
                          <li><a href="/search/Advertising" className="subcategory_search" data-id="111">Advertising</a></li>
                          <li><a href="/search/Theater" className="subcategory_search" data-id="114">Theater</a></li>
                          <li><a href="/search/Documentary" className="subcategory_search" data-id="142">Documentary</a></li>
                          <li><a href="/search/Corporate Films" className="subcategory_search" data-id="113">Corporate Films</a></li>
                          <li><a href="/search/Music Video" className="subcategory_search" data-id="115">Music Video</a></li>
                          <li><a href="/search/Web Content" className="subcategory_search" data-id="290">Web Content</a></li>
                          <li><a href="/search/Live Event" className="subcategory_search" data-id="116">Live Event</a></li>
                          <li><a href="/search/Fresher" className="subcategory_search" data-id="291">Fresher</a></li>
                        </ul>
                      </div>
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="117">Executive Producer</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Features EP" className="subcategory_search" data-id="268">Features EP</a></li>
                          <li><a href="/search/Ad Film EP" className="subcategory_search" data-id="269">Ad Film EP</a></li>
                        </ul>
                      </div>
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="124">Line Producer</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Features" className="subcategory_search" data-id="265">Features</a></li>
                          <li><a href="/search/Ad Film" className="subcategory_search" data-id="266">Ad Film</a></li>
                          <li><a href="/search/Location LP" className="subcategory_search" data-id="267">Location LP</a></li>
                        </ul>
                      </div>
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="125">Advertising</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Boutique Agency" className="subcategory_search" data-id="274">Boutique Agency</a></li>
                          <li><a href="/search/Digital Agency" className="subcategory_search" data-id="275">Digital Agency</a></li>
                        </ul>
                      </div>
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="129">Art</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Production Designer" className="subcategory_search" data-id="272">Production Designer</a></li>
                          <li><a href="/search/Location Make up Artist" className="subcategory_search" data-id="273">Location Make up Artist</a></li>
                        </ul>
                      </div>
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="136">Make up/Hair</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Make-up and Hair" className="subcategory_search" data-id="276">Make-up and Hair</a></li>
                          <li><a href="/search/Make up" className="subcategory_search" data-id="277">Make up</a></li>
                          <li><a href="/search/Hair Stylist" className="subcategory_search" data-id="137">Hair Stylist</a></li>
                        </ul>
                      </div>
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="270">Costume</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Costume Designer/Stylist" className="subcategory_search" data-id="132">Costume Designer/Stylist</a></li>
                          <li><a href="/search/Costume Designer" className="subcategory_search" data-id="294">Costume Designer</a></li>
                          <li><a href="/search/Prosthetics" className="subcategory_search" data-id="293">Prosthetics</a></li>
                          <li><a href="/search/Stylist" className="subcategory_search" data-id="295">Stylist</a></li>
                        </ul>
                      </div>
                    </div>
                  </li>
                  <li onClick={this.changeclass.bind(this,'kltechnical')} className="kltechnical"><a href="javascript:void(0)" data-id="technicalList">Technical</a>
                    <div className="search_desc" id="technicalList">
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="140">Cinematography</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Cinema + Ad DOP" className="subcategory_search" data-id="141">Cinema + Ad DOP</a></li>
                          <li><a href="/search/Television DOP" className="subcategory_search" data-id="296">Television DOP</a></li>
                          <li><a href="/search/Documentary DoP" className="subcategory_search" data-id="229">Documentary DoP</a></li>
                          <li><a href="/search/Sports DoP" className="subcategory_search" data-id="298">Sports DoP</a></li>
                          <li><a href="/search/Camera Operator" className="subcategory_search" data-id="144">Camera Operator</a></li>
                          <li><a href="/search/Camera Assistant" className="subcategory_search" data-id="299">Camera Assistant</a></li>
                          <li><a href="/search/Focus Puller" className="subcategory_search" data-id="146">Focus Puller</a></li>
                          <li><a href="/search/DIT" className="subcategory_search" data-id="300">DIT</a></li>
                        </ul>
                      </div>
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="147">Photographer</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/News" className="subcategory_search" data-id="152">News</a></li>
                          <li><a href="/search/Sports" className="subcategory_search" data-id="301">Sports</a></li>
                          <li><a href="/search/Advertising" className="subcategory_search" data-id="302">Advertising</a></li>
                          <li><a href="/search/Fashion/Portfolio" className="subcategory_search" data-id="149">Fashion/Portfolio</a></li>
                          <li><a href="/search/Product" className="subcategory_search" data-id="303">Product</a></li>
                          <li><a href="/search/Wedding" className="subcategory_search" data-id="148">Wedding</a></li>
                          <li><a href="/search/Event" className="subcategory_search" data-id="151">Event</a></li>
                          <li><a href="/search/Travel" className="subcategory_search" data-id="150">Travel</a></li>
                          <li><a href="/search/Landscape/Architecture" className="subcategory_search" data-id="153">Landscape/Architecture</a></li>
                        </ul>
                      </div>
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="154">Videographer</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/News" className="subcategory_search" data-id="156">News</a></li>
                          <li><a href="/search/Sports" className="subcategory_search" data-id="157">Sports</a></li>
                          <li><a href="/search/Corporate Film" className="subcategory_search" data-id="159">Corporate Film</a></li>
                          <li><a href="/search/Music Video" className="subcategory_search" data-id="122">Music Video</a></li>
                          <li><a href="/search/Wedding" className="subcategory_search" data-id="155">Wedding</a></li>
                          <li><a href="/search/Making of" className="subcategory_search" data-id="304">Making of</a></li>
                        </ul>
                      </div>
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="160">Audio Pro</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Sound Designer" className="subcategory_search" data-id="161">Sound Designer</a></li>
                          <li><a href="/search/Location Recordist" className="subcategory_search" data-id="162">Location Recordist</a></li>
                          <li><a href="/search/Studio Recordist" className="subcategory_search" data-id="163">Studio Recordist</a></li>
                          <li><a href="/search/Sound Assistant" className="subcategory_search" data-id="166">Sound Assistant</a></li>
                          <li><a href="/search/Boom Operator" className="subcategory_search" data-id="165">Boom Operator</a></li>
                          <li><a href="/search/Radio Sound Engineer" className="subcategory_search" data-id="305">Radio Sound Engineer</a></li>
                        </ul>
                      </div>
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="167">Television</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Technical Director" className="subcategory_search" data-id="337">Technical Director</a></li>
                          <li><a href="/search/Senior Cameraman" className="subcategory_search" data-id="168">Senior Cameraman</a></li>
                          <li><a href="/search/Junior Cameraman" className="subcategory_search" data-id="169">Junior Cameraman</a></li>
                          <li><a href="/search/TV Sound Recordist" className="subcategory_search" data-id="170">TV Sound Recordist</a></li>
                          <li><a href="/search/Fixer/Stringer" className="subcategory_search" data-id="171">Fixer/Stringer</a></li>
                          <li><a href="/search/Location Manager" className="subcategory_search" data-id="172">Location Manager</a></li>
                          <li><a href="/search/Assistant" className="subcategory_search" data-id="173">Assistant</a></li>
                        </ul>
                      </div>
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="174">Specialists</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Gaffer" className="subcategory_search" data-id="176">Gaffer</a></li>
                          <li><a href="/search/Grips" className="subcategory_search" data-id="175">Grips</a></li>
                          <li><a href="/search/Steadicam" className="subcategory_search" data-id="177">Steadicam</a></li>
                          <li><a href="/search/Jib/Crane" className="subcategory_search" data-id="178">Jib/Crane</a></li>
                          <li><a href="/search/Dolly" className="subcategory_search" data-id="179">Dolly</a></li>
                          <li><a href="/search/Product/ Pack shot" className="subcategory_search" data-id="306">Product/ Pack shot</a></li>
                          <li><a href="/search/Light Assistants" className="subcategory_search" data-id="180">Light Assistants</a></li>
                          <li><a href="/search/Spot Boy" className="subcategory_search" data-id="181">Spot Boy</a></li>
                        </ul>
                      </div>
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="183">VFX</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Timelapse" className="subcategory_search" data-id="184">Timelapse</a></li>
                          <li><a href="/search/Aerial/Drone" className="subcategory_search" data-id="186">Aerial/Drone</a></li>
                          <li><a href="/search/Slow Motion" className="subcategory_search" data-id="185">Slow Motion</a></li>
                          <li><a href="/search/Underwater" className="subcategory_search" data-id="187">Underwater</a></li>
                          <li><a href="/search/Motion Control" className="subcategory_search" data-id="307">Motion Control</a></li>
                          <li><a href="/search/VFX" className="subcategory_search" data-id="188">VFX</a></li>
                        </ul>
                      </div>
                    </div>
                  </li>
                  <li onClick={this.changeclass.bind(this,'klpproduction')} className="klpproduction"><a href="javascript:void(0)" data-id="postProductionList">Post Production</a>
                    <div className="search_desc" id="postProductionList">
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="189">Editors</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Cinema" className="subcategory_search" data-id="190">Cinema</a></li>
                          <li><a href="/search/Television" className="subcategory_search" data-id="192">Television</a></li>
                          <li><a href="/search/Documentary" className="subcategory_search" data-id="191">Documentary</a></li>
                          <li><a href="/search/Online" className="subcategory_search" data-id="313">Online</a></li>
                          <li><a href="/search/Corporate Film" className="subcategory_search" data-id="193">Corporate Film</a></li>
                          <li><a href="/search/Wedding" className="subcategory_search" data-id="316">Wedding</a></li>
                          <li><a href="/search/Assistant" className="subcategory_search" data-id="195">Assistant</a></li>
                          <li><a href="/search/Fresher" className="subcategory_search" data-id="182">Fresher</a></li>
                        </ul>
                      </div>
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="197">Colourist/DI</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Colourist" className="subcategory_search" data-id="200">Colourist</a></li>
                          <li><a href="/search/Retoucher" className="subcategory_search" data-id="252">Retoucher</a></li>
                        </ul>
                      </div>
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="308">Studios/Suites</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Editing" className="subcategory_search" data-id="309">Editing</a></li>
                          <li><a href="/search/DI" className="subcategory_search" data-id="310">DI</a></li>
                          <li><a href="/search/Sound Editing" className="subcategory_search" data-id="311">Sound Editing</a></li>
                        </ul>
                      </div>
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="312">VFX Post</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/VFX Producer" className="subcategory_search" data-id="317">VFX Producer</a></li>
                          <li><a href="/search/VFX Artist" className="subcategory_search" data-id="203">VFX Artist</a></li>
                        </ul>
                      </div>
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="314">Sound Post</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Sound Editor" className="subcategory_search" data-id="164">Sound Editor</a></li>
                          <li><a href="/search/Foley" className="subcategory_search" data-id="202">Foley</a></li>
                          <li><a href="/search/Re-recording Mixer" className="subcategory_search" data-id="315">Re-recording Mixer</a></li>
                          <li><a href="/search/ADR Recordist" className="subcategory_search" data-id="318">ADR Recordist</a></li>
                        </ul>
                      </div>
                    </div>
                  </li>
                  <li onClick={this.changeclass.bind(this,'klservice')} className="klservice"><a href="javascript:void(0)" data-id="serviceList">Services</a>
                    <div className="search_desc" id="serviceList">
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="211">Rentals</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Camera Rental" className="subcategory_search" data-id="212">Camera Rental</a></li>
                          <li><a href="/search/Cinema Lights" className="subcategory_search" data-id="319">Cinema Lights</a></li>
                          <li><a href="/search/Special Lense" className="subcategory_search" data-id="320">Special Lense</a></li>
                          <li><a href="/search/Photo Flash" className="subcategory_search" data-id="321">Photo Flash</a></li>
                          <li><a href="/search/Grips/Accessories" className="subcategory_search" data-id="214">Grips/Accessories</a></li>
                          <li><a href="/search/Costume Rental" className="subcategory_search" data-id="216">Costume Rental</a></li>
                          <li><a href="/search/Prop Rental" className="subcategory_search" data-id="215">Prop Rental</a></li>
                          <li><a href="/search/Automobile Rental" className="subcategory_search" data-id="47">Automobile Rental</a></li>
                          <li><a href="/search/Misc Equipment" className="subcategory_search" data-id="213">Misc Equipment</a></li>
                        </ul>
                      </div>
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="218">Sales</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Camera/ Audio Equipment" className="subcategory_search" data-id="322">Camera/ Audio Equipment</a></li>
                          <li><a href="/search/Digital Software" className="subcategory_search" data-id="271">Digital Software</a></li>
                          <li><a href="/search/Digital Hardware" className="subcategory_search" data-id="220">Digital Hardware</a></li>
                          <li><a href="/search/Art Equipment" className="subcategory_search" data-id="323">Art Equipment</a></li>
                          <li><a href="/search/Props" className="subcategory_search" data-id="221">Props</a></li>
                          <li><a href="/search/Production Material" className="subcategory_search" data-id="244">Production Material</a></li>
                          <li><a href="/search/Misc Equipment" className="subcategory_search" data-id="249">Misc Equipment</a></li>
                        </ul>
                      </div>
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="222">Event specialists</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Wedding/Party" className="subcategory_search" data-id="223">Wedding/Party</a></li>
                          <li><a href="/search/Cultural Events" className="subcategory_search" data-id="224">Cultural Events</a></li>
                          <li><a href="/search/Business/Corporate" className="subcategory_search" data-id="225">Business/Corporate</a></li>
                        </ul>
                      </div>
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="226">Filmfestival</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Multi Genre" className="subcategory_search" data-id="227">Multi Genre</a></li>
                          <li><a href="/search/Fiction" className="subcategory_search" data-id="228">Fiction</a></li>
                          <li><a href="/search/Documentary" className="subcategory_search" data-id="331">Documentary</a></li>
                          <li><a href="/search/Animation" className="subcategory_search" data-id="332">Animation</a></li>
                          <li><a href="/search/Other Specialised" className="subcategory_search" data-id="230">Other Specialised</a></li>
                        </ul>
                      </div>
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="235">Set Services</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Catering" className="subcategory_search" data-id="237">Catering</a></li>
                          <li><a href="/search/Transport" className="subcategory_search" data-id="238">Transport</a></li>
                        </ul>
                      </div>
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="324">Location/Venue</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Shooting Floor" className="subcategory_search" data-id="325">Shooting Floor</a></li>
                          <li><a href="/search/Bungalow" className="subcategory_search" data-id="327">Bungalow</a></li>
                          <li><a href="/search/Dance Rehearsal" className="subcategory_search" data-id="329">Dance Rehearsal</a></li>
                          <li><a href="/search/Exterior Location" className="subcategory_search" data-id="326">Exterior Location</a></li>
                          <li><a href="/search/Wedding/ Party" className="subcategory_search" data-id="330">Wedding/ Party</a></li>
                          <li><a href="/search/Auditorium" className="subcategory_search" data-id="328">Auditorium</a></li>
                        </ul>
                      </div>
                      <div className="search_dd_cat">
                        <h3><a href="javascript:void(0)" data-id="333">Office Services</a> <span className="mobile_back_btn"></span> </h3>
                        <ul className="aaa">
                          <li><a href="/search/Legal specialists" className="subcategory_search" data-id="236">Legal specialists</a></li>
                          <li><a href="/search/Digital Printing" className="subcategory_search" data-id="335">Digital Printing</a></li>
                          <li><a href="/search/Flex Printing" className="subcategory_search" data-id="233">Flex Printing</a></li>
                          <li><a href="/search/Screen Printing" className="subcategory_search" data-id="234">Screen Printing</a></li>
                        </ul>
                      </div>
                    </div>
                  </li>
                  </ul>
                  </div>
                </div>
              </div>
            </div>
            <div className="results">
              <div className="container">
                <div className="row result-count">
                  <div className="col-sm-3 col-xs-12 pull-right right"><a href="#" className="greyBtn">Reset Filter</a></div>
                  <div className="col-sm-4 col-xs-12">
                    <p>Showing Results for: <strong>{this.state.Qparam}</strong></p>
                  </div>
                  <div className="col-sm-4 col-xs-12">
                    <p>Current Filter Results: <strong>{this.state.proglob} Profiles</strong></p>
                  </div>
                </div>
                <div className="row">
                  <div className="filter">
                    <div className="col-md-2 col-sm-4 col-xs-12">
                    <SelectField value={this.state.Gender} onChange={this.searchfilter} className="SearchSelectBox">
                      <MenuItem value={0}  primaryText="Gender" />
                      <MenuItem value={1}  primaryText="Male" />
                      <MenuItem value={2}  primaryText="Female" />
                      <MenuItem value={3}  primaryText="Other" />
                    </SelectField>

                    </div>
                    <div className="col-md-2 col-sm-4 col-xs-12">
                    <SelectField value={this.state.ageGroup} onChange={this.handleChange} className="SearchSelectBox">
                      <MenuItem value={1} primaryText="Age Group" />
                      <MenuItem value={'10-20'} primaryText="10-20" />
                      <MenuItem value={'20-25'} primaryText="20-25" />
                      <MenuItem value={'25-30'} primaryText="25-30" />
                      <MenuItem value={'30-35'} primaryText="30-35" />
                      <MenuItem value={'35-40'} primaryText="35-40" />
                      <MenuItem value={'40-50'} primaryText="40-50" />
                      <MenuItem value={'50-60'} primaryText="50-60" />
                      <MenuItem value={'60-70'} primaryText="60-70" />
                      <MenuItem value={'70 Above'} primaryText="70 Above" />
                    </SelectField>
                    </div>
                    <div className="col-md-2 col-sm-4 col-xs-12">
                    <div className="location dropdown"> <a data-toggle="dropdown" href="#location">  <Languages /> </a>  </div>
                    </div>
                    <div className="col-md-2 col-sm-4 col-xs-12">
                      <div className="location dropdown"> <a data-toggle="dropdown" href="#location">Location</a>
                        <div className="dropdown-menu">
                          <div className="col-sm-4">
                            <label>Country</label>
                            <TextField hintText="Country" className="SearchInputTxt"/>
                          </div>
                          <div className="col-sm-4">
                            <label>State</label>
                            <TextField hintText="State" className="SearchInputTxt"/>
                          </div>
                          <div className="col-sm-4">
                            <label>City</label>
                            <TextField hintText="City" className="SearchInputTxt"/>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="col-md-2 col-sm-4 col-xs-12">
                      <SelectField value={this.state.fees} onChange={this.handleChange} className="SearchSelectBox">
                        <MenuItem value={1} primaryText="Average Fee" />
                        <MenuItem value={'5000'} primaryText="Below 5000 /day" />
                        <MenuItem value={'5000-10000'} primaryText="5000-10000 /day" />
                        <MenuItem value={'15000-20000'} primaryText="15000-20000 /day" />
                        <MenuItem value={'20000-30000'} primaryText="20000-30000 /day" />
                        <MenuItem value={'30000-40000'} primaryText="30000-40000 /day" />
                        <MenuItem value={'40000-50000'} primaryText="40000-50000 /day" />
                        <MenuItem value={'50000-75000'} primaryText="50000-75000 /day" />
                        <MenuItem value={'75000-100000'} primaryText="75000-1L /day" />
                        <MenuItem value={'100000'} primaryText="Above 1L /day" />
                      </SelectField>
                    </div>
                    <div className="col-md-2 col-sm-4 col-xs-12">
                    <div className="calendar">
                    <DatePicker hintText="Availability" value={this.state.schedule_work_dates} autoOk = {true} container="inline"
                    onChange={this.handleScheduleChange} className="date_pick hasDatepicker SearchPicDate"/>
                    </div></div>
                  </div>
                </div>
                <div className="row">
                <div className="showFilters">
                  <a href="javascript:void(0);"></a>
                </div>

                  <div id="sorting">
                    <label>Sort by</label>
                    <SelectField value={1} onChange={this.handleChange} className="SearchSelectBox2">
                      <MenuItem value={1} primaryText="Name" />
                      <MenuItem value={2} primaryText="Ratings" />
                      <MenuItem value={3} primaryText="Avg. Professional Fee" />
                      <MenuItem value={4} primaryText="Workcred" />
                      <MenuItem value={4} primaryText="Newest" />
                      <MenuItem value={4} primaryText="Likes" />
                    </SelectField>
                  </div>
                </div>
                <div className="row">
                  <div className="col-xs-12 search_result_out">
                    <ul>
                    {filteredProfile.map(c =>
                      <li>

                      <div className="inner">
                        <div className="result_images">
                            <a href="#"><img src={c.ProfilePic} alt={c.Fullname} /></a>
                              <span className="result_flag">
                                <span className="report_result"><a href="javascript:void(0);"><i className="fa fa-info"></i></a> Report</span>
                                  <span className="like_result"><a href="javascript:void(0);"><i className="fa fa-heart"></i></a><span>1</span></span>
                              </span>
                        </div>

                        <div className="result_info">
                          <div className="result_upper">
                              <a href="#"><h3>{c.Fullname}</h3></a>
                              <h4>{c.Procat}</h4>
                              <h4>{c.CityName}</h4>
                          </div>


                          <div className="result_upper">
                              <span className="share_links">
                                  <span className="p_share"><a href="javascript:void(0)" title="Share" data-toggle="tooltip"><i className="fa fa-share-alt"></i></a></span>
                                  <span className="p_like"><a href="javascript:void(0);" title="Like" data-toggle="tooltip"><i className="fa fa-star"></i></a></span>
                              </span>

                              <span className="rating">
                                  <h2>{c.Rating}</h2>
                                  <p>INCRED RATING</p>
                              </span>
                          </div>

                          <div className="result_upper">
                              <span className="average">
                                <p>Avg <strong><i className="fa fa-inr"></i>  {c.WorkRate}</strong></p>
                              </span>
                              <span className="workcred">
                                <p>Work Cred <strong>{c.worckredTotal}</strong></p>
                              </span>
                          </div>

                        </div>
                        </div>
                      </li>

                    )}


                    </ul>
                  </div>
                </div>
              </div>
            </div>
            </div>
          );
        }
      }
      Search.propTypes = {
        changeRoute: React.PropTypes.func,
      };

      function mapDispatchToProps(dispatch) {
        return {
          changeRoute: (url) => dispatch(push(url)),
        };
      }

      export default connect(null, mapDispatchToProps)(Search);
