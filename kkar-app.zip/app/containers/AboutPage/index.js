
import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';

import Button from 'components/Button';
import H1 from 'components/H1';

export class AboutPage extends React.Component {

  /**
   * Changes the route
   *
   * @param  {string} route The route we want to go to
   */
 openRoute = (route) => {
    this.props.changeRoute(route);
  };
  /**
   * Changed route to '/'
   */
  openHomePage = () => {
    this.openRoute('/');
  };
openFeaturesPage = () => {
    this.openRoute('/features');
  };

  render() {
    return (
      <section className="inner_page">
        <div className="cms_page">
          <div className="container">
            <div className="row">
                <div className="col-xs-12">
                  <div className="entry-header">
                    <h1>about us</h1>
                  </div>
                </div>
            </div>
          </div>

          <div className="menu_cms">
          </div>

            <div className="container">
              <div className="row">
                  <div className="col-xs-12">
                    <div className="entry-content">
                      <p>Kalakar<br/>
                      The Digital Home for India’s Artists, Technicians, and Media Services</p>
                      <p>Objective<br/>
                      Our objective is to create a pan-national, inclusive, equally representative, multi lingual digital space for all of India’s Artists, Technicians and Media Services.</p>
                      <p>We’d like to create a business, a community and an eco system – where art, artists, professionalism, business, talent, knowledge, information and integrity abound.</p>
                      <p>Our value offering to Individuals</p>
                      <p>Every Individual gets. . .</p>
                      <ul>
                        <li><span>A multi functional personal website.</span></li>
                        <li><span>Information about job opportunities in their specific professional skill set.</span></li>
                        <li><span>Listed in the biggest search engine for their professional category.</span></li>
                        <li><span>Transparent search parameters to improve their professional rating.</span></li>
                        <li><span>A private messaging service with filters and quality control protocols.</span></li>
                        <li><span>Multiple point analytics for each professional profile they create.</span></li>
                        <li><span>And many other features.</span></li>
                      </ul>

                      <p>Our value offering to Businesses</p>
                      <ul>
                        <li><span>Tap into the largest resource pool of professional artistic talent and services.</span></li>
                        <li><span>Connect with difficult to reach top level professionals.</span></li>
                        <li><span>Get clean, verifiable and transparent information.</span></li>
                        <li><span>Messaging protocols to ensure precise and qualitative communication.</span></li>
                        <li><span>Get customized dashboards for you business needs.</span></li>
                        <li><span>Use our specialists to find the right talent for your work.</span></li>
                      </ul>

                      <p>Community and Eco System</p>
                      <p>Kalakar presents itself as more than a market place linking people looking for work with people providing it.</p>
                      <p>First, we want to be a space for the individual’s identity. That I, as an artist, a technician, a professional – am proud of my Kalakar page because it represents me to the outside world. I take great pride in showcasing what work I’ve done thus far, what my interests are, where I’d like to grow professionally and as an individual.</p>
                      <p>Secondly, we inform our customers what is taking place in what part of the country in various artistic and professional spheres.</p>
                      <p>Thirdly, we create video content to share with our customers as an on-boarding exercise, as community engagement practice and as skill enhancement tools. For example, we make short films on how a director or casting director casts for a series of roles or how prosthetics are created and applied. Teaching practices, skill sets, on set experiences, etc.</p>
                    </div>
                  </div>
            </div>
            </div>
          </div>

      </section>

    );
  }
}

AboutPage.propTypes = {
  changeRoute: React.PropTypes.func,
};

function mapDispatchToProps(dispatch) {
  return {
    changeRoute: (url) => dispatch(push(url)),
  };
}

export default connect(null, mapDispatchToProps)(AboutPage);
