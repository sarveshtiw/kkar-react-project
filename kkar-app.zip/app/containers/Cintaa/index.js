import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';




export class Cintaa extends React.Component {
    openRoute = (route) => {
        this.props.changeRoute(route);
    };

    render() {
        return (
            <div className="inner-page testimonialPage ">

                <div className="container cinta"  >

                                <article className="article"  >
                                        <h1>CINTAA</h1>

                                    <div className="entry-content">


                                        <p>
                                            <img
                                                src="https://gallery.mailchimp.com/6fdd07f48c1e0fd2825f249af/images/9c5e76b2-f8e3-42e3-a143-8f968e1fbe95.png"
                                                alt
                                                width={66}
                                                height={79}/>
                                        </p>
                                        <h6 >
                                            Advantages exclusively to CINTAA members:
                                        </h6>

                                        <p>
                                            Subscription discount and assistance:<br />
                                            Rs 200 Discount to CINTAA members if they join in the next 6 months.<br />
                                            The offer ends end February 2017.<br />
                                            Assistance by our staff for CINTAA members self creating their profiles.
                                        </p>


                                        <p>
                                            Full profile creation by the Kalakar.pro team for a discounted rate:<br />
                                            We will make and optimise your entire Kalakar profile with the data and
                                            information provided for only 200 Rs.
                                        </p>



                                        <p>
                                            Please find the CINTAA Discount code in the member area <a
                                            href="http://www.cintaa.net">www.cintaa.net</a>
                                        </p>

                                        <h6>Kalakar.Pro</h6>

                                        <p>
                                            Kalakar provides an individual profile web page as your online CV, showreel
                                            and portfolio. It shows your skills, achievements, project history, industry
                                            connections, endorsements and availabilities Making Kalakar.pro the top
                                            industry search engine.
                                        </p>



                                        <p>
                                            We create larger and equal opportunity to our members.
                                        </p>



                                        <p>
                                            Giving you visibility, points of contact and quality leads to potential
                                            hirers, job information, direct bookings and casting calls.
                                        </p>



                                        <p>
                                            Kalakar’s Classified Ads (Apply, Get Short Listed, Audition directly) or put
                                            out your own casting call
                                        </p>



                                        <p>
                                            180+ Artist, Technician and Service categories listed to create an
                                            exhaustive industry platform.
                                        </p>



                                        <p>
                                            250+ Top Production Houses and Ad Agencies are being contacted to be future
                                            users of Kalakar for casting.
                                        </p>



                                        <p>
                                            We link with International Bodies, channels and production houses to give
                                            you International Project Leads
                                        </p>

                                        <p>
                                            Kalakar is positioned to get all information of International Productions in
                                            India, across all media.
                                        </p>



                                        <p>
                                            In our Members area you will find ears to the ground information from top
                                            production houses, Information from&nbsp; ADs and Line Producers,&nbsp; and
                                            our personal contacts.
                                        </p>



                                        <p>
                                            The members only community provides guidance with forums for each
                                            professional community. As well as exclusive videos (tutorials, tips,
                                            technicals, industry relevant interviews.
                                        </p>


                                    </div>

                                </article>
                            </div>
                </div>

        )
    }
}
Cintaa.propTypes = {
    changeRoute: React.PropTypes.func,
};

function mapDispatchToProps(dispatch) {
    return {
        changeRoute: (url) => dispatch(push(url)),
    };
}

export default connect(null,
    mapDispatchToProps)(Cintaa);
