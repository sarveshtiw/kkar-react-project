/**
 * Created by Neeru on 7/13/2016.
 */
//import React from 'react';
import React, { Component } from 'react';
import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
import {DashboardHeader} from 'components/DashboardHeader_Component';
import cookie from 'react-cookie';
var util = require('utils/request');
import { API_URL } from 'containers/App/constants'

export class DashBoardaffiliate extends React.Component {
constructor(props) {
    super(props);
    this.state ={
      userId : cookie.load('userId'),
      affiliateHistory : [],
      withdrawHistory : [],
      total_code_used:'',
      total_income_affiliate:'',
      currentBalance:'',
      affiCode:'',
      copytext:'Copy',
      balance:'',
      withdrawBalance:'',
      HolderName:'',
      ACtype:'',
      ACNumber:'',
      IFSCcode:'',
      errorbal:'',
      errorfname:'',
      errortype:'',
      errornum:'',
      errorcode:'',
      successmessage:'',
      open: false
    }
 }


componentDidMount() {
   document.title = "My Dashboard | Kalakar";
  $('.withdrawhistory').hide();
   $('.viewtable').click(function () {
       $('.withdrawhistory').show();
       $('.affiliatetransaction').hide();
       $('.viewtable').html('Withdraw History');
   })
   $('.hidewithdraw').click(function () {
        $('.withdrawhistory').hide();
        $('.affiliatetransaction').show();
        $('.viewtable').html('View Withdraw History');
    });
    var local = this;
    var userid = this.state.userId;
    var param = {action:'affiliate_history', custId: userid}
    util.getSetData(param, function (response) {
      console.log(response);
    if(response.status === "success"){
      local.setState({ affiliateHistory : [response.data] });
         }
         else{
            alert("Please try again.");
         }

     });

     var param1 = {action:'withdraw_history', custId: userid}
     util.getSetData(param1, function (response) {
     if(response.status == "success"){
       local.setState({ withdrawHistory : [response.data] });

          }
          else{
             alert("Please try again.");
          }
      });

      var param2 = {action:'total_code_used', custId: userid}
      util.getSetData(param2, function (data) {
      if(data.status == "success"){
        local.setState({total_code_used:data.total_code_used});

           }
           else{
              alert("Please try again.");
           }
       });
       var param3 = {action:'total_income_affiliate', custId: userid}
        $.ajax({
           url: API_URL,
           type: "POST",
           dataType: 'json',
           data: param3,
           success: function (data) {
             console.log(data);
                local.setState({total_income_affiliate:data.earning_affiliate});
           }.bind(this)

       });
        var param4 = {action:'current_bal', custId: userid}
        util.getSetData(param4, function (data) {
        if(data.status == "success"){
          local.setState({currentBalance:data.current_bal});

             }
             else{
                alert("Please try again.");
             }
         });
         var param5 = {action:'get_affiliate', customer_id: userid}
         util.getSetData(param5, function (data) {
         if(data.status == "success"){
           local.setState({affiCode:data.data});
              }
              else{
                console.log(data);

              }
          });
  }

  copyToClipboard(elem) {    
            this.setState({copytext:'Copied'});
            var field = document.getElementById('affiliatecode');
            field.focus();
            field.setSelectionRange(0, field.value.length);
            document.execCommand("copy");
            alert("Artist Profile has been copied on clipboard.");

    }

  handleOpen = () => {
       this.setState({open: true});
     };
transferTowallet(){
var withdrawbalance = this.state.withdrawBalance;
var errorf='';
if(!withdrawbalance){this.setState({errorbal: 'Please enter withdrawal balance'}); errorf='Y';}
var HolderName = this.state.HolderName;
if(!HolderName){this.setState({errorfname: 'Please enter name'}); errorf='Y';}
var ACtype = this.state.ACtype;
if(!ACtype){this.setState({errortype: 'Please select accout type'}); errorf='Y';}
var ACNumber = this.state.ACNumber;
if(!ACNumber){this.setState({errornum: 'Please enter account number'}); errorf='Y';}
var IFSCcode = this.state.IFSCcode;
if(!IFSCcode){this.setState({errorcode: 'Please enter IFSC code'}); errorf='Y';}
if(errorf!=''){return false;}
else {
  var local= this;
var accountype = this.state.ACtype;
var balance = this.state.withdrawBalance;
var accountnumber = this.state.ACNumber;
var accountholder = this.state.HolderName;
var ifsccode = this.state.IFSCcode;
var userId = this.state.userId;
  var formdata = {action:'withdraw', accounttype:accountype, balance:balance,accountnumber:accountnumber, accountholder:accountholder,ifsccode:ifsccode, userId: userId }
  util.getSetData(formdata, function (data) {
  if(data.status == "success"){
local.setState({successmessage:data.message, withdrawBalance:'', HolderName:'', ACtype:'', ACNumber:'', IFSCcode:'',});
}
       else{
        local.setState({successmessage:data.message});

       }
   });


}
}
changeEventHandler(event, e){
if(event=='withdrawBalance'){this.setState({ withdrawBalance : e.target.value });}
if(event=='HolderName'){this.setState({ HolderName : e.target.value });}
if(event=='ACtype'){this.setState({ ACtype : e.target.value });}
if(event=='ACNumber'){this.setState({ ACNumber : e.target.value });}
if(event=='IFSCcode'){this.setState({ IFSCcode : e.target.value });}
}
  handleClose = () => {
    this.setState({open: false, withdrawBalance:'', HolderName:'', ACtype:'', ACNumber:'', IFSCcode:'',});

       };

  render() {
    const actions = [
      <RaisedButton
        label="X"
        primary={true}
        className="cancelBtnPopup"
        onTouchTap={this.handleClose}
      />,
      <FlatButton
        label="WITHDRAWAL"
        primary={true}
        className="whithdrawalBtn"
        keyboardFocused={true}
        onTouchTap={this.transferTowallet.bind(this)}
      />,
    ];
    var localvar = this;
    return (
      <div className="PageMinHeight">
        <DashboardHeader page="Affiliates" />
        <div className="container">
            <div className="row">
              <div className="affiliates">
                <div className="col-md-5 affiliat-left">
                    <h1> Your Affiliate code</h1>
                    <div className="copy-code"><input type="text" className="code" id="affiliatecode" value={this.state.affiCode}  disabled /><button type="submit" id="copycode" onClick={this.copyToClipboard.bind(this,'affiliate-code')}>{this.state.copytext}</button></div>
                    <ul className="boxes">
                        <li>
                            <h2>{this.state.total_code_used}</h2>
                            <p>Total Code Usage by Friends and Acquaintances</p>
                        </li>
                        <li>
                            <h2><i className="fa fa-inr"></i> {this.state.total_income_affiliate}</h2>
                            <p>Total Earnings via Affilate Program</p>
                        </li>
                        <li>
                            <h2><i className="fa fa-inr"></i>{this.state.total_income_affiliate}</h2>
                            <p>Current Balances</p>
                        </li>
                        <li className="transfer-wall fancybox" onTouchTap={this.handleOpen} href="#transfertoaccount">
                            <a href="javascript:void(0)">Transfer to Wallet</a>

                        </li>
<Dialog
          title="Withdraw Balance"
          className="withdrawBalPopup"
          titleClassName="withBalPopupH2"
          bodyClassName="withdrawBalBody"
          actions={actions}
          modal={false}
          open={this.state.open}
          onRequestClose={this.handleClose}
        >
        <div className="withdrawform">
              <p className="errorMsg"><b>{this.state.successmessage}</b></p>
              <div className="form-group">
                <label>Balance:</label>
                <input type="text" disabled value={this.state.total_income_affiliate}/>
              </div>
              <div className="form-group">
                <label>Withdraw Balance*:</label>
                <input type="text" value={this.state.withdrawBalance} onChange={this.changeEventHandler.bind(this, "withdrawBalance")} />
                <small  className="errorMsg">{this.state.errorbal}</small>
              </div>
              <div className="form-group">
                <label>A/C Holder Name*:</label>
                <input type="text" value={this.state.HolderName} onChange={this.changeEventHandler.bind(this,'HolderName')} />
                <small  className="errorMsg">{this.state.errorfname}</small>
           </div>
              <div className="form-group">
               <label>A/C Type*:</label>
                <select value={this.state.ACtype} onChange={this.changeEventHandler.bind(this,'ACtype')}>
                  <option value="">select type</option>
                  <option value="saving account">saving account</option>
                  <option value="current account">current account</option>
                </select>
                <small  className="errorMsg">{this.state.errortype}</small>
              </div>

              <div className="form-group">
                <label>A/C Number*:</label>
                <input type="text" value={this.state.ACNumber} onChange={this.changeEventHandler.bind(this,'ACNumber')}/>
                <small  className="errorMsg">{this.state.errornum}</small>
              </div>
              <div className="form-group">
                      <label>IFSC Code*:</label>
                      <input type="text" value={this.state.IFSCcode} onChange={this.changeEventHandler.bind(this,'IFSCcode')}/>
                      <small  className="errorMsg">{this.state.errorcode}</small>
              </div>
        </div>
        </Dialog>
                    </ul>
                    <span> <a href="javascript:void(0);" className="viewtable">View Withdraw History</a></span>
                </div>
                <div className="col-md-7">
                    <div className="affilate-right affiliatetransaction">
                    <div className="table-responsive">
                        <table className="table table-striped" style={{marginTop: '33px'}}>
                            <tbody> <tr>
                                <th>Name</th>
                                <th>Profile</th>
                                <th>Date</th>
                                <th className="text-right">Purchase</th>
                                <th className="text-right">Your Earnings</th>
                            </tr>
                            {(this.state.affiliateHistory!='')?this.state.affiliateHistory.map(c =>
                            <tr>
                            <td>{c.customer_name}</td>
                            <td>{c.category_name}</td>
                            <td>{c.order_date}</td>
                            <td className="text-right"><i className="fa fa-inr"></i> {c.order_amount}</td>
                            <td className="text-right"><i className="fa fa-inr"></i> {c.earning}</td>
                            </tr>
                          ):''}
                        </tbody>
                        </table>
                    </div>
                    </div>
                    <div className="affilate-right withdrawhistory">
                        <span><a href="javascript:void(0);" className="hidewithdraw">Hide</a></span>
                        <div className="table-responsive">
                        <table className="table table-striped">
                            <tbody><tr>
                                <th>A/C Holder</th>
                                <th className="text-right">A/C Type</th>
                                <th className="text-right">A/C Number</th>
                                <th className="text-right">IFSC Code</th>
                                <th >Requested Amount</th>
                                <th >Paid Amount</th>
                                <th >Status</th>
                            </tr>
                              { (this.state.withdrawHistory!='')?this.state.withdrawHistory.map(d =>
                                <tr>
                                    <td>{d.account_holder}</td>
                                    <td className="text-right">{d.account_type}</td>
                                    <td  className="text-right">{d.account_number}</td>
                                    <td  className="text-right">{d.IFSC_code}</td>
                                    <td >{d.amount}</td>
                                    <td >{d.paid_amount}</td>
                                    <td >{(d.status==0)?"Pending":"Paid"}</td>
                                </tr>
                              ):''}

                        </tbody></table>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        </div>
      </div>
      );
  }
}

export default DashBoardaffiliate;
