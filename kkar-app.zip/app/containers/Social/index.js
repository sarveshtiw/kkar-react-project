import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import {DashboardMenu} from 'components/DashboardMenu';
import TextField from 'material-ui/TextField';
import {ViewEdit} from 'components/ViewEdit_Component';
import {ProgressSlider} from 'components/ProgressSlider';
var util = require('utils/request');



export class Social extends React.Component {

    openRoute = (route) => {
        this.props.changeRoute(route);
    };

    constructor(props) {
        super(props);
        this.state = {
            stateUpdate:false,
            form_data: {
            facebook: '',
            twitter: '',
            wiki: '',
            youtube_link: '',
            whatsapp_link: '',
            google_link: '',
            instagram_link: '',
                result :null,
                resultMsg : ''
        }
    }}
    componentDidMount() {
      document.title = "Extended Profile | Kalakar";
        var param = {action: 'social_links_get', profile_id: this.props.params.profileId}
        var formState = this;
        util.getSetData(param, function (data) {
            if (data.status == "success")
            {
                formState.setState({
                    form_data: {
                        facebook_link:(data.data.facebook== null)?'':decodeURIComponent(data.data.facebook) ,
                        twitter_link: (data.data.twitter== null)?'':decodeURIComponent(data.data.twitter),
                        wordpress_link: (data.data.wiki == null)?'':decodeURIComponent(data.data.wiki),
                        youtube_link: (data.data.youtube_link == null)?'':decodeURIComponent(data.data.youtube_link),
                        whatsapp_link: (data.data.whatsapp_link == null)?'':decodeURIComponent(data.data.whatsapp_link),
                        google_link: (data.data.google_link == null)?'':decodeURIComponent(data.data.google_link),
                        instagram_link: (data.data.instagram_link ==null)? '':decodeURIComponent(data.data.instagram_link)
                    }
                })
            }
        });
        jQuery('#lightgallery').lightGallery();
        jQuery('.lightgallery-single-image').lightGallery();
        jQuery('.lightgallery-single-video').lightGallery();
    }


    handleInputChange(name, e) {
        var change = {};
        change.form_data = this.state.form_data;
        change.form_data[name] = e.target.value;
        this.setState(change);
        if(name == 'facebook_link'){
            this.isDisabledFacebook();
        }
        if(name == 'twitter_link'){
            this.isDisabledTwitter();
        }
        if(name == 'instagram_link'){
            this.isDisabledInsta();
        }
        if(name == 'google_link'){
            this.isDisabledGoogle();
        }
        if(name == 'youtube_link'){
            this.isDisabledYoutube();
        }
        if(name == 'whatsapp_link'){
            this.isDisabledphone();
        }
        if(name == 'wordpress_link'){
            this.isDiasbleWiki();
        }
        if(name == 'whatsapp_link'){
            this.isDisabledphone();
        }


    }
    validateWatsapp(value){
        var e=/^([0|\+[0-9]{1,5})?([7-9][0-9]{9})$/;
        return e.test(value);
    }
    isDisabledphone() {
        let phoneIsValid = false;
        if (this.state.form_data.whatsapp_link == null ||this.state.form_data.whatsapp_link === "" ||this.state.form_data.whatsapp_link === undefined) {
            phoneIsValid = true;
            this.setState({
                phone_error_text: null
            });
        } else {
            if (this.validateWatsapp(this.state.form_data.whatsapp_link)) {
                phoneIsValid = true
                this.setState({
                    phone_error_text: null
                });
            } else {
                this.setState({
                    phone_error_text: "Sorry, this is not a valid format"
                });
            }

        }
        return phoneIsValid;
    }
    validateTwitter(value){
        var exp =/(?:http|https):\/\/(?:www.)?twitter\.com\/(#!\/)?[a-zA-Z0-9_]+/;
        return exp.test(value);
    }
    isDisabledTwitter() {
        let urlIsValid = false;
        if (this.state.form_data.twitter_link === "" || this.state.form_data.twitter_link === null ||this.state.form_data.twitter_link === undefined ) {
            urlIsValid=true;
            this.setState({
                twebsite_error_text: null
            });
        } else {
            if (this.validateTwitter(this.state.form_data.twitter_link)) {
                urlIsValid = true;
                this.setState({
                    twebsite_error_text: null
                });
            }
            else {
                this.setState({
                    twebsite_error_text: "Sorry, this is not a valid format"
                });
            }
        }
        return urlIsValid;
    }
    validateFacebook(value){
        var exp =/(?:(?:http|https):\/\/)?(?:www.)?facebook.com\/(?:(?:\w)*#!\/)?(?:pages\/)?(?:[?\w\-]*\/)?(?:profile.php\?id=(?=\d.*))?([\w\-]*)?/;
        return exp.test(value);
    }
    isDisabledFacebook() {
        let urlIsValid = false;
        if (this.state.form_data.facebook_link === "" ||this.state.form_data.facebook_link === null ||this.state.form_data.facebook_link === undefined ) {
            urlIsValid=true;
            this.setState({
                fwebsite_error_text: null
            });
        } else {
            if (this.validateFacebook(this.state.form_data.facebook_link)) {
                urlIsValid = true;
                this.setState({
                    fwebsite_error_text: null
                });
            }
            else {
                this.setState({
                    fwebsite_error_text: "Sorry, this is not a valid format"
                });
            }
        }
        return urlIsValid;
    }
    validateInstagram(value){
        var exp =/(?:(?:http|https):\/\/)?(?:www.)?(?:instagram.com|instagr.am)\/([A-Za-z0-9-_]+)/
        return exp.test(value);
    }
    isDisabledInsta() {
        let urlIsValid = false;
        if (this.state.form_data.instagram_link === "" ||this.state.form_data.instagram_link === null || this.state.form_data.instagram_link === undefined ) {
            urlIsValid=true;
            this.setState({
                iwebsite_error_text: null
            });
        } else {
            if (this.validateInstagram(this.state.form_data.instagram_link)) {
                urlIsValid = true;
                this.setState({
                    iwebsite_error_text: null
                });
            }
            else {
                this.setState({
                    iwebsite_error_text: "Sorry, this is not a valid format"
                });
            }
        }
        return urlIsValid;
    }
    validateGoogle(value){
        var exp =/(?:(?:http|https):\/\/)?plus\.google\.com\/.?\/?.?\/?([0-9]*)/;
        return exp.test(value);
    }
    isDisabledGoogle() {
        let urlIsValid = false;
        if (this.state.form_data.google_link === "" || this.state.form_data.google_link === null || this.state.form_data.google_link === undefined) {
            urlIsValid=true;
            this.setState({
                gwebsite_error_text: null
            });
        } else {
            if (this.validateGoogle(this.state.form_data.google_link)) {
                urlIsValid = true;
                this.setState({
                    gwebsite_error_text: null
                });
            }
            else {
                this.setState({
                    gwebsite_error_text: "Sorry, this is not a valid format"
                });
            }
        }
        return urlIsValid;
    }
    validateYoutube(value){
        var exp =/(?:(?:http|https):\/\/)?(?:www\.)?(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))((\w|-){11})(?:\S+)?$/;;
        return exp.test(value);
    }
    isDisabledYoutube() {
        let urlIsValid = false;
        if (this.state.form_data.youtube_link === "" || this.state.form_data.youtube_link === null ||this.state.form_data.youtube_link === undefined) {
            urlIsValid=true;
            this.setState({
                ywebsite_error_text: null
            });
        } else {
            if (this.validateYoutube(this.state.form_data.youtube_link)) {
                urlIsValid = true;
                this.setState({
                    ywebsite_error_text: null
                });
            }
            else {
                this.setState({
                    ywebsite_error_text: "Sorry, this is not a valid format"
                });
            }
        }
        return urlIsValid;
    }
    validateWiki(value){
        var exp =/(?:(?:http|https):\/\/)?(?:www.)?(?:wikipedia.com)\/([A-Za-z0-9-_]+)/
        return exp.test(value);
    }
    isDiasbleWiki(){
        let urlIsValid = false;
        if (this.state.form_data.wordpress_link === "" ||this.state.form_data.wordpress_link === null || this.state.form_data.wordpress_link === undefined) {
            urlIsValid=true;
            this.setState({
                wikiwebsite_error_text: null
            });
        } else {
            if (this.validateWiki(this.state.form_data.wordpress_link)) {
                urlIsValid = true;
                this.setState({
                    wikiwebsite_error_text: null
                });
            }
            else {
                this.setState({
                    wikiwebsite_error_text: "Sorry, this is not a valid format"
                });
            }
        }
        return urlIsValid;
    }

    submitSocial(e){
        e.preventDefault();
        if(!(this.isDisabledFacebook() && this.isDisabledTwitter() && this.isDisabledInsta() && this.isDisabledGoogle()
            &&  this.isDisabledYoutube()  && this.isDiasbleWiki() && this.isDisabledphone() )){
            this.isDisabledFacebook();
            this.isDisabledTwitter();
            this.isDisabledInsta();
            this.isDisabledGoogle();
            this.isDisabledYoutube();
            this.isDisabledphone();
            this.isDiasbleWiki();
            return;
        }
        var formState = this;
        this.state.form_data.action = 'social_links_set';
        this.state.form_data.profile_id = this.props.params.profileId;
        var param =  this.state.form_data;
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                formState.state.stateUpdate = true;
                var change = formState.state.form_data;
               change.result=true;
                change.resultMsg= data.message;
                formState.setState({
                    form_data: change
                })
            }
            else {
                var change = {};
                change.form_data = formState.state.form_data;
                change.form_data["result"] = false;
                change.form_data["resultMsg"] = data.message;
                formState.setState(change);
            }
        });

    }

    render() {
        var updateState = false;
        if(this.state.stateUpdate)
        {
            updateState = true;
            this.state.stateUpdate = false;
        }

        return (<section className="inner-page basic-profile">

            <DashboardMenu page="Social" profileId = {this.props.params.profileId}/>

            <div className="pageRest cell">
                <div className="basic-profile-inner">
                    {this.state.form_data.result == true &&
                    <div className="sucess_ep">{this.state.form_data.resultMsg}</div> }
                    {this.state.form_data.result == false &&
                    <div className="error_ep">{this.state.form_data.resultMsg}</div> }
                    <div className="row">
                        <div className="col-sm-6 ">
                            <div className="btn_inline_view">
                                <h1 className="h1_btn">Social</h1>
                            <span className="lightgallery-single-video">
                             <li className="video" data-src="https://www.youtube.com/watch?v=7BB9B9ozNug&feature=youtu.be">
                                 <button type="button" className=" btn video_assist_btn">Video Assist <i className="fa fa-play-circle"></i></button>
                             </li></span>
                            </div>
                        </div>
                        <div className="col-sm-6">
                            <h3>Step 14/14</h3>
                        </div>
                    </div>

                    <div className="socialPageInput">
                        <div className="row">
                            <div className="col-xs-12 inputSocial">
                                <input type="text" placeholder="" className=""
                                       value={this.state.form_data.facebook_link}
                                       onChange={this.handleInputChange.bind(this,'facebook_link')}/>
                                <small className="errorMsg">{this.state.fwebsite_error_text}</small>

                                    <i className="fa fa-facebook" aria-hidden="true"></i>
                                </div>
                                <div className="col-xs-12 inputSocial">
                                    <input type="text" placeholder="" className=""
                                           value={this.state.form_data.twitter_link}
                                           onChange={this.handleInputChange.bind(this,'twitter_link')}/>
                                    <small className="errorMsg">{this.state.twebsite_error_text}</small>
                                        <i className="fa fa-twitter" aria-hidden="true"></i>
                                    </div>
                                    <div className="col-xs-12 inputSocial">
                                        <input type="text" placeholder="" className=""
                                               value={this.state.form_data.instagram_link}
                                               onChange={this.handleInputChange.bind(this,'instagram_link')}
                                               />   <small className="errorMsg">{this.state.iwebsite_error_text}</small>
                                            <i className="fa fa-instagram" aria-hidden="true"></i>
                                        </div>
                                        <div className="col-xs-12 inputSocial">
                                            <input type="text" placeholder="" className=""
                                                   value={this.state.form_data.google_link}
                                                   onChange={this.handleInputChange.bind(this,'google_link')}
                                                  />  <small className="errorMsg">{this.state.gwebsite_error_text}</small>
                                                <i className="fa fa-google-plus" aria-hidden="true"></i>
                                            </div>
                                            <div className="col-xs-12 inputSocial">
                                                <input type="text" placeholder="" className=""
                                                       value={this.state.form_data.wordpress_link}
                                                       onChange={this.handleInputChange.bind(this,'wordpress_link')}
                                                       />
                                                <small className="errorMsg">{this.state.wikiwebsite_error_text}</small>
                                                    <i className="fa fa-wikipedia-w" aria-hidden="true"></i>
                                                </div>
                                                <div className="col-xs-12 inputSocial">
                                                    <input type="text" placeholder="" className=""
                                                           value={this.state.form_data.youtube_link}
                                                           onChange={this.handleInputChange.bind(this,'youtube_link')}
                                                          />
                                                    <small className="errorMsg">{this.state.ywebsite_error_text}</small>
                                                        <i className="fa fa-youtube" aria-hidden="true"></i>
                                                    </div>
                                                    <div className="col-xs-12 inputSocial">
                                                        <input type="text" placeholder="" className=""
                                                               value={this.state.form_data.whatsapp_link}
                                                               onChange={this.handleInputChange.bind(this,'whatsapp_link')} />
                                                        <small className="errorMsg">{this.state.phone_error_text}</small>
                                                            <i className="fa fa-whatsapp" aria-hidden="true"></i>


                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="spacer"></div>


                                                <div className="row">
                                                    <div className="col-sm-12 col-xs-12 alignRigh1">
                                                        <button  className="btn btn-profile2 big noMargin" onClick={this.submitSocial.bind(this)}>Save</button>
                                                    </div>
                                                </div>

                         <ProgressSlider profileId = {this.props.params.profileId} stateUpdate={updateState}/>

                                            </div>

                                        </div>

                                    </section>
                                    )}
}
Social.propTypes = {
    changeRoute: React.PropTypes.func,
};

function mapDispatchToProps(dispatch) {
    return {
        changeRoute: (url) => dispatch(push(url)),
    };
}

export default connect(null,
    mapDispatchToProps)(Social);
