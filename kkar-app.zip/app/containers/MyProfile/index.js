import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import Dialog from 'material-ui/Dialog';
var util = require('utils/request');
import cookie from 'react-cookie';
import {Profilecomponent} from 'components/Profilecomponent';
import RaisedButton from 'material-ui/RaisedButton';

export class MyProfile extends React.Component {
    openRoute = (route) => {
        this.props.changeRoute(route);
    };

    constructor(props) {
        super(props);
        this.state =
        {
            user_id:"",
            user_name : "",
            user_info : [],
            open: false,
            openDialog : false,
            openWhatsApp : false,
            pageLoader:true
        }
       if(this.props.params.splat === "" || this.props.params.splat === undefined || this.props.params.splat === null){
         this.state.user_id = cookie.load('userId');
       }
       else {
          this.state.user_id = this.props.params.splat.replace("/","");
        }
    }
    handleOpen(name) {
       if(name == "userphone"){
                this.setState({
                    text_show: this.state.userdata.phone,
                    open: true
                });}
        if(name=="useremail"){
            this.setState({
                text_show: this.state.userdata.email,
                open: true
            });
       }
            }

        handleClose = () => {
            this.setState({open: false});
        };

        handleWhatAppOpen(number) {
          if(number != null && number != "")
             this.setState({openWhatsApp: true});
        };

        handleWhatAppClose = () => {
            this.setState({openWhatsApp: false});
        };
    componentDidUpdate(){$('.pageloader').remove();}
        componentDidMount() {
              var events = [];
              var userid = this.state.user_id;
              var param = {action:'myprofile',user_id: userid}
              var formState = this;
              util.getSetData(param,function (data) {

                  if(data.status == "success"){
                    if(data.Profilesdata == undefined || data.Profilesdata == null){
                        $(location).attr('href', '/NotFound');
                    }
                      formState.setState({
                          calendar:data.calender,
                          userdata:data,
                          user_info: data.Profilesdata
                      });

                      if (formState.state.calendar != null) {
                          for (var i = 0; i < formState.state.calendar.length; i++) {
                              var event = {};
                              event["title"] = formState.state.calendar[i].title;
                              event["id"] = formState.state.calendar[i].id;
                              event["start"] = formState.state.calendar[i].startdate;
                              event["end"] = formState.state.calendar[i].enddate;
                              event["allDay"] = true;
                              events.push(event);
                          }
                         }
                       }
                           jQuery('#calendar').fullCalendar({
                                 events: events,
                                 eventRender: function(event, element, view) {
                                    var dataToFind = moment(event.start).format('YYYY-MM-DD');
                                  }
                              });



              });
        }
    togglecalender(){
            jQuery('#calendar').toggleClass('open_cal');
  }


    render() {
        return(
        <div className="PageMinHeight">
            <div className="pageloader"><img src="http://kalakar.pro:90/kalakar/demo/other/assets/img/loader.svg"/></div>
          {this.state.userdata != undefined &&
        <section className="inner_page myProfilePage" >
            <div className="dash_header">
              <div className="row">
                <div className="col-md-8 col-sm-8 col-xs-6 profileInfo">
                    <span><img src={this.state.userdata.userImg} alt=""/></span>
                    <h3>{this.state.userdata.firstname+' '+this.state.userdata.lastname}
                      <span>
                        <p><i className="fa fa-map-marker" aria-hidden="true"></i>{this.state.userdata.cityname} </p>
                      </span>
                    </h3>
                </div>
                <div className="col-md-4 col-sm-4 col-xs-6 profileEdit">
                  <div className="myProfilCalender">
                  <a href="javascript:void(0)" className="btn btn_red" onClick={this.togglecalender.bind(this)}>Calendar</a>
                  <span className="name_social">
                    <p>{this.state.userdata.firstname}</p>
                    <a href="javascript:void(0)" onTouchTap={this.handleOpen.bind(this,'userphone')}><i className="fa fa-phone-square" aria-hidden="true"></i></a>
                    <a href="javascript:void(0)" onTouchTap={this.handleOpen.bind(this,'useremail')}><i className="fa fa-envelope" aria-hidden="true"></i></a>
                    <a href={this.state.userdata.my_website} target="_blank" ><i className="fa fa-globe" aria-hidden="true"></i></a>
                    <a style={{width:'100%', textAlign:'left'}}>{this.state.userdata.company}</a>
                  </span>
                  <span className="landing_calendar">
                      <div id="calendar" className="calendar"></div>
                  </span>
                  </div>
                </div>
              </div>
            </div>

            <Dialog className="pay-ads-pop"
                    modal={false}
                    open={this.state.open}
                    onRequestClose={this.handleClose}
                    autoScrollBodyContent={true}>
                <div className="ViewProfileContact">{this.state.text_show}</div>
                <RaisedButton label="X" primary={true} className="cancelBtnPopup" onTouchTap={this.handleClose}/>
            </Dialog>


            <div className="container">
            <div className="owl-carousel dash_profileItem">
                {this.state.user_info.map(function(object, i){
                    return <Profilecomponent key = {i} profile_id={object.profile_id} category={object.category}
                                             bigimage={object.profileImage}      smallimages={object.media} proUrl={object.proUrl} />
                })}
            </div>
            <div className='myprofilesocial'>
            {this.state.userdata.facebook_profile !="" && this.state.userdata.facebook_profile != null && <a href={decodeURIComponent(this.state.userdata.facebook_profile)} target="_blank">
              <i className="fa fa-facebook" aria-hidden="true"></i>
            </a>}
            {this.state.userdata.twitter_profile !="" && this.state.userdata.twitter_profile != null && <a href={decodeURIComponent(this.state.userdata.twitter_profile)} target="_blank">
              <i className="fa fa-twitter" aria-hidden="true"></i>
              </a>}
            {this.state.userdata.instagram_profile !="" && this.state.userdata.instagram_profile != null && <a href={decodeURIComponent(this.state.userdata.instagram_profile)} target="_blank">
              <i className="fa fa-instagram" aria-hidden="true"></i>
            </a>}
            {this.state.userdata.google_profile !="" && this.state.userdata.google_profile != null && <a href={decodeURIComponent(this.state.userdata.google_profile)} target="_blank">
               <i className="fa fa-google-plus" aria-hidden="true"></i>
            </a>}
            {this.state.userdata.wikipidea_profile !="" && this.state.userdata.wikipidea_profile != null && <a href={decodeURIComponent(this.state.userdata.wikipidea_profile)} target="_blank">
               <i className="fa fa-wikipedia-w" aria-hidden="true"></i>
              </a>}
            {this.state.userdata.youtube_profile !="" && this.state.userdata.youtube_profile != null && <a href={decodeURIComponent(this.state.userdata.youtube_profile)} target="_blank">
               <i className="fa fa-youtube" aria-hidden="true"></i>
            </a>}
            {this.state.userdata.whatsapp_profile !="" && this.state.userdata.whatsapp_profile != null && <a href="javascript:void(0)" onTouchTap={this.handleWhatAppOpen.bind(this,this.state.userdata.whatsapp_profile)}>
                <i className="fa fa-whatsapp" aria-hidden="true"></i>
            </a>}
            </div>
            <Dialog className="pay-ads-pop"
                    modal={false}
                    open={this.state.openWhatsApp}
                    onRequestClose={this.handleWhatAppClose}
                    autoScrollBodyContent={true}>

                <div className="ViewProfileContact">{this.state.userdata.whatsapp_profile}</div>
                <RaisedButton label="X" primary={true} className="cancelBtnPopup" onTouchTap={this.handleWhatAppClose}/>

            </Dialog>
          </div>
</section>}
              </div>)

      }
    }

MyProfile.propTypes = {
    changeRoute: React.PropTypes.func,
};

function mapDispatchToProps(dispatch) {
    return {
        changeRoute: (url) => dispatch(push(url))
    };
}

export default connect(null,
    mapDispatchToProps)(MyProfile);
