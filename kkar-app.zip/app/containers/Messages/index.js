// Created by vinay on 7/13/2016.
import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import { DashboardHeader } from 'components/DashboardHeader_Component';
import { InboxMessages } from 'components/InboxMessages';
import { ClassifiedMessages } from 'components/ClassifiedMessages';
import cookie from 'react-cookie';
const util = require('utils/request');
import {NewMessage} from 'components/NewMessage';
import {CircleMessages} from 'components/CircleMessages';
import {SentMessages} from 'components/SentMessages';
import {DraftMessages} from 'components/DraftMessages';
import {MessageSettings} from 'components/MessageSettings';


const color = ["theatreColor", "direphotoColor", "choreographerColor", "landsArchiColor", "rockPopColor", "indianClasstheatreColor", "horseRidingColor"];

export class Messages extends React.Component {
    openRoute = (route) => {
        this.props.changeRoute(route);
    };

    constructor(props) {
        super(props);
        this.state = {
            data: [],
            user_id: cookie.load('userId'),
            open: false,
            totalSent: '',
            totalUseful: '',
            totalBlacklist: '',
            SentMsg: [],
            InboxMsg: [],
            Sentempty: '',
            Inboxempty: '',
            draftMsg: [],
            classMsg: [],
            circleMsg: [],
            draftEmpty: '',
            classEmpty: '',
            circleEmpty: '',
            DisplayBox: '',
            SortTerm: '',
            States: '',
            profileData: [],
            profileID: '',
            openInbox: false,
            openCircle: false,
            openClassi: false,
            openSent: false,
            currentPage: 0,
            nextPage: 10,
            messegeCounter: 0,
            openDraft: false,
            checked: [],
            inboxchecked: [],
            draftchecked: [],
            circlechecked: [],
            classichecked: [],
            selectAll: false,
            displaySettings:false
        };
    }


    componentDidMount() {
      $('#setting').hide();
      $('#toolbar').show();
      $('.toolbar_con').show();

        document.title = "My Dashboard | Kalakar";
        const userid = this.state.user_id;
        const formState = this;
        const param = {action: 'counters', user_id: userid, type: 'sent_msgs'};
        util.getSetData(param, function (data) {
            if (data.status === 'success') {
                formState.setState({totalSent: data.msg_count});
            }

        });
        const param1 = {
            action: 'counters', usinbox_msg_detailser_id: userid, type: 'block_by'
        }
        util.getSetData(param1, function (data) {
            if (data.status === 'success') {
                formState.setState({totalBlacklist: data.msg_count});
            }

        });
        const param2 = {action: 'counters', user_id: userid, type: 'useful_msgs'}
        util.getSetData(param1, function (data) {
            if (data.status === 'success') {
                formState.setState({totalUseful: data.msg_count});
            }

        });

        formState.Inboxmsg(0, 10, '');
        var profileParam = {action: 'profilesList', user_id: cookie.load('userId')}
        util.getSetData(profileParam, function (data) {
            if (data.status == "success") {
                if (data.data != null) {
                    formState.setState({
                        profileData: data.data
                    });
                }
            }
        });
    }

    setProfile(val, e) {
        this.setState({profileID: val});
        switch (this.state.DisplayBox) {
            case 'inbox':
                this.Inboxmsg(0, 10, val);
                break;
            case 'sent':
                this.sentMessages(0, 10, val);
                break;
            case 'draft':
                this.DraftMsg(0, 10, val);
                break;
            case 'classi':
                this.ClassifiedMsg(0, 10, val);
                break;
            case 'circle':
                this.CircleMsg(0, 10, val);
                break;
        }
    }

    Inboxmsg(CP, NP, PI) {
        this.setState({currentPage: CP, nextPage: NP});
        if (CP >= 0) {
            var startP = CP;
        }
        else {
            var startP = this.state.currentPage;
        }
        const userid = this.state.user_id;
        const formState = this;
        const param3 = {
            action: 'inbox_msgs',
            user_id: userid,
            profile_id: PI,
            start: startP,
            raws: 10
        }
        util.getSetData(param3, function (data) {
            if (data.status === 'success' && data.data != null) {
                var inboxchecked = [];
                for (var i = 0; i <= data.data.length - 1; i++) {
                    inboxchecked.push(false);
                }
                formState.setState({
                    InboxMsg: data.data,
                    DisplayBox: 'inbox',
                    inboxchecked: inboxchecked,
                    messegeCounter: data.msgscount[0].messageCounter
                });
            }
            else {
                formState.setState({Inboxempty: data.message, InboxMsg: [], messegeCounter: 0});
            }
        });
        this.setState({DisplayBox: 'inbox'});
    }

    sentMessages(CP, NP, PI) {
        this.setState({currentPage: CP, nextPage: NP});
        if (CP >= 0) {
            var startP = CP;
        }
        else {
            var startP = this.state.currentPage;
        }

        const userid = this.state.user_id;
        const formState = this;
        const param = {action: 'sent_msgs', user_id: userid, profile_id: PI, start: startP, raws: 10}
        util.getSetData(param, function (data) {
            if (data.status === 'success' && data.data != null) {
                var checked = [];
                for (var i = 0; i <= data.data.length - 1; i++) {
                    checked.push(false);
                }
                formState.setState({
                    checked: checked,
                    SentMsg: data.data,
                    messegeCounter: data.msgscount[0].messageCounter
                });
            }

            else {
                formState.setState({Sentempty: data.message, SentMsg: [], messageCounter: 0});
            }
        });
        this.setState({DisplayBox: 'sent'})
    }

    DraftMsg(CP, NP, PI) {
        this.setState({currentPage: CP, nextPage: NP});
        if (CP >= 0) {
            var startP = CP;
        }
        else {
            var startP = this.state.currentPage;
        }

        const userid = this.state.user_id;
        const formState = this;
        const param3 = {
            action: 'draft_msgs',
            user_id: userid,
            profile_id: PI,
            start: startP,
            raws: 10
        }
        util.getSetData(param3, function (data) {
            if (data.status === 'success' && data.data != null) {
                var draftchecked = [];
                for (var i = 0; i <= data.data.length - 1; i++) {
                    draftchecked.push(false);
                }
                formState.setState({
                    draftchecked: draftchecked,
                    draftMsg: data.data,
                    messegeCounter: data.msgscount[0].messageCounter
                });
            }
            else {
                formState.setState({draftEmpty: data.message, draftMsg: [], messegeCounter: 0});
            }
        });
        this.setState({DisplayBox: 'draft'});
    }

    ClassifiedMsg(CP, NP, PI) {
        this.setState({currentPage: CP, nextPage: NP});
        if (CP >= 0) {
            var startP = CP;
        }
        else {
            var startP = this.state.currentPage;
        }
        const userid = this.state.user_id;
        const formState = this;
        const param3 = {
            action: 'classi_msgs',
            user_id: userid,
            profile_id: PI,
            start: startP,
            raws: 10
        }
        util.getSetData(param3, function (data) {
            if (data.status === 'success' && data.data != null) {
                var classichecked = [];
                for (var i = 0; i <= data.data.length - 1; i++) {
                    classichecked.push(false);
                }
                formState.setState({
                    classichecked: classichecked,
                    classMsg: data.data,
                    messegeCounter: data.msgscount[0].messageCounter
                });
            }
            else {
                formState.setState({classEmpty: data.message, classMsg: []});
            }
        });
        this.setState({DisplayBox: 'classi'});
    }

    CircleMsg(CP, NP, PI) {
        this.setState({currentPage: CP, nextPage: NP});
        if (CP >= 0) {
            var startP = CP;
        }
        else {
            var startP = this.state.currentPage;
        }

        const userid = this.state.user_id;
        const formState = this;
        const param3 = {
            action: 'circle_msgs',
            user_id: userid,
            profile_id: PI,
            start: startP,
            raws: 10
        }
        util.getSetData(param3, function (data) {
            if (data.status === 'success' && data.data != null) {
                var circlechecked = [];
                for (var i = 0; i <= data.data.length - 1; i++) {
                    circlechecked.push(false);
                }
                formState.setState({
                    circlechecked: circlechecked,
                    circleMsg: data.data,
                    messegeCounter: data.msgscount[0].messageCounter
                });
            }
            else {
                formState.setState({circleEmpty: data.message, circleMsg: [], messegeCounter: 0});
            }
        });
        this.setState({DisplayBox: 'circle'});
    }


    handleChange = (event, index, value) => this.setState({value});
    handleOpen = () => {
        this.setState({open: true});
    };
    handleClose = () => {
        this.setState({open: false});
    };
    handleInboxOpen = (c, id) => {
        this.setState({
            openInbox: true,
            message: id
        });
    };
    handleInboxClose = () => {
        this.setState({openInbox: false});
    };
    handleCircleOpen = (id) => {
        this.setState({
            openCircle: true,
            message: id
        });
    };
    handleCircleClose = () => {
        this.setState({openCircle: false});
    };
    handleClassiOpen = (id) => {
        this.setState({
            openClassi: true,
            message: id
        });
    };
    handleClassiClose = () => {
        this.setState({openClassi: false});
    };
    handleDraftOpen = (id) => {
        this.setState({
            openDraft: true, message: id
        });
    };
    handleDraftClose = () => {
        this.setState({openDraft: false});
    };

    handleSentOpen(id) {
        this.setState({
            openSent: true,
            message: id
        })
    }

    handleSentClose() {
        this.setState({openSent: false})
    }

    handleChecked(i, name) {
        if (name === 'sent') {
            var checked = this.state.checked;
            checked[i] = !checked[i];
            if (!checked[i]) {
                var checkState = false;
                this.setState({selectAll: checkState});
            }
            this.setState({checked: checked});

        }
        if (name === 'inbox') {
            var inboxchecked = this.state.inboxchecked;
            inboxchecked[i] = !inboxchecked[i];
            if (!inboxchecked[i]) {
                var checkState = false;
                this.setState({selectAll: checkState});
            }
            this.setState({inboxchecked: inboxchecked});
        }
        if (name === 'draft') {
            var draftchecked = this.state.draftchecked;
            draftchecked[i] = !draftchecked[i];
            if (!draftchecked[i]) {
                var checkState = false;
                this.setState({selectAll: checkState});
            }
            this.setState({draftchecked: draftchecked});
        }
        if (name === 'circle') {
            var circlechecked = this.state.circlechecked;
            circlechecked[i] = !circlechecked[i];
            if (!circlechecked[i]) {
                var checkState = false;
                this.setState({selectAll: checkState});
            }
            this.setState({circlechecked: circlechecked});
        }

        if (name === 'classi') {
            var classichecked = this.state.classichecked;
            classichecked[i] = !classichecked[i];
            if (!classichecked[i]) {
                var checkState = false;
                this.setState({selectAll: checkState});
            }
            this.setState({classichecked: classichecked});
        }
    }

    checkAll() {
        if (this.state.DisplayBox == 'sent') {
            var checked = this.state.checked;
            var checkState = !this.state.selectAll;
            for (var i = 0; i < this.state.checked.length; i++) {
                checked[i] = checkState;
            }
            this.state.selectAll = checkState;
            this.setState({
                checked: checked, selectAll: this.state.selectAll
            })
        }
        if (this.state.DisplayBox == 'inbox') {
            var inboxchecked = this.state.inboxchecked;
            var checkState = !this.state.selectAll;
            for (var i = 0; i < this.state.inboxchecked.length; i++) {
                inboxchecked[i] = checkState;
            }
            this.state.selectAll = checkState;
            this.setState({
                inboxchecked: inboxchecked, selectAll: this.state.selectAll
            })
        }
        if (this.state.DisplayBox == 'draft') {
            var draftchecked = this.state.draftchecked;
            var checkState = !this.state.selectAll;
            for (var i = 0; i < this.state.draftchecked.length; i++) {
                draftchecked[i] = checkState;
            }
            this.state.selectAll = checkState;
            this.setState({
                draftchecked: draftchecked, selectAll: this.state.selectAll
            })
        }
        if (this.state.DisplayBox == 'circle') {
            var circlechecked = this.state.circlechecked;
            var checkState = !this.state.selectAll;
            for (var i = 0; i < this.state.circlechecked.length; i++) {
                circlechecked[i] = checkState;
            }
            this.state.selectAll = checkState;
            this.setState({
                circlechecked: circlechecked, selectAll: this.state.selectAll
            })
        }
        if (this.state.DisplayBox == 'classi') {
            var classichecked = this.state.classichecked;
            var checkState = !this.state.selectAll;
            for (var i = 0; i < this.state.classichecked.length; i++) {
                classichecked[i] = checkState;
            }
            this.state.selectAll = checkState;
            this.setState({
                classichecked: classichecked, selectAll: this.state.selectAll
            })
        }

    }

    deleteCheckbox() {
        if (this.state.DisplayBox == 'sent') {
            var formState = this;
            var msgIds = [];
            for (var i = 0; i <= formState.state.checked.length - 1; i++) {
                if (formState.state.checked[i] == true) {
                    msgIds.push(formState.state.SentMsg[i].message_id);
                }
            }
            var mul_check = msgIds;
            mul_check = JSON.stringify(mul_check);
            var profileParam = {action: 'delete_messages', mul_check};
            util.getSetData(profileParam, function (data) {
                if (data.status == "success") {
                    formState.setState({message: data.message});
                    alert(formState.state.message);
                    var totalDel = msgIds.length;
                    var currentP = parseInt((formState.state.currentPage - totalDel) / 10) * 10;
                    var nextP = parseFloat(currentP + 10);
                    formState.setState({currentPage: currentP, nextPage: nextP});
                    formState.sentMessages(currentP, nextP);
                }
            });
        }
        else if (this.state.DisplayBox == 'inbox') {
            var formState = this;
            var msgIds1 = [];
            for (var i = 0; i <= formState.state.inboxchecked.length - 1; i++) {
                if (formState.state.inboxchecked[i] == true) {
                    msgIds1.push(formState.state.InboxMsg[i].message_id);
                }
            }
            var mul_check = msgIds1;
            mul_check = JSON.stringify(mul_check);
            var profileParam = {action: 'delete_messages', mul_check};
            util.getSetData(profileParam, function (data) {
                if (data.status == "success") {
                    formState.setState({message: data.message});
                    alert(formState.state.message);
                    var totalDel = msgIds1.length;
                    var currentP = parseInt((formState.state.currentPage - totalDel) / 10) * 10;
                    var nextP = parseFloat(currentP + 10);
                    formState.setState({currentPage: currentP, nextPage: nextP});
                    formState.Inboxmsg(currentP, nextP);
                }
            });
        }
        else if (this.state.DisplayBox == 'draft') {
            var formState = this;
            var msgIds3 = [];
            for (var i = 0; i <= formState.state.draftchecked.length - 1; i++) {
                if (formState.state.draftchecked[i] == true) {
                    msgIds3.push(formState.state.draftMsg[i].message_id);
                }
            }
            var mul_check = msgIds3;
            mul_check = JSON.stringify(mul_check);
            var profileParam = {action: 'delete_messages', mul_check};
            util.getSetData(profileParam, function (data) {
                if (data.status == "success") {
                    formState.setState({message: data.message});
                    alert(formState.state.message);
                    var totalDel = msgIds3.length;
                    var currentP = parseInt((formState.state.currentPage - totalDel) / 10) * 10;
                    var nextP = parseFloat(currentP + 10);
                    formState.setState({currentPage: currentP, nextPage: nextP});
                    formState.DraftMsg(currentP, nextP);
                }
            });
        }
        else if (this.state.DisplayBox == 'circle') {
            var formState = this;
            var msgIds4 = [];
            for (var i = 0; i <= formState.state.circlechecked.length - 1; i++) {
                if (formState.state.circlechecked[i] == true) {
                    msgIds4.push(formState.state.circleMsg[i].circle_id);
                }
            }
            var mul_check = msgIds4;
            mul_check = JSON.stringify(mul_check);
            var profileParam = {action: 'delete_messages', mul_check};
            util.getSetData(profileParam, function (data) {
                if (data.status == "success") {
                    formState.setState({message: data.message});
                    alert(formState.state.message);
                    var totalDel = msgIds4.length;
                    var currentP = parseInt((formState.state.currentPage - totalDel) / 10) * 10;
                    var nextP = parseFloat(currentP + 10);
                    formState.setState({currentPage: currentP, nextPage: nextP});
                    formState.CircleMsg(currentP, nextP);
                }
            });
        }
        else if (this.state.DisplayBox == 'classi') {
            var formState = this;
            var msgIds5 = [];
            for (var i = 0; i <= formState.state.classichecked.length - 1; i++) {
                if (formState.state.classichecked[i] == true) {
                    msgIds5.push(formState.state.classMsg[i].message_id);
                }
            }
            var mul_check = msgIds5;
            mul_check = JSON.stringify(mul_check);
            var profileParam = {action: 'delete_messages', mul_check};
            util.getSetData(profileParam, function (data) {
                if (data.status == "success") {
                    formState.setState({message: data.message});
                    alert(formState.state.message);
                    var totalDel = msgIds5.length;
                    var currentP = parseInt((formState.state.currentPage - totalDel) / 10) * 10;
                    var nextP = parseFloat(currentP + 10);
                    formState.setState({currentPage: currentP, nextPage: nextP});
                    formState.ClassifiedMsg(currentP, nextP);
                }
            });
        }
    }


    prevPage() {
        var currentP = this.state.currentPage;
        var nextP = this.state.nextPage;
        if (currentP > 0) {
            var CrP = currentP - 10;
            var NeP = nextP - 10;
            switch (this.state.DisplayBox) {
                case 'inbox':
                    this.Inboxmsg(CrP, NeP);
                    break;
                case 'sent':
                    this.sentMessages(CrP, NeP);
                    break;
                case 'draft':
                    this.DraftMsg(CrP, NeP);
                    break;
                case 'classi':
                    this.ClassifiedMsg(CrP, NeP);
                    break;
                case 'circle':
                    this.CircleMsg(CrP, NeP);
                    break;
            }
        }
    }

    nextPage() {
        var currentP = this.state.currentPage;
        var nextP = this.state.nextPage;
        if (this.state.messegeCounter > this.state.nextPage) {
            var CP = currentP + 10;
            var NP = nextP + 10;

            switch (this.state.DisplayBox) {
                case 'inbox':
                    this.Inboxmsg(CP, NP);
                    break;
                case 'sent':
                    this.sentMessages(CP, NP);
                    break;
                case 'draft':
                    this.DraftMsg(CP, NP);
                    break;
                case 'classi':
                    this.ClassifiedMsg(CP, NP);
                    break;
                case 'circle':
                    this.CircleMsg(CP, NP);
                    break;
            }
        }
    }
showsettings(){
    $('#setting').toggle();
    $('#toolbar').toggle();
    $('.toolbar_con').toggle();

}
    render() {
    
        return (
            <div className="PageMinHeight">
                <DashboardHeader page="Messages" user_name={this.state.user_name} user_image={this.state.user_image}/>
                <div className='container'>
                    <div className='dashMsg'>
                        <div className='row'>
                            <div className='col-sm-12'>
                                <div className='filterMsgOuter'>
                                    <ul className='filterMsg'>
                                        {this.state.profileData.map((ph, i) =>
                                                <li key={ph.profile_id} className={color[i]}>
                                                    <a href="javascript:void(0)"
                                                       className={(this.state.profileID===ph.profile_id)? 'active':''}
                                                       onClick={this.setProfile.bind(this,ph.profile_id)}>{ph.profileName}</a>
                                                </li>
                                        )}
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <div className='row'>
                            <div className='col-md-2 col-sm-3'>
                                <div className='dashMsgLeft'>
                                    <h2>messages</h2>

                                    <div className='left_options'>
                                        <ul>
                                            <li ><a href='javascript:void(0)'
                                                    className={(this.state.DisplayBox === "inbox") ? "active" : ""}
                                                    onClick={this.Inboxmsg.bind(this,0,10, this.state.profileID)}>Inbox</a>
                                            </li>
                                            <li><a href='javascript:void(0)'
                                                   className={(this.state.DisplayBox === "draft") ? "active" : ""}
                                                   onClick={this.DraftMsg.bind(this,0, 10, this.state.profileID)}>Draft</a>
                                            </li>
                                            <li className='classified_link'>
                                                <a href='javascript:void(0)'
                                                   className={(this.state.DisplayBox === "classi") ? "active" : ""}
                                                   onClick={this.ClassifiedMsg.bind(this, 0, 10, this.state.profileID)}>Classfieds</a>
                                            </li>
                                            <li><a href='javascript:void(0)'
                                                   className={(this.state.DisplayBox === "sent")?"active" : ""}
                                                   onClick={this.sentMessages.bind(this, 0, 10, this.state.profileID)}>Sent</a>
                                            </li>
                                            <li><a href='javascript:void(0)'
                                                   className={(this.state.DisplayBox === "circle")?"active" : ""}
                                                   onClick={this.CircleMsg.bind(this, 0, 10, this.state.profileID)}>Circle
                                                Requests</a></li>
                                        </ul>
                                    </div>
                                    <a href='javascript:void(0)' onTouchTap={this.handleOpen}
                                       className='send_message modalPopup' data-size="size-mediam"
                                       data-class="send_new_msg">Send New Message</a>
                                    <NewMessage open={this.state.open} close={this.handleClose}/>

                                    <div className='message_info_left'>
                                        <ul>
                                            <li>Total Messages sent <span>{this.state.totalSent}</span></li>
                                            <li>Professionally useful Messages <span>{this.state.totalUseful}</span>
                                            </li>
                                            <li>Blacklisted by <span>{this.state.totalBlacklist} Users</span></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div className='col-md-10 col-sm-9'>
                                <div className='dashMsgRight'>
                                    <div className='toolbar'>
                                        <div className='toolbar-inner' >
                                            <div className='message_settings_icon' >
                                                <a href='javascript:void(0)' className='msg_etting_icon' onClick={this.showsettings.bind(this)}><i className='fa fa-cog'></i>Message
                                                    Settings</a>
                                            </div>
                                            <span id='setting'><MessageSettings/></span>



  <div className='toolbar_con'>
                                    <span className='page_count'   id='page_count'>{(this.state.nextPage > this.state.messegeCounter) ? this.state.currentPage + ' - ' + this.state.messegeCounter + ' / ' + this.state.messegeCounter : this.state.currentPage + ' - ' + this.state.nextPage + ' / ' + this.state.messegeCounter}
                                    </span>
  <span className='controller'>
  <a href='javascript:void(0)' onClick={this.prevPage.bind(this)}
     className='prev_control filter_cat filter_category'><img
      src={require('./img/prev_b_icon.png')} alt=''/></a>
    <a href='javascript:void(0)' onClick={this.nextPage.bind(this)}
       className='next_control filter_cat1 filter_category'><img
        src={require('./img/next_b_icon.png')} alt=''/></a>
  </span>
<span className='delete_msg'>
  <a href='javascript:void(0)' onClick={this.deleteCheckbox.bind(this)}><img src={require('./img/delete_msg_ico.png')}
                                                                             alt=''/> Delete</a>
  </span>
  <span className='select_all'>
  <div className='prof_checkbox'>
      <div className='radio'>
          <input type='checkbox' id='radio01' name='checkbox' checked={this.state.selectAll}
                 onChange={this.checkAll.bind(this)}/>
          <label><span></span>Select All</label>
      </div>
  </div>
  </span>
                                            </div>
                                        </div>
                                        <div id='toolbar'>
                                        <div className='messages_list'>
                                            <ul id='repeated_li'>

                                                {(this.state.DisplayBox == 'sent') ? this.state.SentMsg.map((c, i) =>

                                                        <li key={c.message_id}>
                                                            <span className='color_id'
                                                                  style={{backgroundColor: "#"+((c.profile_color != "")?c.profile_color:"D01D15")}}></span>
                                                            <span className='sender_name'
                                                                  onTouchTap={this.handleSentOpen.bind(this,c.message_id)}><a
                                                                href='javascript:void(0)'>{c.sender_name}&nbsp;</a></span>
                                                            <span className='msg_subject'
                                                                  onTouchTap={this.handleSentOpen.bind(this,c.message_id)}><a
                                                                href='javascript:void(0)'>{c.subject}&nbsp;</a></span>
                                                            <span className='sort_msg'
                                                                  onTouchTap={this.handleSentOpen.bind(this,c.message_id)}><a
                                                                href='javascript:void(0)'>{c.nature_of_message}&nbsp;</a></span>

                                                              <span
                                                                  className='msg_ir_rating'>{(c.rating === null || c.rating === '' || c.rating === undefined ) ? '' :
                                                                  <a href='javascript:void(0)'><span className="rating">ir</span>
                                                                      <span className="rating_val">{c.rating}</span>
                                                                  </a>}&nbsp;</span>

                                                            <span
                                                                className='msg_attachment_rating '>  {(c.attached_doc !== '') ?
                                                                <img src={require('./img/attachement-icon.png')}
                                                                     alt=''/> : ''}&nbsp;</span>
                                                            <span className='msg_date'><a
                                                                href='#'>{c.date}&nbsp;</a></span>
                                                                   <span className='msg_selection'>
                                            <div className='prof_checkbox'>
                                                <div className='radio'>
                                                    <input type='checkbox' id='radio01' name='checkbox'
                                                           checked={this.state.checked[i]}
                                                           onChange={this.handleChecked.bind(this,i,'sent')}/>
                                                    <label><span></span></label>
                                                </div>
                                            </div></span>
                                                        </li>
                                                ) : ''}
                                                <SentMessages messageid={this.state.message}
                                                              open={this.state.openSent}
                                                              close={this.handleSentClose.bind(this)}
                                                              sentMsg={this.sentMessages.bind(this)}/>

                                                {(this.state.SentMsg == '' && this.state.DisplayBox == 'sent') ?
                                                    <li>{this.state.Sentempty}</li> : ''}

                                                {(this.state.DisplayBox == 'draft') ? this.state.draftMsg.map((c, i) =>
                                                        <li key={c.message_id}>
                                                            <span className='color_id'
                                                                  style={{backgroundColor: "#"+((c.profile_color != "")?c.profile_color:"D01D15")}}></span>
                                                            <span className='sender_name'
                                                                  onTouchTap={this.handleDraftOpen.bind(this,c.message_id)}><a
                                                                href='javascript:void(0)'>{c.sender_name}&nbsp;</a></span>
                                                            <span className='msg_subject'
                                                                  onTouchTap={this.handleDraftOpen.bind(this,c.message_id)}><a
                                                                href='javascript:void(0)'>{c.subject}&nbsp;</a></span>
                                                            <span className='sort_msg'
                                                                  onTouchTap={this.handleDraftOpen.bind(this,c.message_id)}><a
                                                                href='javascript:void(0)'>{c.nature_of_message}&nbsp;</a></span>
                                                            <span
                                                                className='msg_ir_rating'>{(c.rating === null || c.rating === '' || c.rating === undefined ) ? '' :
                                                                <a href='javascript:void(0)'><span
                                                                    className="rating">ir</span> <span
                                                                    className="rating_val">{c.rating}</span>
                                                                </a>}&nbsp;</span>

                                                            <span
                                                                className='msg_attachment_rating '>  {(c.attached_doc !== '') ?
                                                                <img src={require('./img/attachement-icon.png')}
                                                                     alt=''/> : ''}&nbsp;</span>
                                                            <span className='msg_date'><a
                                                                href='#'>{c.date}&nbsp;</a></span>
                                                     <span className='msg_selection'>
                                                                                                    <div
                                                                                                        className='prof_checkbox'>
                                                                                                        <div
                                                                                                            className='radio'>
                                                                                                            <input
                                                                                                                type='checkbox'
                                                                                                                id='radio01'
                                                                                                                name='checkbox'
                                                                                                                checked={this.state.draftchecked[i]}
                                                                                                                onChange={this.handleChecked.bind(this,i,'draft')}/>
                                                                                                            <label><span></span></label>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                    </span>
                                                        </li>
                                                ) : ''}
                                                <DraftMessages messageid={this.state.message}
                                                               open={this.state.openDraft}
                                                               close={this.handleDraftClose.bind(this)}
                                                    />

                                                {(this.state.draftMsg == '' && this.state.DisplayBox == 'draft') ?
                                                    <li>{this.state.draftEmpty}</li> : ''}

                                                {(this.state.DisplayBox == 'circle') ? this.state.circleMsg.map((c, i) =>

                                                        <li key={c.circle_id}>
                                                            <span className='color_id'
                                                                  style={{backgroundColor: "#"+((c.profile_color != "")?c.profile_color:"D01D15")}}></span>
                                                            <span className='sender_name'
                                                                  onTouchTap={this.handleCircleOpen.bind(this,c.circle_id)}><a
                                                                href='javascript:void(0)'>{c.sender_name} &nbsp;</a></span>
                                                            <span className='msg_subject'
                                                                  onTouchTap={this.handleCircleOpen.bind(this,c.circle_id)}><a
                                                                href='javascript:void(0)'
                                                                onTouchTap={this.handleCircleOpen.bind(this,c.circle_id)}>{c.subject}&nbsp;</a></span>
                                                            <span className='sort_msg'><a
                                                                href='javascript:void(0)'>{c.nature_of_message}&nbsp;</a></span>
                                                            <span
                                                                className='msg_ir_rating'>{(c.rating === null || c.rating === '' || c.rating === undefined ) ? '' :
                                                                <a href='javascript:void(0)'><span
                                                                    className="rating">ir</span><span
                                                                    className="rating_val">{c.rating}</span>
                                                                </a>}&nbsp;</span>
                                                            <span
                                                                className='msg_attachment_rating '>  {(c.attached_doc !== '' && c.attached_doc !== null) ?
                                                                <img src={require('./img/attachement-icon.png')}
                                                                     alt=''/> : ''}</span>
                                                            <span className='msg_date'><a href='#'>{c.date}</a></span>
                                                                 <span className='msg_selection'>
                                                                    <div className='prof_checkbox'>
                                                                        <div className='radio'>
                                                                            <input type='checkbox' id='radio01'
                                                                                   name='checkbox'
                                                                                   checked={this.state.circlechecked[i]}
                                                                                   onChange={this.handleChecked.bind(this,i,'circle')}/>
                                                                            <label><span></span></label>
                                                                        </div>
                                                                    </div>
                                                                </span>
                                                        </li>
                                                ) : ''}
                                                <CircleMessages messageid={this.state.message}
                                                                open={this.state.openCircle}
                                                                close={this.handleCircleClose.bind(this)}
                                                                circleMsg={this.CircleMsg.bind(this)}/>

                                                {(this.state.circleMsg == '' && this.state.DisplayBox == 'circle') ?
                                                    <li>{this.state.circleEmpty}</li> : ''}


                                                {(this.state.DisplayBox == 'classi') ? this.state.classMsg.map((c, i) =>

                                                        <li key={c.message_id}>
                                                            <span className='color_id'
                                                                  style={{backgroundColor: "#"+((c.profile_color != "")?c.profile_color:"D01D15")}}></span>
                                                            <span className='sender_name'
                                                                  onTouchTap={this.handleClassiOpen.bind(this,c.message_id)}><a
                                                                href='javascript:void(0)'>{c.sender_name}&nbsp;</a></span>
                                                            <span className='msg_subject'
                                                                  onTouchTap={this.handleClassiOpen.bind(this,c.message_id)}><a
                                                                href='javascript:void(0)'
                                                                onTouchTap={this.handleClassiOpen.bind(this,c.message_id)}>{c.subject}&nbsp;</a></span>
                                                            <span className='sort_msg'><a
                                                                href='javascript:void(0)'>{c.nature_of_message}&nbsp;</a></span>
                                                             <span
                                                                 className='msg_ir_rating'>{(c.rating === null || c.rating === '' || c.rating === undefined ) ? '' :
                                                                 <a href='javascript:void(0)'><span className="rating">ir</span>
                                                                     <span className="rating_val">{c.rating}</span>
                                                                 </a>}&nbsp;</span>
                                                            <span
                                                                className='msg_attachment_rating '>  {(c.attached_doc !== '') ?
                                                                <img src={require('./img/attachement-icon.png')}
                                                                     alt=''/> : ''}&nbsp;</span>
                                                            <span className='msg_date'><a
                                                                href='#'>{c.date}&nbsp;</a></span>
                                                                <span className='msg_selection'>
                                                                     <div className='prof_checkbox'>
                                                                         <div className='radio'>
                                                                             <input type='checkbox' id='radio01'
                                                                                    checked={this.state.draftchecked[i]}
                                                                                    name='checkbox'
                                                                                    onChange={this.handleChecked.bind(this,i,'classi')}/>
                                                                             <label><span></span></label>
                                                                         </div>
                                                                     </div>
                                                                     </span>
                                                        </li>
                                                ) : ''}
                                                <ClassifiedMessages messageid={this.state.message}
                                                                    open={this.state.openClassi}
                                                                    close={this. handleClassiClose.bind(this)}
                                                                    classiMsg={this.ClassifiedMsg.bind(this)}/>
                                                {(this.state.classMsg == '' && this.state.DisplayBox == 'classi') ?
                                                    <li>{this.state.classEmpty}</li> : ''}


                                                {(this.state.DisplayBox == 'inbox') ? this.state.InboxMsg.map((c, i) =>
                                                    <li key={c.message_id}>
                                                        <span className='color_id'
                                                              style={{backgroundColor: "#"+((c.profile_color != "")?c.profile_color:"D01D15")}}></span>
                                                        <span className='sender_name'
                                                              onTouchTap={this.handleInboxOpen.bind(this,c,c.message_id)}><a
                                                            href='javascript:void(0)'>{c.sender_name}&nbsp;</a></span>
                                                        <span className='msg_subject'
                                                              onTouchTap={this.handleInboxOpen.bind(this,c,c.message_id)}><a
                                                            href='javascript:void(0)'>{c.nature_of_message}&nbsp;</a></span>
                                                        <span className='sort_msg'
                                                              onTouchTap={this.handleInboxOpen.bind(this,c,c.message_id)}><a
                                                            href='javascript:void(0)'>{c.subject}&nbsp;</a></span>
                                                         <span
                                                             className='msg_ir_rating'>{(c.rating === null || c.rating === '' || c.rating === undefined ) ? '' :
                                                             <a href='javascript:void(0)'><span
                                                                 className="rating">ir</span> <span
                                                                 className="rating_val">{c.rating}</span>
                                                             </a>}&nbsp;</span>

                                                        <span
                                                            className='msg_attachment_rating '>  {(c.attached_doc !== '') ?
                                                            <img src={require('./img/attachement-icon.png')}
                                                                 alt=''/> : ''}&nbsp;</span>
                                                        <span className='msg_date'><a href='#'>{c.date}&nbsp;</a></span>
                                                             <span className='msg_selection'>
                                                    <div className='prof_checkbox'>
                                                        <div className='radio'>
                                                            <input type='checkbox' id='radio01' name='checkbox'
                                                                   checked={this.state.inboxchecked[i]}
                                                                   onChange={this.handleChecked.bind(this,i,'inbox')}/>
                                                            <label><span></span></label>
                                                        </div>
                                                    </div>
                                                      </span>
                                                    </li>) : ''}
                                                <InboxMessages messageid={this.state.message}
                                                               open={this.state.openInbox}
                                                               close={this.handleInboxClose.bind(this)}
                                                               inboxMsg={this.Inboxmsg.bind(this)}/>


                                                {(this.state.InboxMsg == '' && this.state.DisplayBox == 'inbox') ?
                                                    <li>{this.state.Inboxempty}</li> : ''}


                                            </ul>

                                        </div>
                                        <div className='toolbar-inner'>
                                            <div className='message_settings_icon'>
                                                <a href='javascript:void(0)' className='msg_etting_icon' onClick={this.showsettings.bind(this)}><i className='fa fa-cog'></i>Message
                                                    Settings</a>
                                            </div>
                                            <div className='toolbar_con'>
                                                <span className='page_count'
                                                      id='page_count'>{(this.state.nextPage > this.state.messegeCounter) ? this.state.currentPage + ' - ' + this.state.messegeCounter + ' / ' + this.state.messegeCounter : this.state.currentPage + ' - ' + this.state.nextPage + ' / ' + this.state.messegeCounter}</span>
                                              <span className='controller'>
                                              <a href='javascript:void(0)' onClick={this.prevPage.bind(this)}
                                                 className='prev_control filter_cat filter_category'><img
                                                  src={require('./img/prev_b_icon.png')} alt=''/></a>
                                                <a href='javascript:void(0)' onClick={this.nextPage.bind(this)}
                                                   className='next_control filter_cat1 filter_category'><img
                                                    src={require('./img/next_b_icon.png')} alt=''/></a>
                                              </span>

  <span className='delete_msg'>
  <a href='javascript:void(0)'><img src={require('./img/delete_msg_ico.png')} alt=''/> Delete</a>
  </span>
  <span className='select_all'>
  <div className='prof_checkbox'>
      <div className='radio'>
          <input type='checkbox' id='radio01' name='checkbox'/>
          <label><span></span>Select All</label>
      </div>
  </div>
  </span>
</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        );
    }
}
Messages.propTypes = {
    changeRoute: React.PropTypes.func,
};

function mapDispatchToProps(dispatch) {
    return {
        changeRoute: (url) => dispatch(push(url)),
    };
}

export default connect(null, mapDispatchToProps)(Messages);
