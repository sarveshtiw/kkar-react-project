/**
 * Created by Neeru on 8/22/2016.
 */
import React, { Component } from 'react';
var util = require('utils/request');
import cookie from 'react-cookie';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import {DashboardMenu} from 'components/DashboardMenu';
import { ExtendedPhotos } from 'components/Photos';
import Cropper from 'react-cropper';
import RaisedButton from 'material-ui/RaisedButton';
import Dialog from 'material-ui/Dialog';
import {ProgressSlider} from 'components/ProgressSlider';

export class Photos extends React.Component {
    openRoute = (route) => {
        this.props.changeRoute(route);
    };

  constructor(props) {
      super(props);
      this.state = {
        user_id:cookie.load('userId'),
        photosData : [],
        confirmOpen : false,
        phid : 0,
        croperstate:false,
        IMGSrc: '',
        uploadingImg:'',
        open:false,
        imgTags:'',
        Message:'',
        Filename:'',
        picState:'',
        tagError:''
      }
  }

  componentDidMount() {
    document.title = "Extended Profile | Kalakar";
      var param = {action: 'get_photos', profile_id: this.props.params.profileId}
      var formState = this;
      util.getSetData(param, function (data) {
          if (data.status == "success") {
              formState.setState({
                  photosData : data.data
              });
          }

      });
      jQuery('#lightgallery').lightGallery();
      jQuery('.lightgallery-single-image').lightGallery();
      jQuery('.lightgallery-single-video').lightGallery();
  }


 handleDelete(photoId,formState){
   var param = {action : 'deletePhoto',photoId : photoId,user_id : cookie.load('userId') ,mediaId : photoId }
   util.getSetData(param, function (data) {
     if (data.status == "success") {
      alert("Photo has been deleted successfully.");
      location.reload(true);
     }

   });
 }

  handleCClose = () => {
    this.setState({croperstate: false});
  };
 uploadImage(){
if(this.state.imgTags===''){this.setState({tagError:'Photo tags required!'}); return false;}
 var cropperDAta = this.refs.cropper.getCroppedCanvas().toDataURL();
 this.setState({croperstate:false,  uploadingImg:cropperDAta, picState:1});
 var formState = this;
 var userid = this.state.user_id;
 var profileId = this.props.params.profileId;
 var params1 = {action:'photos', profile_id:profileId, userId: userid, img_data: cropperDAta, imgtgs:this.state.imgTags, f_name:this.state.Filename}
 util.getSetData(params1, function (data) {
 if(data.status == "success"){
location.reload(true);
    }
    else {
   formState.setState({picState:3, Message:data.message});
    }
  });
  }
  handleClose = () => {
      this.setState({open: false, croperstate: false, IMGSrc:''});
  };

 RotateR(){
 this.refs.cropper.rotate(90);
 }
 _crop(e){
      }
 RotateL(){
 this.refs.cropper.rotate(-90);
 }

 removeImg(){
   this.setState({uploadingImg:'', picState:0})
 }
 handleImageChange (e) {
  e.preventDefault();
 let reader = new FileReader();
 let file = e.target.files[0];
  reader.onloadend = () => {
   this.setState({croperstate:true, IMGSrc:reader.result, Filename:file.name});
 }
 reader.readAsDataURL(file);
 }
 changeText(e){
   this.setState({imgTags:e.target.value})
 }
 retryImage(e){
   if(e===3)
   {
     this.setState({picState:1});
     var formState = this;
     var userid = this.state.user_id;
     var profileId = this.props.params.profileId;
     var params1 = {action:'photos', profile_id:profileId, userId: userid, img_data:this.state.IMGSrc, imgtgs:this.state.imgTags, f_name:this.state.Filename}
     util.getSetData(params1, function (data) {
     if(data.status == "success"){
    location.reload(true);
        }
        else {
       formState.setState({picState:3});
        }
      });
   }
 }
    Continue()
    {
        var p_id = this.props.params.profileId;
        this.props.changeRoute('/my-accounts/extended-profile/'+ p_id +'/video');
    }
  render() {
      var updateState = false;
      if(this.state.stateUpdate)
      {
          updateState = true;
          this.state.stateUpdate = false;
      }
    var formState = this;

    return (
        <section className="inner-page basic-profile">
  <DashboardMenu page="Photos" profileId = {this.props.params.profileId}/>
    <Dialog title="Upload Image" modal={true} open={this.state.croperstate}  className="croperPopup" autoScrollBodyContent={false}>
    <button onClick={this.uploadImage.bind(this)}  className="uploadBtnCrop"><span className="fa fa-check"></span></button>
    <p>(min size 800px X 600px)</p>
    <small className='errorMsg'>{this.state.tagError}</small>
<input type='text' placeholder="Photo Tags" value={this.state.imgTags} onChange={this.changeText.bind(this)}/>

    <Cropper
    ref='cropper'
    src={this.state.IMGSrc}
    style={{height: 385, width: '100%'}}
    autoCropArea={0.97}
    guides={false}
   />
    <span className="RotateBtnCropOuter">
      <button title='Rotate Left' onClick={this.RotateL.bind(this)} className="RotateBtnCrop"><span className="fa fa-rotate-left"></span></button>
      <button title='Rotate Right' onClick={this.RotateR.bind(this)} className="RotateBtnCrop"><span className="fa fa-rotate-right"></span></button>
    </span>
      <RaisedButton className="cancelBtnPopup" primary={true} onTouchTap={this.handleClose.bind(this)} label="X"/>

    </Dialog>
<div className="pageRest cell">
    <div className="basic-profile-inner">
      <div className="row">
          <div className="col-sm-6 ">
              <div className="btn_inline_view">
                  <h1 className="h1_btn">Photos</h1>
                            <span className="lightgallery-single-video">
                             <li className="video" data-src="https://www.youtube.com/watch?v=QRy2Q1r6Hrc&feature=youtu.be">
                                 <button type="button" className=" btn video_assist_btn">Video Assist <i className="fa fa-play-circle"></i></button>
                             </li></span>

              </div>
          </div>
            <div className="col-sm-6">
            	<h3>Step 10/14</h3>
            </div>
        </div>

        <div className="row">
            <div className="col-xs-12">
            <div className="albums-data">
            <div className="albums-data__inner" id="photo-block1">
               <div className="photo-block">
     <div className="photo-block__img"><div className="upload">
  <div className={(this.state.picState==1)? 'ajax_loading_loader_image':(this.state.picState==3)? 'ajax_retry':(this.state.picState==2)?'ajax_complete':''} onClick={this.retryImage.bind(this, this.state.picState)}></div>
       {(this.state.IMGSrc==='') ? <span className="fileUploadBtn">+<input type='file' id="file"  onChange={this.handleImageChange.bind(this)} accept="image/*"/></span>:<span><img src={this.state.IMGSrc}/></span> }</div></div>
               </div>
               <input type="text" value={this.state.imgTags} placeholder="Upload Image" readOnly=""/>
                 <div style={{position: 'relative', bottom: '2px', fontSize: '12px', lineHeight: '12px', color: 'rgb(244, 67, 54)', transition: 'all 450ms cubic-bezier(0.23, 1, 0.32, 1) 0ms'}}>{this.state.Message}</div>

          </div>

	               <div className="photo_right_gp">
                 {this.state.photosData.map(function (obj, i) {
                     return <ExtendedPhotos key={i} profile_id={formState.props.params.profileId} photo={obj} handletextChange={formState.handletextChange}
                     handleDelete={formState.handleDelete} formState={formState}/>
                 })}
            </div>
           </div>
          </div>
      </div>
       <div className="row">
         <div className="col-sm-12 col-xs-12 alignRigh1">
          <button className="btn btn-profile2 big noMargin" onClick={this.Continue.bind(this)}>Continue <i className="fa fa-chevron-right"></i></button>
          <a href={'/user-profile/'+this.props.params.profileId} target='_blank' className="btn btn-profile2 big noMargin">Quick View <i className="fa fa-chevron-right"></i></a>
         </div>
        </div>
  <ProgressSlider profileId = {this.props.params.profileId}  stateUpdate={updateState}/>
</div>
</div>

</section>
      );
    }
  }

  Photos.propTypes = {
      changeRoute: React.PropTypes.func,
  };

  function mapDispatchToProps(dispatch) {
      return {
          changeRoute: (url) => dispatch(push(url)),
      };
  }

  export default connect(null,mapDispatchToProps)(Photos);
