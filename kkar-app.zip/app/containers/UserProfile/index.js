import React from 'react';
var util = require('utils/request');
import Img from 'components/Img';
import cookie from 'react-cookie';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import {UserProfile_LeftSection} from 'components/UserProfile_LeftSection';
import {ExtendedProfile} from 'components/ExtendedComponent';
import{ProfileMainSlider} from 'components/Profileslider';
import{ExtendedMedia} from 'components/ExtendedMedia';
import{ProfileSearch} from 'components/ProfileSearch';
import{ProfileSearchResponsive} from 'components/ProfileSearchResponsive';


export class UserProfile extends React.Component {

    openRoute = (route) => {
        this.props.changeRoute(route);
    };

    constructor(props) {
        super(props);
        this.state = {
            form_data:"",
            pageLoader:true,
            profileId: 0
        };
    }
    componentDidUpdate(){$('.pageloader').remove();}

    componentDidMount() {
      document.title = "User Profile | Kalakar";
      (function($){
        $(window).load(function(){
        $(".myaccount-data-scroll").mCustomScrollbar({
          theme:"dark-3"
        });

        $(".dd_scroll").mCustomScrollbar({
          setHeight:200,
          theme:"dark-3"
         });

        $(".profile_info_left .tab-pane").mCustomScrollbar({
            setHeight:508,
            theme:"dark-3"
          });

        $(".profile_info_right .demo-gallery, .profile_info_right .dashboard_rating").mCustomScrollbar({
          snapAmount:40,
          scrollButtons:{enable:true},
          keyboard:{scrollAmount:40},
          mouseWheel:{deltaFactor:40},
          scrollInertia:400,
          setHeight:468
        });

        $(".circle_data_scroll").mCustomScrollbar({
          setHeight:440,
          theme:"dark-3"
          });
        });
      })(jQuery);
      $(function() {
        var Page = (function() {
        var $nav = $( '#nav-dots > span' ),
         slitslider = $( '#slider' ).slitslider( {
           onBeforeChange : function( slide, pos ) {
             $nav.removeClass( 'nav-dot-current' );
             $nav.eq( pos ).addClass( 'nav-dot-current' );
           }
         } ),

         init = function() {
           initEvents();
         },
         initEvents = function() {
           $nav.each( function( i ) {
             $( this ).on( 'click', function( event ) {
               var $dot = $( this );
               if( !slitslider.isActive() ) {
                 $nav.removeClass( 'nav-dot-current' );
                 $dot.addClass( 'nav-dot-current' );
               }
               slitslider.jump( i + 1 );
               return false;
             } );
           } );
         };
         return { init : init };
        })();
        Page.init();
      });
      var formState = this;
        

      var param = {action: 'get_profile_id', profileName:'http://www.kalakar.pro'+this.props.location.pathname}

      util.getSetData(param, function (data) {
          if (data.status == "success") {
              if (data.profileId != null) {
                  formState.setState({profileId: data.profileId});

                  var param = {action: 'extended_profile_detail', profile_id: data.profileId}
                  util.getSetData(param, function (data) {
                      if (data.status == "success") {
                          if (data.data != null) {
                              formState.setState(data.data);
                          }
                      }
                      else {
                          $(location).attr('href', '/NotFound');
                      }
                  });

                  var param = {action: 'social_links_get', profile_id: data.profileId}
                  util.getSetData(param, function (data) {
                      var form_data=data.data;
                      if (data.status == "success")
                      {
                          formState.setState({

                              form_data: {
                                  facebook_link:(data.data.facebook== null)?'':data.data.facebook ,
                                  twitter_link: (data.data.twitter== null)?'':data.data.twitter,
                                  wordpress_link: (data.data.wiki == null)?'':data.data.wiki,
                                  youtube_link: (data.data.youtube_link == null)?'':data.data.youtube_link,
                                  whatsapp_link: (data.data.whatsapp_link == null)?'':data.data.whatsapp_link,
                                  google_link: (data.data.google_link == null)?'':data.data.google_link,
                                  instagram_link: (data.data.instagram_link ==null)? '':data.data.instagram_link
                              }
                          } )}

                  })
              }
          }
          else {
              $(location).attr('href', '/NotFound');
          }
      });
    }

    render() {
      if(this.state[0] != undefined){
       $('header').css('backgroundColor', '#'+this.state[0].profile_color);

      var fontStyle = {
        color : '#'+this.state[0].profile_color
      };
    }

    if(this.state.profileId <= 0)
      return <div className="PageMinHeight"><br/><br/><br/>Loading...</div>;


        return (
          <div className="PageMinHeight">
              <div className="pageloader"><img src="http://kalakar.pro:90/kalakar/demo/other/assets/img/loader.svg"/></div>

          {this.state[0] != undefined &&
            <section className="inner_page">
              <div className="profile_right profile_rightTop">
                <ProfileSearchResponsive />
              </div>
                <div className="profile_page">
                    <div className="profile_left">
                        <UserProfile_LeftSection data={this.state[0]} social={this.state.form_data} profileId={this.state.profileId} />
                    </div>
                    <div className="profile_main">
                        <ProfileMainSlider profileId={this.state.profileId} />
                        <div className="decHide"><p><i className="fa fa-clone" aria-hidden="true"></i> View Deck</p></div>
                        <div className="profile_main_info">
                            <div className="row">
                                <ExtendedProfile style={fontStyle} profileId={this.state.profileId} />
                                <ExtendedMedia style={fontStyle} social={this.state.form_data} profileId={this.state.profileId}/>

                            </div>
                        </div>
                    </div>
                    <div className="profile_right  profile_rightBtm">
                      <ProfileSearch profileId={this.state.profileId}/>
                    </div>
                </div>
            </section>
      }
      </div>

        )
    }
}
UserProfile.propTypes = {
    changeRoute: React.PropTypes.func,
};

function mapDispatchToProps(dispatch) {
    return {
        changeRoute: (url) => dispatch(push(url)),
    };
}

export default connect(null, mapDispatchToProps)(UserProfile);
