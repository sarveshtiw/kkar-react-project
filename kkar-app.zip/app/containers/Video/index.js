import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import {DashboardMenu} from 'components/DashboardMenu';
import TextField from 'material-ui/TextField';
import {ViewEdit} from 'components/ViewEdit_Component';
import {DialogConfirm} from 'components/TagDelete';
import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
import {ProgressSlider} from 'components/ProgressSlider';
var util = require('utils/request');
import cookie from 'react-cookie';


export class Video extends React.Component {
    openRoute = (route) => {
        this.props.changeRoute(route);
    };

    constructor(props) {
        super(props);
        this.state = {
            stateUpdate:false,
            confirmOpen: false,
            user_id: cookie.load('userId'),
            videodata: [],
            form_data: {
                video_id: '',
                video_link: '',
                video_tag: '',
                button_text: 'ADD',
                result: null,
                resultMsg: ''
            }

        }
    }

    componentDidMount() {
      document.title = "Extended Profile | Kalakar";
      (function($){
             $(window).load(function(){
             $(".scroller335").mCustomScrollbar({
                 setHeight:335,
                 theme:"dark-3"
               });
             });

         })(jQuery);

        var param = {action: 'videos_list', profile_id: this.props.params.profileId}
        var formState = this;
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                if (data.data != null) {
                    formState.setState({
                        videodata: data.data
                    })
                }
            }

        });

        jQuery('.lightgallery-single-image').lightGallery();
        jQuery('.lightgallery-single-video').lightGallery();
    }

    handleInputChange(name, e) {
        var change = {};
        change.form_data = this.state.form_data;
        change.form_data[name] = e.target.value;
        this.setState(change);
        if(name == 'video_link')
        {
            this.isDisabledWebsite();
        }
        if(name == 'video_tag')
        {
            this.validate1();
        }
    }

    handleInputChange1(name, e) {
        var change = {};
        change[name] = e.target.value;
        this.setState(change);
    }

    handleEditClicked(obj) {
        this.setState({
            form_data: {
                video_id: obj.video_id,
                video_link: obj.videolink.replace('embed/', 'watch?v='),
                video_tag: obj.video_tag,
                button_text: "UPDATE"

            }
        });

    }

    handleOpen(tid, formState) {
        formState.setState({dtid: tid, confirmOpen: true});
    }

    handleClose = () => {
        this.setState({confirmOpen: false});
    };

    deleteVideo(local) {
        var param = {action: 'video_delete', video_id: local.state.dtid};
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                local.state.stateUpdate = true;
                    local.handleClose();
                var param = {action: 'videos_list', profile_id: local.props.params.profileId}
                util.getSetData(param, function (data) {
                    if (data.status == "success") {
                        local.setState({
                            videodata: data.data
                        })
                        }

                });
            }
        });
    }

    validateWebsite(value)
    {
        var exp =/(?:(?:http|https):\/\/)?(?:www\.)?(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))((\w|-){11})(?:\S+)?$/;;
        var exp1 =/https?:\/\/(?:www\.|player\.)?vimeo.com\/(?:channels\/(?:\w+\/)?|groups\/([^\/]*)\/videos\/|album\/(\d+)\/video\/|video\/|)(\d+)(?:$|\/|\?)/;
        if(exp.test(value))
        {
            return true;
        }
        else if( exp1.test(value))
        {
            return true;
        }
        else{
        return false;
        }

    }
    isDisabledWebsite() {
        let urlIsValid = false;
        if (this.state.form_data.video_link === "") {

            this.setState({
                website_error_text:"Required"
            });
        } else {
            if (this.validateWebsite(this.state.form_data.video_link)) {
                urlIsValid = true;
                this.setState({
                    website_error_text: null
                });
            }
            else {
                this.setState({
                    website_error_text: "Sorry, this is not a valid format"
                });
            }
        }
        return urlIsValid;
    }
    validate1() {
        let valid=false;
        if(this.state.form_data.video_tag == ""){
            this.setState({
               error_text: "Required"
            });
        } else {
            valid=true
            this.setState({
               error_text: null
            })

        }return valid;
    }

    submitVideo() {
        if(!(this.isDisabledWebsite() && this.validate1())){
            this.isDisabledWebsite();
            this.validate1();
            return;
        }
        var formState = this;
        var userid = this.state.user_id;
        this.state.form_data.action = 'videos_save';
        this.state.form_data.profile_id = this.props.params.profileId;
        this.state.form_data.user_id = userid;
        var param = this.state.form_data;
        util.getSetData(param, function (data) {

            if (data.status == "success") {
                formState.state.stateUpdate = true;
                var param = {action: 'videos_list', profile_id: formState.props.params.profileId}
                util.getSetData(param, function (data1) {
                    if (data1.status == "success") {
                        formState.setState({
                            videodata: data1.data,
                            form_data: {
                                video_link: '',
                                video_tag: '',
                                button_text: 'ADD',
                                result: true,
                                resultMsg: data.message
                            }
                        })
                    }
                })
            }
            else {
                var change = {};
                change.form_data = formState.state.form_data;
                change.form_data["result"] = false;
                change.form_data["resultMsg"] = data.message;
                formState.setState(change);
            }
        });
    }

    Continue() {
        var p_id = this.props.params.profileId;
        this.props.changeRoute('/my-accounts/extended-profile/' + p_id + '/albums');
    }


    render() {
        var updateState = false;
        if(this.state.stateUpdate)
        {
            updateState = true;
            this.state.stateUpdate = false;
        }
        var local = this;
        return (
            <section className="inner-page basic-profile">

                <DashboardMenu page="Videos" profileId={this.props.params.profileId}/>

                <div className="pageRest cell">
                    <div className="basic-profile-inner">
                        {this.state.form_data.result == true &&
                        <div className="sucess_ep">{this.state.form_data.resultMsg}</div> }
                        {this.state.form_data.result == false &&
                        <div className="error_ep">{this.state.form_data.resultMsg}</div> }

                        <div className="row">
                            <div className="col-sm-6 ">
                                <div className="btn_inline_view">
                                    <h1 className="h1_btn">Videos</h1>
                            <span className="lightgallery-single-video">
                             <li className="video" data-src="https://www.youtube.com/watch?v=AKYQfHzVYqo&feature=youtu.be">
                                 <button type="button" className=" btn video_assist_btn">Video Assist <i className="fa fa-play-circle"></i></button>
                             </li></span>

                                </div>
                            </div>
                            <div className="col-sm-6">
                                <h3>Step 11/14</h3>
                            </div>
                        </div>

                        <div className="row">
                            <div className="col-xs-12 lastCol lastCol2">
                                <input type="text" placeholder="Paste youtube or vimeo link"
                                       value={this.state.form_data.video_link}
                                       onChange={this.handleInputChange.bind(this,'video_link')}/>

                                <small className="errorMsg">{this.state.website_error_text}</small>

                                <i className="fa fa-info" data-toggle="tooltip" title="Paste youtube or vimeo link"
                                   data-original-title="Paste youtube or vimeo link"></i>
                            </div>
                            <div className="col-xs-12 lastCol lastCol2">
                                <input type="text" placeholder="Tag this photo, seperate tags by comma"
                                       value={this.state.form_data.video_tag}
                                       onChange={this.handleInputChange.bind(this,'video_tag')}/>
                                <small className="errorMsg">{this.state.error_text}</small>
                            </div>
                        </div>

                        <div className="row">
                            <div className=" col-xs-12 lastCol lastCol2 alignRigh1">
                                <button className="add_val_btn marginTopBott4"
                                        onClick={this.submitVideo.bind(this)}>{this.state.form_data.button_text}
                                </button>
                            </div>
                        </div>
                        <div className="spacer"></div>

                        <div className="scroller335">
                        <div className="row">
                            <div className="col-xs-12 lastCol2">
                                <div className="row">
                                    {this.state.videodata.map(v =>
                                            <div className="col-sm-4 col-xs-6" key={v.video_id}>
                                                <div className="video_Box">
                                                    <div className="video_box_inner">
                                                        <iframe width="100%" height="140px"
                                                                src={v.videolink} frameBorder="0"
                                                                allowFullScreen>
                                                        </iframe>
                                                    </div>
                                                    <div className="video_text_box">
                                                        <input type="text" value={v.video_tag}
                                                               onChange={this.handleInputChange1.bind(this)}
                                                               placeholder="Tag this photo, seperate tags by comma"/>
                                                        <a href = "javascript:void(0)" onClick={this.handleEditClicked.bind(this,v)}>
                                                            <i className="fa fa-pencil" ari-hidden="true"></i></a>
                                                  </div>


                                                    <a href = "javascript:void(0)" onTouchTap={local.handleOpen.bind(null,v.video_id,local)}>
                                                        <i className="fa fa-trash-o" aria-hidden="true"></i></a>

                                                </div>

                                            </div>
                                    )}
                                </div>
                                <DialogConfirm open={local.state.confirmOpen} title="Delete Video"
                                               body="Do you really want to delete?"
                                               onSubmit={local.deleteVideo.bind(null,local)}
                                               onClose={local.handleClose}/>
                            </div>
                            </div>
                            </div>


                            <div className="spacer"></div>

                            <div className="row">
                                <div className="col-sm-12 col-xs-12 alignRigh1">
                                    <button onClick={this.Continue.bind(this)} className="btn btn-profile2 big ">
                                        Continue <i
                                        className="fa fa-chevron-right"></i></button>
                                </div>
                            </div>

                            <ProgressSlider profileId = {this.props.params.profileId} stateUpdate={updateState}/>
                        </div>

                    </div>

            </section>

        )
    }
}

Video.propTypes = {
    changeRoute: React.PropTypes.func,
};

function mapDispatchToProps(dispatch) {
    return {
        changeRoute: (url) => dispatch(push(url)),
    };
}
export default connect(null, mapDispatchToProps)(Video);
