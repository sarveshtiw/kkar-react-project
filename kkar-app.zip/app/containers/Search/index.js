/***  Created by kailash on 7/13/2016. */
import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import SelectField from 'material-ui/SelectField';
import AutoComplete from 'material-ui/AutoComplete';
import MenuItem from 'material-ui/MenuItem';
import DatePicker from 'material-ui/DatePicker';
import  { createFilter } from 'react-search-input';
import {SearchProfilesList} from 'components/SearchProfilesList';
const country = ['India'];
const _ = require('lodash');
const languages = ['Hindi', 'English', 'Gujarati', 'Tamil', 'Malyalam', 'Telgu', 'Kannada', 'Punjabi', 'Bengali', 'Marathi', 'German', 'Assamese', 'Bodo', 'Dogri', 'Kashmiri', 'Konkani', 'Maithili', 'Manipuri', 'Nepali',
    'Odia', 'Sanskrit', 'Santali','Sindhi','Urdu','Mundari','Khasi','Tulu','Kurukh','Khandeshi','Gondi','Bhili/Bhilodi'];
const States=[];
const URL = 'http://52.66.48.222:8983/solr/search/select';
const Location = 'http://52.66.48.222:8983/solr/Location/select';
import { API_URL } from 'containers/App/constants'
import cookie from 'react-cookie';
var util = require('utils/request');
import {ShareComponent} from 'components/ShareComponent';
import Dialog from 'material-ui/Dialog';
import FontIcon from 'material-ui/FontIcon';


export class Search extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            data:[],
            userId: cookie.load('userId'),
            open: false,
            proglob:'',
            Qparam:'',
            querystring:'',
            Gender:0,
            genderfilter:'Gender: *',
            agefilter:'Age:*',
            languagefilter:'PrimaryLang:*',
            countryfilter:'india',
            statefilter:'StateName:*',
            cityfilter:'CityName:*',
            feefilter:'WorkRate:*',
            availfilter:'',
            ageGroup:0,
            Workrate:0,
            Lang:'',
            dataSource1:[],
            searchbox: '',
            searchTerm:'',
            SortTerm:2,
            SortFilter:'id asc',
            States:'',
            Cities:'',
            Avialdate:'',
            bookmarkmsg:'',
            bookmarkID:'',
            Likemsg:'',
            LikeID:'',
            profile_url : '',
            nameOrder:'asc',
            likeOrder:'asc',
            ratingOrder:'desc',
            workrateOrder:'asc',
            workredOrder:'asc',
            idOrder:'asc',
            Loader:true,
            pageLoader:true,
            bookmark_list: [],
            Sgender:'',
            SLocatio:'',
            cityArray:'',
            parentCategory:[],
            childCategory:[],
            subChildCategory:[],
            arr1:[],
            arr2:[]
        };
    }

    isBookmarked(profileId) {
        var bookmarked=false;
        this.state.bookmark_list.map(obj => {
            if(obj.profile_id == profileId) {
                bookmarked = true;
            }
        });
        return bookmarked;
    }

    getBookmarkList() {
        var param = {action: 'bookmarks_list', user_id: this.state.userId};
        var formState = this;
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                var bookmark_list = data.data;

                formState.setState({
                    bookmark_list: data.data
                })
            }
        });
    }
    SolrSearch(urls){
        cookie.save('SolrQuery', urls, { path: '/' });
        $.ajax({
            'url': urls,
            'success': function(data) {
                var queryparam = data.responseHeader.params.q;
                queryparam = queryparam.replace('%20',' ');
                queryparam = queryparam.replace('*','');
                this.setState({
                    data: data.response.docs,
                    proglob: data.response.numFound,
                    Qparam: queryparam,
                    searchbox: queryparam,
                    Loader:false
                }) }.bind(this),
            'error': function(XMLHttpRequest, textStatus, errorThrown) {
                currenstate.setState({Loader:false});
            },
            'dataType': 'jsonp',
            'jsonp': 'json.wrf'
        });
    }
    componentDidMount() {
        this.getBookmarkList();
        $("[data-toggle='tooltip']").tooltip();
        $('.showFilters a').click(function(e){
            e.preventDefault();
            $(this).toggleClass('active');
            $('.results .filter').toggleClass('open');
        });
        var currentRoutes = this.props.location.pathname;
        currentRoutes = currentRoutes.replace('?','');
        var patt = /profession/g;
        var result = patt.exec(currentRoutes);
        if(result !== null){
            var arr = currentRoutes.split('/profession/');
            var reqarr = arr[1].replace('%20',' ');
            reqarr = reqarr.replace('%20',' ');
            reqarr = reqarr.replace('%20',' ');
            var queryS = reqarr+'&fq=ProcatName:'+'"'+reqarr+'"';
            var Query = '?q=*'+queryS+'&sort=Rating desc&start=0&rows=100000&wt=json';
            var urls = URL+Query;
            this.setState({querystring:Query});
            this.SolrSearch(urls);
        }
        else {
            var arr = currentRoutes.split('search/');
            var queryS = arr[1];
            var currenstate = this;
            var FQS = {action: 'Solr', SolrTerm: queryS};
            $.ajax({
                'url':API_URL,
                type: "POST",
                dataType: 'json',
                data: FQS,
                'success': function(data) {
                    var Query =data.query;
                    var urls = URL+Query+'&start=0&rows=5000&wt=json';
                    currenstate.setState({querystring:Query});
                    currenstate.SolrSearch(urls+'&sort=Rating desc');
                }
            });
        }
       this.childCategory();
        $(function(){

            $('.search_keywords > li > a').click(function($scope) {

                if (!$(this).parent().hasClass('active')){
                    $('#bannerBG').addClass('active');
                    $('.search_keywords > li').removeClass('active');
                    $(this).parent().addClass('active');
                    $('#search-container').addClass('active');
                }
                else{
                    $('.search_keywords > li').removeClass('active');
                    $('#search-container').removeClass('active');
                    $('#bannerBG').removeClass('active');
                }
            });

            $('.search_keywords h3').click(function(){
                $(this).toggleClass('active');
                $(this).next('ul').toggleClass('active');
            });
            $('.searchFilterDrop').click(function(){
                $('.search_keywords').css('margin-top','90px;');
                $('#bannerBG').css('margin-top', '249;');
            })
        });


    }


    onchangecountry(e,value){
        var statesdatas = {action: 'get_states', country: value+1};
        var states=[];
        $.ajax({
            url: API_URL,
            type: "POST",
            dataType: 'json',
            data: statesdatas,
            success: function (data) {
                $.each(data.states, function(i, star) {
                    states.push(star.state_name);
                });
                this.setState({States:states, currentCountry: country[value]});
            }.bind(this),
            error: function (err) {
            }
        });
        e.stopPropagation();
    }
    onchangestates(e,value){
        var citydatas = {action: 'get_cities', state: value+1};
        var cities=[];
        $.ajax({
            url: API_URL,
            type: "POST",
            dataType: 'json',
            data: citydatas,
            success: function (data) {
                $.each(data.cities, function(i, star) {
                    cities.push(star.city_name);
                });
                this.setState({Cities:cities});
            }.bind(this),
            error: function (err) {
            }
        });
    }
    searchUpdated (classnm, e) {
        this.setState({searchbox: e.target.value})
    }
    openRoute = (route) => {
        this.props.changeRoute(route);
    };

    handleChange = (event, index, value) => this.setState({value});
    changeclass(classnm, e){
        if ($('.' + classnm).hasClass('active')){
            $('.' + classnm).toggleClass('active');
            $('#bannerBG').removeClass('active');
            $('#search-container').removeClass('active');
        }
        else{
            $('.search_keywords  li').removeClass('active');
            $('.' + classnm).toggleClass('active');
            $('#search-container').addClass('active');
            $('#bannerBG').addClass('active');
        }

    }
    datafilter(event, value, filterkey){
        var gender=this.state.genderfilter;
        var age= this.state.agefilter;
        var WorkRate = this.state.feefilter;
        var lang = this.state.languagefilter;
        var gendK = this.state.Gender;
        var AgeK = this.state.ageGroup;
        var WorkK = this.state.Workrate;
        var stateName = this.state.statefilter;
        var cityName = this.state.cityfilter;
        var avialdate = this.state.Avialdate;


        if(event == 'genderfilter')  {
            if(filterkey==1){ gender= 'Gender:male';}
            if(filterkey==2){ gender= 'Gender:female';}
            if(filterkey==3){ gender= 'Gender:other';}
            gendK = filterkey;
        }

        if(event == 'agefilter')  {
            if(filterkey==0){ age = 'Age:[* TO 100]';}
            if(filterkey==1){ age = 'Age:[10 TO 20]';}
            if(filterkey==2){ age = 'Age:[20 TO 25]';}
            if(filterkey==3){ age = 'Age:[25 TO 30]';}
            if(filterkey==4){ age = 'Age:[30 TO 35]';}
            if(filterkey==5){ age = 'Age:[35 TO 40]';}
            if(filterkey==6){ age= 'Age:[40 TO 50]';}
            if(filterkey==7){ age= 'Age:[50 TO 60]';}
            if(filterkey==8){ age= 'Age:[60 TO 70]';}
            if(filterkey==9){ age= 'Age:[70 TO 100]';}
            AgeK = filterkey;

        }
        if(event == 'feefilter')  {
            if(filterkey==0){ WorkRate = 'WorkRate:[* TO *]';}
            if(filterkey==1){ WorkRate = 'WorkRate:[* TO 5000]';}
            if(filterkey==2){ WorkRate = 'WorkRate:[5000 TO 10000]';}
            if(filterkey==3){ WorkRate = 'WorkRate:[10000 TO 15000]';}
            if(filterkey==4){ WorkRate = 'WorkRate:[15000 TO 20000]';}
            if(filterkey==5){ WorkRate = 'WorkRate:[20000 TO 30000]';}
            if(filterkey==6){ WorkRate = 'WorkRate:[30000 TO 40000]';}
            if(filterkey==7){ WorkRate = 'WorkRate:[40000 TO 50000]';}
            if(filterkey==8){ WorkRate = 'WorkRate:[50000 TO 75000]';}
            if(filterkey==9){ WorkRate = 'WorkRate:[75000 TO 100000]';}
            if(filterkey==10){ WorkRate = 'WorkRate:[100000 TO *]';}
            WorkK = filterkey;
        }
        if(event == 'languagefilter')  {
            lang = 'PrimaryLang:'+languages[filterkey];
            this.setState({currentLang:lang});
            var lang1 = 'SecondryLang:'+languages[filterkey];
            var langK = filterkey;

        }
        if(event == 'statefilter')  {
            this.onchangestates(this,filterkey);
            stateName = 'StateName:'+this.state.States[filterkey];
            this.setState({currentState:stateName});
            var statesK = filterkey;
        }
        if(event == 'cityfilter')  {
            cityName = 'CityName:'+this.state.Cities[filterkey];
            this.setState({currentCity:cityName});
            var cityK = filterkey;
        }
        if(value=='datefilter')
        {
            avialdate = 'AvailDate:'+this.state.Avialdate;
        }
        if(value == 'resetfilters')  {
            var gender='Gender: *';
            var age= 'Age:*';
            var WorkRate = 'WorkRate:*';
            var lang = 'PrimaryLang:*';
            var gendK = 0;
            var AgeK = 0;
            var WorkK = 0;
            var stateName = 'StateName:*';
            var cityName = 'CityName:*';
            var avialdate = '';
            this.setState({SortTerm:0, schedule_work_dates:'',currentLang:''});
            this.setState({Loader:true});
            var currentRoutes = this.props.location.pathname;
            var patt = /profession/g;
            var result = patt.exec(currentRoutes);
            if(result !== null){
                var arr = currentRoutes.split('/profession/');
                var reqarr = arr[1].replace('%20',' ');
                var queryS = reqarr+'&fq=Procat:'+'"'+reqarr+'"';

            }
            else {
                var arr = currentRoutes.split('search/');
                var queryS = '*'+arr[1].replace('%20',' ');
            }
            var searchbox = this.state.querystring;
            var urls = URL+searchbox+'&sort=Rating desc&start=0&rows=100000&wt=json';
            this.setState({
                Gender:gendK,
                languagefilter: lang,
                languagefilter1: lang1,
                Workrate:WorkK,
                genderfilter:gender,
                ageGroup:AgeK,
                feefilter:WorkRate,
                agefilter:age,
                statefilter:stateName,
                cityfilter:cityName,});
            this.SolrSearch(urls);

        }
        else{
            this.setState({Loader:true});
            var searchbox = this.state.querystring;
            var urls = URL+searchbox+'&fq='+ gender +'&fq='+ age +'&fq='+ WorkRate +'&fq='+ lang+'&fq='+stateName+'&fq='+cityName+'&fq='+avialdate+'&start=0&rows=100000&wt=json';
            this.setState({
                Gender:gendK,
                languagefilter: lang,
                languagefilter1: lang1,
                Workrate:WorkK,
                genderfilter:gender,
                ageGroup:AgeK,
                feefilter:WorkRate,
                agefilter:age,
                statefilter:stateName,
                cityfilter:cityName,});
            this.SolrSearch(urls);
        }
    }

    handleScheduleChange = (event, date) => {
        var avialdate= '*'+date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate()+'*';
        this.setState({
            schedule_work_dates: date,
            Avialdate:avialdate
        });
        this.datafilter(this, 'datefilter', avialdate);
    }

    submitdata(value, event) {
        if(event.keyCode == 13 || value == 'click'){
            var searchstring = this.state.searchbox;
            this.props.changeRoute('/search/'+searchstring);
        }
    }

    sortBy(event, value) {
        var gender=this.state.genderfilter;
        var age= this.state.agefilter;
        var nameorder = this.state.nameOrder;
        var likeorder = this.state.likeOrder;
        var ratingorder = this.state.ratingOrder;
        var workredorder = this.state.workredOrder;
        var workrateorder = this.state.workrateOrder;
        var idorder = this.state.idOrder;
        var WorkRate = this.state.feefilter;
        var lang = this.state.languagefilter;
        var lang1 = this.state.languagefilter1;
        var SortF = this.state.SortFilter;
        var stateName = this.state.statefilter;
        var cityName = this.state.cityfilter;
        var avialdate = this.state.Avialdate;
        this.setState({SortTerm:value,Loader:true});

        if(value=='1'){SortF='Firstname '+nameorder;if(nameorder ==='asc'){this.setState({nameOrder:'desc'})} else {this.setState({nameOrder:'asc' });}}
        if(value=='2'){SortF='Rating '+ratingorder;if(ratingorder ==='asc'){this.setState({ratingOrder:'desc'})}else {this.setState({ratingOrder:'asc' });}}
        if(value=='3'){SortF='WorkRate '+workrateorder;if(workrateorder ==='asc'){this.setState({workrateOrder:'desc'})}else {this.setState({workrateOrder:'asc' });}}
        if(value=='4'){SortF='worckredTotal '+workredorder;if(workredorder ==='asc'){this.setState({workredOrder:'desc'})}else {this.setState({workredOrder:'asc' });}}
        if(value=='5'){SortF='id '+idorder;if(idorder ==='asc'){this.setState({idOrder:'desc'})}else {this.setState({idOrder:'asc' });}}
        if(value=='6'){SortF='likesTotal '+likeorder;if(likeorder ==='asc'){this.setState({likeOrder:'desc'})}else {this.setState({likeOrder:'asc' });}}

        var currentRoutes = this.props.location.pathname;
        var patt = /profession/g;
        var result = patt.exec(currentRoutes);
        if(result !== null){
            var arr = currentRoutes.split('/profession/');
            var reqarr = arr[1].replace('%20',' ');
            var queryS = reqarr+'&fq=Procat:'+'"'+reqarr+'"';

        }
        else {
            var arr = currentRoutes.split('search/');
            var queryS = '*'+arr[1].replace('%20',' ');
        }

        var searchbox = queryS;
        var urls = URL+'?q='+searchbox+'&fq='+gender+'&fq='+ age +'&fq='+WorkRate+'&fq='+lang+'&sort='+SortF+'&fq='+stateName+'&fq='+cityName+'&fq='+avialdate+'&start=0&rows=100000&wt=json';
        cookie.save('SolrQuery', urls, { path: '/' });
        $.ajax({
            'url':urls,
            'success': function(data) {
                var queryparam = data.responseHeader.params.q;
                queryparam = queryparam.replace('%20',' ');
                queryparam = queryparam.replace('*','');
                this.setState({
                    data: data.response.docs,
                    proglob: data.response.numFound,
                    Qparam: queryparam,
                    searchbox: queryparam,
                    SortFilter:SortF,
                    Loader:false,
                }) }.bind(this),
            'dataType': 'jsonp',
            'jsonp': 'json.wrf',
        });
    }

    resetfilter(){
        this.datafilter(this, 'resetfilters');
    }
    searchfilter (event, value) {


    }


    childCategory(){

            var formState=this;
            var param = {action: 'get_home_cat'}
            util.getSetData(param, function (data) {

                if (data.status == "success" ){
                    formState.setState({
                        childCategory:data.child,
                        subChildCategory:data.subChild,
                        parentCategory:data.parent,

                    });

                    $(function(){

                        $('.search_keywords > li > a').click(function($scope) {

                            if (!$(this).parent().hasClass('active')){
                                $('#bannerBG').addClass('active');
                                $('.search_keywords > li').removeClass('active');
                                $(this).parent().addClass('active');
                                $('#search-container').addClass('active');
                            }
                            else{
                                $('.search_keywords > li').removeClass('active');
                                $('#search-container').removeClass('active');
                                $('#bannerBG').removeClass('active');
                            }
                        });

                        $('.search_keywords h3').click(function(){
                            $(this).toggleClass('active');
                            $(this).next('ul').toggleClass('active');
                        });
                        $('.searchFilterDrop').click(function(){
                            $('.search_keywords').css('margin-top','90px;');
                            $('#bannerBG').css('margin-top', '249;');
                        })
                    });
            }});
    }

    render () {


        $('.search-form').click(function(){
            $('.search_keywords > li').removeClass('active');
            $('#search-container').removeClass('active');
            $('#bannerBG').removeClass('active');
        })
        $('.site-header').click(function(){
            $('.search_keywords > li').removeClass('active');
            $('#search-container').removeClass('active');
            $('#bannerBG').removeClass('active');
        })
        $('.results').click(function(){
            $('.search_keywords > li').removeClass('active');
            $('#search-container').removeClass('active');
            $('#bannerBG').removeClass('active');
        })
        $('#blankupperhn').click(function(){
            $('.search_keywords > li').removeClass('active');
            $('#search-container').removeClass('active');
            $('#bannerBG').removeClass('active');
        });
        $('#bannerBG.active').click(function(){
            $('.search_keywords > li').removeClass('active');
            $('#search-container').removeClass('active');
            $('#bannerBG').removeClass('active');
        });



        const filteredProfile = this.state.data.filter(createFilter(this.state.searchTerm, ['Gender','WorkRate','SecondryLang','PrimaryLang']));
        var formState = this;
        return (
            <div className='page-content'>
                <div id='bannerBG'>
                    <div id="blankupperhn"></div>
                    <div className='search_con_wrapper'>
                        <div className='search_con'>
                            <div id='search-container'>
                                <p>Search by Keywords</p>
                                <form className='search-form'>
                                    <label htmlFor='search_field'>
                                        <input type='text'  title='Search for:' value={this.state.searchbox}  onChange={this.searchUpdated.bind(this,'searchbox')} onKeyDown = {this.submitdata.bind(this, 'keydown')} placeholder='Profession, Age, City' className='search-field' id='search_field' />
                                    </label>
                                    <input type='submit' value='Search' onClick={this.submitdata.bind(this, 'click')} className='search-submit' />

                                    <div className="searchFilterDrop">
                                        <div className="dropdown">
                                            <button className=" dropdown-toggle" type="button" data-toggle="dropdown">
                                                <span className="caret"></span></button>
                                            <ul className="dropdown-menu">
                                                <li><a href="#">Keywords</a></li>
                                                <li><a href="#">Media</a></li>
                                                <li><a href="#">Projects</a></li>
                                            </ul>
                                        </div>
                                    </div>

                                </form>
                            </div>
                            <div className="search_othres active">
                                <ul className="search_keywords">
                                    {this.state.parentCategory.map(c =>
                                        <li  key={c.category_id} className={'kl'+c.category_id}><a href="javascript:void(0)"  data-id={c.category_id} >{c.category_name}</a>
                                            <div className="search_desc" id={c.category_id}>

                                                {this.state.childCategory[c.category_id].map(d =>
                                                        <div className="search_dd_cat" key={d.category_id}>
                                                            <h3><a href="javascript:void(0)">{d.category_name}</a> <span className="mobile_back_btn"></span> </h3>
                                                            <ul className="aaa">
                                                                {this.state.subChildCategory[d.category_id].map(L =>
                                                                        <li key={L.category_id}><a href={"/search/profession/"+L.category_name} className="subcategory_search" data-id={L.category_id} >{L.category_name}</a></li>
                                                                )}
                                                            </ul></div>
                                                )}


                                            </div>

                                        </li>)}
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div className='results'>
                    <div className='container'>
                        <div className='row result-count'>
                            <div className='col-lg-4 col-md-5 col-sm-12 col-xs-12 pull-right right'>
                                <div id='sorting'>
                                    <label>Sort by</label>
                                    <SelectField value={this.state.SortTerm}  onChange={this.sortBy.bind(this)} className='SearchSelectBox2'>
                                        <MenuItem value={0} primaryText='Sort' />
                                        <MenuItem value={1} primaryText='Name' rightIcon={ <FontIcon className="NameArrow"> <i className={(this.state.nameOrder==='asc' && this.state.SortTerm ===1)? "fa fa-angle-down": (this.state.SortTerm ===1)?"fa fa-angle-up":''} aria-hidden="true"></i></FontIcon>} />
                                        <MenuItem value={2} primaryText='Ratings' rightIcon={ <FontIcon className="NameArrow"> <i className={(this.state.ratingOrder==='asc' && this.state.SortTerm ===2)? "fa fa-angle-up": (this.state.ratingOrder==='desc' && this.state.SortTerm ===2)?"fa fa-angle-down":''} aria-hidden="true"></i></FontIcon>} />
                                        <MenuItem value={3} primaryText='Avg. Professional Fee' rightIcon={ <FontIcon className="NameArrow"> <i className={(this.state.workrateOrder==='asc' && this.state.SortTerm ===3)? "fa fa-angle-down": (this.state.SortTerm ===3)?"fa fa-angle-up":''} aria-hidden="true"></i></FontIcon>}/>
                                        <MenuItem value={4} primaryText='Workcred' rightIcon={ <FontIcon className="NameArrow"> <i className={(this.state.workredOrder==='asc' && this.state.SortTerm ===4)? "fa fa-angle-down":(this.state.SortTerm ===4)?"fa fa-angle-up":'' } aria-hidden="true"></i></FontIcon>}/>
                                        <MenuItem value={5} primaryText='Newest' rightIcon={ <FontIcon className="NameArrow"> <i className={(this.state.idOrder==='asc' && this.state.SortTerm ===5)? "fa fa-angle-down": (this.state.SortTerm ===5)?"fa fa-angle-up":''} aria-hidden="true"></i></FontIcon>}/>
                                        <MenuItem value={6} primaryText='Likes' rightIcon={ <FontIcon className="NameArrow"> <i className={(this.state.likeOrder==='asc' && this.state.SortTerm ===6)? "fa fa-angle-down":(this.state.SortTerm ===6)?"fa fa-angle-up":''} aria-hidden="true"></i></FontIcon>}/>
                                    </SelectField>
                                </div>
                                <a href='javascript:void(0)' onClick={this.resetfilter.bind(this)} className='greyBtn'>Reset Filter</a></div>
                            <div className='col-lg-4 col-md-3 col-sm-6 col-xs-12'>
                                <p>Showing Results for: <strong>{this.state.Qparam}</strong></p>
                            </div>
                            <div className='col-lg-4 col-md-4 col-sm-6 col-xs-12'>
                                <p>Current Filter Results: <strong>{this.state.proglob} Profiles</strong></p>
                            </div>
                        </div>
                        <div className='row'>
                            <div className='filter'>
                                <div className='col-md-2 col-sm-4 col-xs-12'>
                                    <SelectField value={this.state.Gender} onChange={this.datafilter.bind(this, 'genderfilter')} className='SearchSelectBox'>
                                        <MenuItem value={0}  primaryText='Gender' />
                                        <MenuItem value={1}  primaryText='Male' />
                                        <MenuItem value={2}  primaryText='Female' />
                                        <MenuItem value={3}  primaryText='Other' />
                                    </SelectField>
                                </div>
                                <div className='col-md-2 col-sm-4 col-xs-12'>
                                    <SelectField value={this.state.ageGroup} onChange={this.datafilter.bind(this, 'agefilter')} className='SearchSelectBox'>
                                        <MenuItem value={0} primaryText='Age Group' />
                                        <MenuItem value={1} primaryText='10-20' />
                                        <MenuItem value={2} primaryText='20-25' />
                                        <MenuItem value={3} primaryText='25-30' />
                                        <MenuItem value={4} primaryText='30-35' />
                                        <MenuItem value={5} primaryText='35-40' />
                                        <MenuItem value={6} primaryText='40-50' />
                                        <MenuItem value={7} primaryText='50-60' />
                                        <MenuItem value={8} primaryText='60-70' />
                                        <MenuItem value={9} primaryText='70 Above' />
                                    </SelectField>
                                </div>
                                <div className='col-md-2 col-sm-4 col-xs-12'>
                                    <div className='location dropdown'> <a href='javascript:void(0)'> <div className='SearchLang'>
                                        <AutoComplete
                                            filter={AutoComplete.caseInsensitiveFilter}
                                            dataSource={languages}
                                            onUpdateInput={this.state.currentLang}
                                            hintText='Language'
                                            triggerUpdateOnFocus={true}
                                            openOnFocus={true}
                                            searchText={this.state.currentLang}
                                            onNewRequest={this.datafilter.bind(this, 'languagefilter')}
                                            />
                                    </div></a>  </div>

                                </div>
                                <div className='col-md-2 col-sm-4 col-xs-12'>
                                    <div className='location dropdown'> <a data-toggle='dropdown' href='#location'>Location</a>
                                        <div className='dropdown-menu'>
                                            <div className='col-sm-4'>
                                                <div className='SearchInputTxt'>
                                                    <AutoComplete
                                                        filter={AutoComplete.caseInsensitiveFilter}
                                                        dataSource={country}
                                                        hintText='Country'
                                                        openOnFocus={true}
                                                        triggerUpdateOnFocus={true}
                                                        searchText={this.state.currentCountry}

                                                        onNewRequest={this.onchangecountry.bind(this)}
                                                        />
                                                </div>
                                            </div>
                                            <div className='col-sm-4'>
                                                <div className='SearchInputTxt'>
                                                    <AutoComplete
                                                        filter={AutoComplete.caseInsensitiveFilter}
                                                        dataSource={(this.state.States!=='')?this.state.States:[]}
                                                        hintText='State'
                                                        openOnFocus={true}
                                                        triggerUpdateOnFocus={true}
                                                        searchText={this.state.currentState}
                                                        onNewRequest={this.datafilter.bind(this, 'statefilter')}
                                                        />
                                                </div>
                                            </div>
                                            <div className='col-sm-4'>
                                                <div className='SearchInputTxt'>
                                                    <AutoComplete
                                                        filter={AutoComplete.caseInsensitiveFilter}
                                                        dataSource={(this.state.Cities!=='')?this.state.Cities:[]}
                                                        hintText='City  '
                                                        openOnFocus={true}
                                                        searchText={this.state.currentCity}
                                                        onNewRequest = {this.datafilter.bind(this, 'cityfilter')}
                                                        />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className='col-md-2 col-sm-4 col-xs-12'>
                                    <SelectField value={this.state.Workrate} onChange={this.datafilter.bind(this, 'feefilter')} className='SearchSelectBox'>
                                        <MenuItem value={0} primaryText='Average Fee' />
                                        <MenuItem value={1} primaryText='Below 5000 /day' />
                                        <MenuItem value={2} primaryText='5000-10000 /day' />
                                        <MenuItem value={3} primaryText='15000-20000 /day' />
                                        <MenuItem value={4} primaryText='20000-30000 /day' />
                                        <MenuItem value={5} primaryText='30000-40000 /day' />
                                        <MenuItem value={6} primaryText='40000-50000 /day' />
                                        <MenuItem value={7} primaryText='50000-75000 /day' />
                                        <MenuItem value={8} primaryText='75000-1L /day' />
                                        <MenuItem value={9} primaryText='Above 1L /day' />
                                    </SelectField>
                                </div>
                                <div className='col-md-2 col-sm-4 col-xs-12'>
                                    <div className='calendar'>
                                        <DatePicker hintText='Availability' value={this.state.schedule_work_dates} autoOk = {true} container='inline'
                                                    onChange={this.handleScheduleChange}  className='date_pick hasDatepicker SearchPicDate'/>
                                    </div></div>
                            </div>
                        </div>
                        <div className='row'>
                            <div className='showFilters'>
                                <a href='javascript:void(0);'></a>
                            </div>
                        </div>
                        <div className='row'>
                            <div className='col-xs-12 search_result_out' >
                                {(this.state.Loader===true)?<div className="bigLoader"> <i><img src='http://kalakar.pro:90/kalakar/demo/other/assets/img/loader.svg'/></i></div>: ''}
                                <ul>
                                    {filteredProfile.map(function (c,i) {
                                        return <SearchProfilesList obj={c} key={i} isBookmarked={formState.isBookmarked.bind(formState)} getBookmarkList={formState.getBookmarkList.bind(formState)}/>

                                    } )}
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );

    }


}
Search.propTypes = {
    changeRoute: React.PropTypes.func,
};
function mapDispatchToProps(dispatch) {
    return {
        changeRoute: (url) => dispatch(push(url)),
    };
}

export default connect(null, mapDispatchToProps)(Search);
