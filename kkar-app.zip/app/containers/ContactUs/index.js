import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';


export class ContactUs extends React.Component {
    openRoute = (route) => {
        this.props.changeRoute(route);
    };

    constructor(props) {
        super(props);

        this.state = {
            name: '',email:'', phone: '', message: ''
        }
    }
    handleInputChange(name, e) {
        var change = {};
        change[name] = e.target.value;
        this.setState(change);
    }
    sendMessage(){
        alert('message sent');
        //var formState = this;
        //var param = {action: ''};
        //util.getSetData(param, function (data) {
        //    if (data.status === 'success') {
        //
        //    }
        //
        //});
    }


    render() {
        return (
            <div className="inner-page testimonialPage ">

                <div className="container cinta">

                    <h1>Contact Us</h1>
                </div>
                <div>
                    <iframe
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d448181.1702143901!2d76.81237738507731!3d28.6472784208342!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390cfd5b347eb62d%3A0x37205b715389640!2sDelhi!5e0!3m2!1sen!2sin!4v1476772919409"
                        style={{width:'100%',height:'300px'}} allowFullScreen></iframe>
                </div>
                <div>
                    <div>
                        <h3>Head Office, Noida</h3>
                        <address>Incred Applications Pvt LtdF-43,
                            Sector 8 ,
                            Noida - 201301,
                            U.P. India

                            <i className="fa fa-phone-square"></i> Phone: (0120) 423-0522
                            <i className="fa fa-fax"></i>Fax: (0120) 423-0522
                            <i className="fa fa-envelope"></i>Email:support@kalakar.pro
                        </address>
                    </div>
                    <div>
                        <h3>Branch Office, Mumbai</h3>
                        <address>
                            Incred Applications,
                            F 43, sector 8,
                            Aram Nagar - 201301,
                            Mumbai, India
                            <i className="fa fa-phone-square"></i> Phone: (0120) 423-0522
                            <i className="fa fa-fax"></i>Fax: (0120) 423-0522
                            <i className="fa fa-envelope"></i>Email:support@kalakar.pro
                        </address>
                    </div>
                    <div>
                        <h3>Send us a message</h3>

                        <div>
                            <input type='text' placeholder="Name" onChange={this.handleInputChange.bind(this,'name')}/>
                            <input type='text' placeholder="Email Address" onChange={this.handleInputChange.bind(this,'email')}/>
                            <input type='text' placeholder="Phone Number" onChange={this.handleInputChange.bind(this,'phone')}/>
                            <textarea type='text' placeholder="Write your message here" onChange={this.handleInputChange.bind(this,'message')}/>
                            <button onClick={this.sendMessage.bind(this)}>Send Message</button>

                        </div>
                    </div>
                </div>
            </div>
        )
    }
}
ContactUs.propTypes = {
    changeRoute: React.PropTypes.func,
};

function mapDispatchToProps(dispatch) {
    return {
        changeRoute: (url) => dispatch(push(url)),
    };
}

export default connect(null,
    mapDispatchToProps)(ContactUs);
