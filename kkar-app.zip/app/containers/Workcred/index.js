import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import {DashboardMenu} from 'components/DashboardMenu';
import TextField from 'material-ui/TextField';
import {ViewEdit} from 'components/ViewEdit_Component';
import {ProgressSlider} from 'components/ProgressSlider';
import Dialog from 'material-ui/Dialog';
import cookie from 'react-cookie';
var util = require('utils/request');
var ProgressStyle = {
    width: '60%'
};


export class WorkcredDetails extends React.Component {
    openRoute = (route) => {
        this.props.changeRoute(route);
    };

    constructor(props) {
        super(props);
        this.state = {
            stateUpdate:false,
            workcreddata: [],
            workcred_data: {
                id_workcred: 0,
                worked_as: '',
                project_name: '',
                work_photo_name : '',
                work_photo: '',
                work_media: '',
                work_video: '',
                work_link: '',
                number_of_days_workcred: '',
                year_of_project: '',
                button_text: 'ADD',
                result: null,
                resultMsg: ''
            },
            years: [1976, 1977, 1978, 1979, 1980, 1981, 1982, 1983, 1984, 1985, 1986, 1987, 1988, 1989, 1990, 1991, 1992, 1993, 1994, 1995,
                1996, 1997, 1998, 1999, 2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016]

        }

    }

    componentDidMount() {
      document.title = "Extended Profile | Kalakar";
      (function($){
             $(window).load(function(){
             $(".scroller335").mCustomScrollbar({
                 setHeight:335,
                 theme:"dark-3"
               });
             });

         })(jQuery);



        var local = this;
        $("[data-toggle='tooltip']").tooltip();
        document.getElementById("uploadBtn").onchange = function () {
            var filename = this.value.replace(/^.*\\/, "");
            document.getElementById("uploadFile").value = filename;
            local.isDisabledImageUpload(filename);
        };
        var param = {action: 'workcred_list', profile_id: this.props.params.profileId}
        var formState = this;
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                formState.setState({
                    workcreddata: data.data
                });
                formState.initializeGallery();
            }
            else {
                  console.log("Error in WorkcredList.Please try again.");
            }
        });
    }
    initializeGallery(){
        jQuery('#lightgallery').lightGallery();
        jQuery('.lightgallery-single-image').lightGallery();
        jQuery('.lightgallery-single-video').lightGallery();
    }
    handleEditClick(id, local) {
        var param = {action: 'workcred_detail', workcred_id: id}
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                var change = {};
                change.workcred_data = data.data[0];
                change.workcred_data["button_text"] = "UPDATE";
                local.setState(change);

            }

        });
    }

    handleDeleteClick(id,local) {
      var param = {action: 'deleteWorkcred', workcred_id: id}
      util.getSetData(param, function (data) {
      if (data.status == "success") {
         alert("Record deleted successfully.");
       }

       });
    }


    handleInputChange(name, e) {
        var change = {};
        change.workcred_data = this.state.workcred_data;
        change.workcred_data[name] = e.target.value;
        this.setState(change);
        if (name == 'worked_as') {
            this.validate1();
        }
        if (name == 'project_name') {
            this.validate2();
        }
        if (name == 'work_video') {
            this.isDisabledWebsite();
        }
        if (name == 'work_link') {
            this.isDisabledLink();
        }
        if (name == 'number_of_days_workcred') {
            this.validate3();
        }
    }

    handleChange(e) {
        var change = {};
        change.workcred_data = this.state.workcred_data;
        change.workcred_data['year_of_project'] = e.target.value;
        this.setState(change);
        this.validateSelect();
    }

    handleImageChange(e) {
        e.preventDefault();
        let reader = new FileReader();
        let file = e.target.files[0];
        reader.onloadend = () => {
            var change = {};
            change.workcred_data = this.state.workcred_data;
            change.workcred_data['work_photo'] = reader.result;
            change.workcred_data['work_photo_name'] = file.name;
            this.setState(change);

        };
        reader.readAsDataURL(file);
    }


    validate1() {
        let valid = false;
        if (this.state.workcred_data.worked_as == "") {
            this.setState({
                worked_error_text: "Required"
            });
        } else {
            valid = true
            this.setState({
                worked_error_text: null
            })

        }
        return valid;
    }

    validate2() {
        let valid = false;
        if (this.state.workcred_data.project_name == "") {
            this.setState({
                project_name_error: "Required"
            });
        } else {
            valid = true
            this.setState({
                project_name_error: null
            })

        }
        return valid;
    }

    validate3() {
        let valid = false;
        if (this.state.workcred_data.number_of_days_workcred == "") {
            this.setState({
                dworked_error_text: "Required"
            });
        } else {
            valid = true
            this.setState({
                dworked_error_text: null
            })

        }
        return valid;
    }

    validateWebsite(value) {
        var exp = /^(?:(?:http|https):\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.]*)*\/?.*$/
        return exp.test(value);
    }

    isDisabledWebsite() {
        let urlIsValid = false;
        if (this.state.workcred_data.work_video === "") {
            urlIsValid = true;
            this.setState({
                website_error_text: null
            });
        } else {
            if (this.validateWebsite(this.state.workcred_data.work_video)) {
                urlIsValid = true;
                this.setState({
                    website_error_text: null
                });
            }
            else {
                this.setState({
                    website_error_text: "Sorry, this is not a valid format"
                });
            }
        }
        return urlIsValid;
    }

    isDisabledLink() {
        let urlIsValid = false;
        if (this.state.workcred_data.work_link === "") {
            urlIsValid = true;
            this.setState({
                lwebsite_error_text: null
            });
        } else {
            if (this.validateWebsite(this.state.workcred_data.work_link)) {
                urlIsValid = true;
                this.setState({
                    lwebsite_error_text: null
                });
            }
            else {
                this.setState({
                    lwebsite_error_text: "Sorry, this is not a valid format"
                });
            }
        }
        return urlIsValid;
    }

    validateSelect() {
        let valid = false;
        if (this.state.workcred_data.year_of_project == "") {
            this.setState({
                    year_error_text: "Required"
                }
            );
        } else {
            valid = true;
            this.setState({
                year_error_text: null
            });

        }
        return valid;
    }

    validateImageUpload(value) {
        var exp = /([a-zA-Z0-9\s_\\.\-:])+(.png|.jpg|.gif|.jpeg)$/;
        return exp.test(value);
    }

    isDisabledImageUpload(value) {

        let urlIsValid = false;
        if (value === "") {
            urlIsValid = true;
            this.setState({
                photo_error_text: null
            });
        } else {
            if (this.validateImageUpload(value)) {
                urlIsValid = true;
                this.setState({
                    photo_error_text: null
                });
            }
            else {
                this.setState({
                    photo_error_text: "Please upload Valid image file"
                });
            }
        }
        return urlIsValid;
    }

    uploadMedia(){
      var form = this;
      var param = {
        action : 'mediaupload',
        user_id : cookie.load('userId'),
        profile_id : this.props.params.profileId,
        file_name : this.state.workcred_data.work_photo_name,
        imgsrc : this.state.workcred_data.work_photo
      }
      util.getSetData(param, function (mediaData) {
          if (mediaData.status == "success") {
              form.uploadWorkcred(mediaData.mediaId);
           }

      });
    }

    uploadWorkcred(mediaId){
      var formState = this;
      var workreadParam = {
        action : "workcred",
        number_of_days_workcred : this.state.workcred_data.number_of_days_workcred,
        profile_id : this.props.params.profileId,
        project_name : this.state.workcred_data.project_name,
        work_link : this.state.workcred_data.work_link,
        work_media : mediaId,
        worked_as : this.state.workcred_data.worked_as,
        year_of_project : this.state.workcred_data.year_of_project,
        work_video : this.state.workcred_data.work_video
      }
      if (this.state.workcred_data.id_workcred != 0) {
          workreadParam["workcred_id"] = this.state.workcred_data.id_workcred;
      }

      util.getSetData(workreadParam, function (data) {
          if (data.status == "success") {
              formState.state.stateUpdate = true;
              var param = {action: 'workcred_list', profile_id: formState.props.params.profileId}
              util.getSetData(param, function (data1) {
                  document.getElementById("uploadFile").value = "";
                  if (data1.status == "success") {
                      formState.setState({
                          workcreddata: data1.data,
                          workcred_data: {
                              worked_as: '',
                              project_name: '',
                              work_photo: '',
                              work_photo_name: '',
                              work_video: '',
                              work_link: '',
                              work_media: '',
                              number_of_days_workcred: '',
                              year_of_project: '',
                              button_text: "Add",
                              result: true,
                              resultMsg: data.message
                          }
                      })
                      formState.initializeGallery();
                  }
              })
          }
          else {
              var change = {};
              change.workcred_data = formState.state.workcred_data;
              change.workcred_data["result"] = false;
              change.workcred_data["resultMsg"] = data.message;
              formState.setState(change);

          }
      });
    }

    submitWorkcred(e) {
        e.preventDefault();
        if (!(this.validate1() && this.validate2() && this.isDisabledWebsite() && this.isDisabledLink() && this.validate3()
            && this.validateSelect())) {
            this.validate1();
            this.validate2();
            this.validate3();
            this.isDisabledWebsite();
            this.isDisabledLink();
            this.validateSelect();
            return;
        }
      //  if(this.state.workcred_data.work_photo != '' && this.state.workcred_data.work_photo != 0)
       if(this.state.workcred_data.work_photo_name != undefined && this.state.workcred_data.work_photo_name != "" && this.state.workcred_data.work_photo_name != null && this.state.workcred_data.work_photo_name != 0)
        {
          //Media upload
          this.uploadMedia();
        }
        else {
          //workred
          if(this.state.workcred_data.work_photo != "" && this.state.workcred_data.work_photo != null){
              this.uploadWorkcred(this.state.workcred_data.work_photo);
            }
          else
          {
                  this.uploadWorkcred(0);
          }
        }

    }

    Continue() {
        var p_id = this.props.params.profileId;
        this.props.changeRoute('/my-accounts/extended-profile/' + p_id + '/training');
    }

    render() {
        var updateState = false;
        if(this.state.stateUpdate)
        {
            updateState = true;
            this.state.stateUpdate = false;
        }

        var local = this;
        return (
            <div>
                <section className="inner-page basic-profile">
                    <DashboardMenu page="Workcred" profileId={this.props.params.profileId}/>

                    <div className="pageRest cell">
                        <div className="basic-profile-inner">
                            {this.state.workcred_data.result == true &&
                            <div className="sucess_ep">{this.state.workcred_data.resultMsg}</div> }
                            {this.state.workcred_data.result == false &&
                            <div className="error_ep">{this.state.workcred_data.resultMsg}</div> }
                            <form onSubmit={this.submitWorkcred.bind(this)}>
                                <div className="row">
                                    <div className="col-sm-6 ">
                                        <div className="btn_inline_view">
                                            <h1 className="h1_btn">Workcred</h1>
                            <span className="lightgallery-single-video">
                             <li className="video" data-src="https://www.youtube.com/watch?v=1rx5xFpMH3Y&feature=youtu.be">
                                 <button type="button" className=" btn video_assist_btn">Video Assist <i className="fa fa-play-circle"></i></button>
                             </li></span>

                                        </div>
                                    </div>
                                    <div className="col-sm-6">
                                        <h3>Step 4/14</h3>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-xs-12 lastCol">
                                        <input type="text" placeholder="Worked as"
                                               value={this.state.workcred_data.worked_as}
                                               onBlur={this.handleInputChange.bind(this,'worked_as')}
                                               onChange={this.handleInputChange.bind(this,'worked_as')}
                                            />
                                        <small className="errorMsg">{this.state.worked_error_text}</small>
                                        <i className="fa fa-info" data-toggle="tooltip" title=""
                                           data-original-title="Worked as"></i>
                                    </div>

                                    <div className="col-xs-12 lastCol">
                                        <input type="text" placeholder="Name of Project"
                                               value={this.state.workcred_data.project_name}
                                               onBlur={this.handleInputChange.bind(this,'project_name')}
                                               onChange={this.handleInputChange.bind(this,'project_name')}/>
                                        <small className="errorMsg">{this.state.project_name_error}</small>

                                        <i className="fa fa-info" data-toggle="tooltip" title=""
                                           data-original-title="Project Name"></i>
                                    </div>

                                    <div className="row">
                                        <div className="col-xs-12">
                                            <div className="col-md-4 col-sm-4 col-xs-12 uploadBasicPh">
                                                <input id="uploadFile" type="text" placeholder="Verify by Photo"
                                                       value={this.state.value}/>
                                                <small className="errorMsg">{this.state.photo_error_text}</small>
                                                <div className="fileUpload">
                                                    <span></span>
                                                    <input id="uploadBtn" type="file" accept="image/*"
                                                           className="upload"
                                                           onChange={this.handleImageChange.bind(this)}/>

                                                    <i className="fa fa-upload" aria-hidden="true"></i>
                                                </div>
                                            </div>
                                            <div className="col-md-4 col-sm-4 col-xs-12">
                                                <input type="text" placeholder="Verify by Video"
                                                       value={this.state.workcred_data.work_video}
                                                       onChange={this.handleInputChange.bind(this,'work_video')}/>
                                                <small className="errorMsg">{this.state.website_error_text}</small>
                                            </div>

                                            <div className="col-md-4 col-sm-4 col-xs-12 lastCol">
                                                <input type="text" placeholder="Verify by Link"
                                                       value={this.state.workcred_data.work_link}
                                                       onChange={this.handleInputChange.bind(this,'work_link')}/>
                                                <small className="errorMsg">{this.state.lwebsite_error_text}</small>
                                                <i className="fa fa-info" data-toggle="tooltip" title=""
                                                   data-original-title="Links"></i>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="col-md-3 col-sm-4 col-xs-12">
                                        <select value={this.state.workcred_data.year_of_project}
                                                onChange={this.handleChange.bind(this)}>
                                            <option value="">Years</option>
                                            {this.state.years.map(c =>
                                                    <option value={c} key={c}>{c}</option>
                                            )}
                                        </select>
                                        <small className="errorMsg">{this.state.year_error_text}</small>

                                    </div>

                                    <div className="col-md-3 col-sm-4 col-xs-12">
                                        <input placeholder="No. of Days Worked" type="number" min="0"
                                               value={this.state.workcred_data.number_of_days_workcred}
                                               onBlur={this.handleInputChange.bind(this,'number_of_days_workcred')}
                                               onChange={this.handleInputChange.bind(this,'number_of_days_workcred')}/>
                                        <small className="errorMsg">{this.state.dworked_error_text}</small>
                                    </div>

                                    <div className="col-md-6 col-sm-4 col-xs-12 lastCol alignRigh1">
                                        <button
                                            className="add_val_btn marginTopBott4">{this.state.workcred_data.button_text}</button>
                                    </div>
                                </div>


                                <div className="row">
                                    <div className="col-xs-12 lastCol">
                                        <div className="spacerLine"></div>
                                    </div>
                                </div>
                                <div className="scroller335">
                                  <div className="row">
                                    <div className="col-xs-12">
                                      {this.state.workcreddata.map(function (obj, i) {
                                          return <ViewEdit key={i} id_workcred={obj.id_workcred} institute={obj.worked_as}
                                           project_name={obj.project_name}
                                           year={obj.year_of_project + " | "}
                                           no_days={obj.number_of_days_workcred} duration="Days"
                                           hPhoto={obj.photourl} hVideo={obj.work_video}
                                           hLink={obj.work_link}
                                           onClick={local.handleEditClick.bind(null,obj.id_workcred,local)}
                                           onDeleteClick={local.handleDeleteClick.bind(null,obj.id_workcred,local)}/>
                                      })}
                                    </div>
                                  </div>
                                </div>


                                <div className="row">
                                    <div className="col-sm-12 col-xs-12 alignRigh1">
                                        <button type="button" onClick={this.Continue.bind(this)} className="btn btn-profile2 big ">
                                            Continue <i
                                            className="fa fa-chevron-right"></i></button>
                                    </div>
                                </div>

                                <ProgressSlider profileId = {this.props.params.profileId} stateUpdate={updateState}/>
                            </form>
                        </div>

                    </div>


                </section>
            </div>
        )
    }

}
WorkcredDetails.propTypes = {
    changeRoute: React.PropTypes.func,
};

function mapDispatchToProps(dispatch) {
    return {
        changeRoute: (url) => dispatch(push(url)),
    };
}

export default connect(null,
    mapDispatchToProps)(WorkcredDetails);
