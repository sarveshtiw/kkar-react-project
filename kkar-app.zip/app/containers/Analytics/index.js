import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import Dialog from 'material-ui/Dialog';
var util = require('utils/request');
import cookie from 'react-cookie';
import { API_URL } from 'containers/App/constants';
import {Chart} from 'react-google-charts';
import {DashboardHeader} from 'components/DashboardHeader_Component';
const color = ["theatreColor", "direphotoColor", "choreographerColor", "landsArchiColor", "rockPopColor", "indianClasstheatreColor", "horseRidingColor"];
export class Analytics extends React.Component {
    openRoute = (route) => {
        this.props.changeRoute(route);
    };

    constructor(props) {
        super(props);
        this.state = {
            profileData: [],
            likes: {},
            month: '',
            line: "all",
            page_views: {},
            citydata: [],
            activeProfileIndex:-1
        }
    }

    componentDidMount() {
        document.title = "My Dashboard | Kalakar";
        var rows1 = [];
        var arr = ["City", "View_Counts", {role: 'style'}];
        var colors = ['#000080', '#57a695','#feb72f','#abd14b','#0098da','#ed6f47','#91d8f7','#008080', '#808080', '#800080', "#800000", "#FF0000",'#00FFFF','#00FF00','#0000FF'];
        var option1 = {
            chartArea: {backgroundColor: '#ffffff',
                width:'80%',height:'65%'},
            seriesType: "bars",
            hAxis: {
                gridlines: {
                    color: 'transparent'
                },
                slantedTextAngle :330,
                slantedText:true
            },
            vAxis: {
                gridlines: {
                    color: 'transparent'
                },
                textColor: '#ffffff',
                showAxisLines: false
            },
            legend: 'none'
        }
        var param = {action: 'analytics2', user_id: cookie.load('userId')};
        $.ajax({
            url: API_URL,
            type: "POST",
            dataType: 'json',
            data: param,
            success: function (data) {
                if (data != null && data!="null") {

                    var cd = data.sort(function (a, b) {
                        return b.view_count - a.view_count;
                    });

                    formState.setState({
                        citydata: cd,
                        rows1: rows1,
                        option1: option1,
                        colors: colors
                    });

                    rows1.push(arr);
                    for (var i = 0; i < formState.state.citydata.length && i < 15; i++) {
                        var obj = formState.state.citydata[i];
                        var color = "color: " + colors[i];
                        rows1.push([obj.city, obj.view_count, color]);
                    }

                }
                else{
                    formState.setState({
                        citydata: [],
                        rows1: [],
                        option1:option1,
                        colors: colors
                    });
                }
            }.bind(this)

        });


        var profileParam = {action: 'profilesList', user_id: cookie.load('userId')}
        var formState = this;
        util.getSetData(profileParam, function (data) {
            if (data.status == "success") {
                if (data.data != null) {
                    formState.setState({
                        profileData: data.data,

                    });
                }
            }
        });

        var currentMonth = (new Date()).getMonth() + 1;
        this.lineChart(currentMonth, this.state.line, null);

    }

    lineChart(month, line, profileid) {
        var formState = this;
       // var colors = ['#FF0000', '#800080', '#00FA9A', '#FFFF99'];
        var rows = [];
        var param;
        if (profileid == null) {
            param = {action: 'analytics', user_id: cookie.load('userId'), month: month};
        } else {
            param = {action: 'analytics', user_id: cookie.load('userId'), month: month, profile_id: profileid};
        }


        this.setState({
            month: month,
            line: line,
            profile: profileid
        });


        var options = {
            chartArea: {backgroundColor: '#ffffff', strokeWidth: 1,
                width:'80%',height:'80%'},
            hAxis: {

                gridlines: {
                    color: 'transparent'
                },
                format:"MMM d, y",
                baselineColor:'black',
                baseline: new Date('2016-'+month+"-1"),
                textStyle: {
                    color:"#ffffff"
                }
            },

            vAxis: {

                gridlines: {
                    color: 'transparent'
                },
                viewWindow: {
                    min:0
                },
                baselineColor:'black',
                baseline:0
            },
            lineWidth:3,
            colors: ['red', 'purple', 'LimeGreen', 'GoldenRod'],
            legend: 'none'
        };

        var columns = [
            {
                'type': 'date',
                'label': 'Date'
            }
        ];

        if (line == "all" || line == "likes") {
            columns.push({
                'type': 'number',
                'label': 'Likes'
            });
            if(line == "likes"){
                options.colors= ['red'];
            }
        }

        if (line == "all" || line == "bookmarks") {
            columns.push({
                'type': 'number',
                'label': 'Bookmarks'
            });
            if(line == "bookmarks") {
                options.colors = ['purple'];
            }
        }
        if (line == "all" || line == "page_views") {
            columns.push({
                'type': 'number',
                'label': 'Page Views'
            });
            if(line == "page_views") {
                options.colors= ['LimeGreen'];
            }
        }

        if (line == "all" || line == "gallery") {
            columns.push({
                'type': 'number',
                'label': 'Gallery'
            });
            if(line == "gallery") {
                options.colors = ['GoldenRod'];
            }
        }

        util.getSetData(param, function (data) {
            if (data.status == "success") {
                formState.setState({
                    likes: data.likes,
                    page_views: data.page_views,
                    bookmarks: data.bookmarks,
                    gallery: data.gallery
                });

                for (var key in formState.state.likes)
                {
                    rows.push([new Date('2016-'+formState.state.month+'-'+key)]);
                }


                if (line == "all" || line == "likes") {
                    for (var key in formState.state.likes) {
                        if (formState.state.likes.hasOwnProperty(key)) {
                            rows[parseInt(key) - 1].push(formState.state.likes[key]);
                        }
                    }
                }
                if (line == "all" || line == "bookmarks") {
                    for (var key in formState.state.bookmarks) {
                        if (formState.state.bookmarks.hasOwnProperty(key)) {
                            rows[parseInt(key) - 1].push(formState.state.bookmarks[key]);
                        }
                    }
                }

                if (line == "all" || line == "page_views") {
                    for (var key in formState.state.page_views) {
                        if (formState.state.page_views.hasOwnProperty(key)) {
                            rows[parseInt(key) - 1].push(formState.state.page_views[key]);
                        }
                    }
                }

                if (line == "all" || line == "gallery") {
                    for (var key in formState.state.gallery) {
                        if (formState.state.gallery.hasOwnProperty(key)) {
                            rows[parseInt(key) - 1].push(formState.state.gallery[key]);
                        }
                    }
                }

                formState.setState({
                    'rows': rows,
                    'columns': columns,
                    'options': options
                });
            }
        });


    }

coloIndex(index){
    this.setState({
        activeProfileIndex:index
    });

}
    handleOptionChange(name, e) {
        var change = {};
        change[name] = e.target.value;
        this.setState(change);
        this.lineChart(e.target.value, this.state.line, this.state.profile);
    }

    render() {
        return (

            <section className="inner_page">
                <DashboardHeader page="Analytics"/>

                <div className="container">

                    <div className="dashMsg">
                        <div className="row">
                            <div className="col-sm-12">
                                <div className="filterMsgOuter">
                                    <ul className="filterMsg">
                                        {this.state.profileData.map((ph, i) =>
                                                <li key={ph.profile_id} className={color[i]}>
                                                    <a href="javascript:void(0)" className={(this.state.activeProfileIndex==i)?"active":""}
                                                       onTouchTap={this.coloIndex.bind(this,i)}
                                                       onClick={this.lineChart.bind(this,this.state.month, "all",ph.profile_id)}>{ph.profileName}</a>
                                                </li>
                                        )}
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-xs-12">
                                <div className="analytic_main">
                                    <div id="wrap">
                                        <div className="l_menu">
                                            <ul>
                                                <li>
                                                    <a href="javascript:void(0)"
                                                       onClick={this.lineChart.bind(this,this.state.month, "all",this.state.profile)}>All</a>
                                                </li>
                                                <li>
                                                    <a
                                                        href="javascript:void(0)"
                                                        onClick={this.lineChart.bind(this,this.state.month, "likes",this.state.profile)}
                                                        >Likes</a>
                                                </li>
                                                <li>
                                                    <a
                                                        href="javascript:void(0)"
                                                        onClick={this.lineChart.bind(this,this.state.month,"bookmarks",this.state.profile)}
                                                        >Bookmarks</a>
                                                </li>
                                                <li>
                                                    <a
                                                        href="javascript:void(0)"
                                                        onClick={this.lineChart.bind(this,this.state.month,"page_views",this.state.profile)}
                                                        >
                                                        Page Views
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="javascript:void(0)"
                                                       onClick={this.lineChart.bind(this,this.state.month,"gallery",this.state.profile)}>Gallery</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div className="anay_right">
                                            <div className="select_time">
                                                <select name='year' id='year'
                                                        value={this.state.month}
                                                        onChange={this.handleOptionChange.bind(this,'month')}>
                                                    <option value="1">January</option>
                                                    <option value="2">February</option>
                                                    <option value="3">March</option>
                                                    <option value="4">April</option>
                                                    <option value="5">May</option>
                                                    <option value="6">June</option>
                                                    <option value="7">July</option>
                                                    <option value="8">August</option>
                                                    <option value="9">September</option>
                                                    <option value="10">October</option>
                                                    <option value="11">November</option>
                                                    <option value="12">December</option>
                                                </select>
                                            </div>
                                            <div className="line_chart_ana">
                                                <Chart chartType="LineChart" rows={this.state.rows}
                                                       columns={this.state.columns} options={this.state.options}
                                                       graph_id="LineChart" width={"100%"} height={"400px"}
                                                       legend_toggle={true}/>

                                            </div>
                                            <div
                                                className="column_chart_ana"
                                                style={{marginLeft: 25, marginTop: 20}}>
                                                <div className="row">
                                                    <div className="col-sm-12 col-xs-12">
                                                        <h2>
                                                            Locations (Top 15 Cities)
                                                        </h2>
                                                        <Chart chartType="ComboChart" data={this.state.rows1}
                                                               options={this.state.option1} width={"100%"}
                                                               height={"400px"} legend_toggle={true}/>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </section>

        )
    }
}

Analytics.propTypes = {
    changeRoute: React.PropTypes.func,
};

function mapDispatchToProps(dispatch) {
    return {
        changeRoute: (url) => dispatch(push(url))
    };
}

export default connect(null,
    mapDispatchToProps)(Analytics);