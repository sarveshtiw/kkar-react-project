import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';


export class Testimonial extends React.Component {
    openRoute = (route) => {
        this.props.changeRoute(route);
    };

    render() {
      return (
          <div className="inner-page testimonialPage ">

          <div className="container ">
              <article
        id="post-80"
        className="post-80 page type-page status-publish hentry">

          <h1 className="entry-title"  style={{margin: '30px 0', width: '100%', textAlign: 'center',color:'rgb(208, 29, 21)'}}>Testimonials</h1>
        
        <div className="menu_cms">
        </div>
        <div className="entry-content">
          <p style={{textAlign: 'center'}}>
            <img
              style={{height: 150, width: 149}}

              src="http://kalakar.pro:90/kalakar/wp-content/uploads/2016/03/testi-monial-img.png"
              alt />
          </p>
          <p style={{textAlign: 'center'}}>
            <span style={{fontFamily: 'verdana,geneva,sans-serif'}}>
              <em>
                <span style={{color: '#222222', fontSize: '12.8px', backgroundColor: '#ffffff'}}>“</span>
              </em>
            </span>
            <em style={{fontFamily: 'verdana, geneva, sans-serif'}}>
              <span style={{color: '#222222', fontSize: '12.8px', backgroundColor: '#ffffff'}}>
                India being such a diverse pool of talent, a platform like&nbsp;
              </span>
              <span style={{color: '#d01d15'}}>
                <strong>
                  <a
                    style={{color: '#d01d15', fontFamily: 'arial, sans-serif', fontSize: '12.8px', backgroundColor: '#ffffff'}}
                    href="http://kalakar.pro/"
                    target="_blank"
                    rel="noreferrer">kalakar.pro</a>
                </strong>
              </span>
              <span style={{color: '#222222', fontSize: '12.8px', backgroundColor: '#ffffff'}}>
                &nbsp;is the need of the day. For me personally having an industry veteran like Mona leading it gives the assurance that&nbsp;
              </span>
              <span style={{color: '#d01d15'}}>
                <strong>
                  <a
                    style={{color: '#d01d15', fontFamily: 'arial, sans-serif', fontSize: '12.8px', backgroundColor: '#ffffff'}}
                    href="http://kalakar.pro/"
                    target="_blank"
                    rel="noreferrer">kalakar.pro</a>
                </strong>
              </span>
              <span style={{color: '#222222', fontSize: '12.8px', backgroundColor: '#ffffff'}}>
                &nbsp;is here to stay. I’m looking forward to seeing Kalakar.pro in its full version soon.”
              </span>
            </em>
          </p>
          <p style={{textAlign: 'center'}}>
            <em>
              <span style={{color: '#222222', fontFamily: 'arial, sans-serif', fontSize: '12.8px', backgroundColor: '#ffffff'}}>
                – Vidya Alva
              </span>
              <br />
              <span style={{color: '#222222', fontFamily: 'arial, sans-serif', fontSize: '12.8px', backgroundColor: '#ffffff'}}>
                Senior Vice President &amp; National Head – Events&nbsp;
              </span>
              <span style={{color: '#222222', fontFamily: 'arial, sans-serif', fontSize: '12.8px', backgroundColor: '#ffffff'}}>
                Percept ICE
              </span>
            </em>
          </p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p style={{textAlign: 'center'}}>
            <img
              style={{height: 150, width: 149}}
              src="http://kalakar.pro:90/kalakar/wp-content/uploads/2016/03/testi-monial-img-2.png"
              alt />
          </p>
          <p style={{textAlign: 'center'}}>
            <span style={{fontFamily: 'verdana,geneva,sans-serif'}}>
              <em>
                <span style={{color: '#222222', fontSize: '12.8px', backgroundColor: '#ffffff'}}>“</span>
              </em>
            </span>
            <em style={{fontFamily: 'verdana, geneva, sans-serif'}}>
              <span style={{color: '#222222', fontSize: '12.8px', backgroundColor: '#ffffff'}}>The biggest and most essential testimonial to <strong><span style={{color: '#d01d15'}}><a style={{color: '#d01d15'}} href="http://kalakar.pro">Kalakar.pro</a></span></strong> is that it is spearheaded by none other than Mona Irani… Mona has been a pioneer in this field and was the first ever casting agent that I ever heard of in our industry. Later, I realised, that her resources ran much beyond casting and that she was a powerhouse resource of the “Who Why What When Where” of many kinds! I have known her to be an immediate problem-solver and solution-giver and with this endeavour, Mona has channeled all her experience and knowledge into launching this powerhouse tool – <strong><span style={{color: '#d01d15'}}><a style={{color: '#d01d15'}} href="http://kalakar.pro" target="_blank">Kalakar.pro</a></span></strong>.</span>
            </em>
          </p>
          <p style={{textAlign: 'center'}}>
            <em style={{fontFamily: 'verdana, geneva, sans-serif'}}>
              <span style={{color: '#222222', fontSize: '12.8px', backgroundColor: '#ffffff'}}>
                <strong>
                  <span style={{color: '#d01d15'}}>Kalakar.pro</span>
                </strong> is a complete tool to get to the right people in front of, and behind, the camera. As a Director I shall definitely use this site to pinpoint and engage not just acting talent, but also technical talent for my films. It gives me, on a single platform, a variety of choices and constantly introduces me to new and upcoming talent. I would love to see Kalakar.pro expand and include all available talent from the country and around the world. I can also see more and more people accessing it over time and very soon this will be <span style={{color: '#d01d15'}}><strong>the</strong></span> one-stop-shop for any Foreign Production coming into the country.”
              </span>
            </em>
          </p>
          <p style={{textAlign: 'center'}}>
            <em>
              <span style={{color: '#222222', fontFamily: 'arial, sans-serif', fontSize: '12.8px', backgroundColor: '#ffffff'}}>
                –&nbsp;Leena Yadav, Director<br />
              Shivalaya Entertainment LLC, US and Ashlee Films, Mumbai
            </span>
          </em>
        </p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p style={{textAlign: 'center'}}>
          <img
            style={{height: 150, width: 149}}
            src="http://kalakar.pro:90/kalakar/wp-content/uploads/2016/03/testi-monial-img-3.png"
            alt />
        </p>
        <p style={{textAlign: 'center'}}>
          <span style={{fontFamily: 'verdana,geneva,sans-serif'}}>
            <em>
              <span style={{color: '#222222', fontSize: '12.8px', backgroundColor: '#ffffff'}}>“</span>
            </em>
          </span>
          <em style={{fontFamily: 'verdana, geneva, sans-serif'}}>
            <span style={{color: '#222222', fontSize: '12.8px', backgroundColor: '#ffffff'}}>
              In the entertainment and media industry, there has been a huge gap between the demand and immediate access to Talent; Talent from all facets of this industry. Kalakar is an absolute necessity because it is an essential data base and access point to the ever growing and ever increasing demand for Talent.
            </span>
          </em>
        </p>
        <p style={{textAlign: 'center'}}>
          <em style={{fontFamily: 'verdana, geneva, sans-serif'}}>
            <span style={{fontSize: '12.8px', backgroundColor: '#ffffff'}}>
              Kalakar’s USP is two words: “Mona Irani”. Mona comes with years of experience in the M&amp;E domain and an in-depth understanding of creativity, production, business and specific requirements of a content piece – be it film, advertising, digital, documentary, theatre, etc. I have worked with Mona, and it’s been a joy. Her professionalism, ethical practices and integrity coupled with the desire to treat every requirement as her own, makes it an unbeatable experience.
            </span>
          </em>
        </p>
        <p style={{textAlign: 'center'}}>
          <em style={{fontFamily: 'verdana, geneva, sans-serif'}}>
            <span style={{fontSize: '12.8px', backgroundColor: '#ffffff'}}>
              I am really happy that Kalakar, which is being spearheaded by Mona has been launched. It has suddenly made my life much easier and also for everyone else. I personally look forward to be able to use the platform for all my needs in all future projects.
            </span>
          </em>
        </p>

        <p style={{textAlign: 'center'}}>
          <em>
            <span style={{color: '#222222', fontFamily: 'arial, sans-serif', fontSize: '12.8px', backgroundColor: '#ffffff'}}>
              –&nbsp;Chhitra Subramaniam<br />
            Head of Company &amp; Vice President Wiz Films, Former Director Turner International ( Cartoon Network, POGO), Former Vice President Studio 18/ Viacom 18, Former Business Head Percept Picture Company, Former Head Of Production RGV The Factory
          </span>
        </em>
      </p>
      <p>&nbsp;</p>
    </div>
  </article>
          </div>
              </div>

                                )}
}
Testimonial.propTypes = {
    changeRoute: React.PropTypes.func,
};

function mapDispatchToProps(dispatch) {
    return {
        changeRoute: (url) => dispatch(push(url)),
    };
}

export default connect(null,
    mapDispatchToProps)(Testimonial);


