import React from 'react';
import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
var util = require('utils/request');
import cookie from 'react-cookie';

export class UploadVideo extends React.Component {
    openRoute = (route) => {
        this.props.changeRoute(route);
    };
    constructor(props) {
        super(props);
        this.state = {
            user_id:cookie.load('userId'),
            video_link:'',
            imgtgs:'',
            albumDetail:''
        }
    }

    handleInputChange(name, e) {
        var change = {};
        change[name] = e.target.value;
        this.setState(change);
        if(name == "video_link"){
            this. isDisabledWebsite();
        }
        if(name == "imgtgs"){
            this.validate1();
        }
    }
    addLink(){
        if(!(this.validate1()  && this.isDisabledWebsite())){
            this.validate1();
            this.isDisabledWebsite();
            return;
        }
        var userid = this.state.user_id;
        var videoLink=this.state.video_link;
        var imageTag=this.state.imgtgs;
        var param = {action: 'images',
            profile_id: this.props.profileId ,imgtgs:imageTag,
            video_link:videoLink.replace('watch?v=','embed/'),
            userId:userid,
            album: this.props.albumId };
        var formState = this;
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                formState.props.close();

               formState.props.detailAlbum();
                formState.setState({
                    video_link:'',
                    imgtgs:''

                })
            }

            }
        );

    }
    validateWebsite(value)
    {
        var exp =/(?:(?:http|https):\/\/)?(?:www\.)?(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))((\w|-){11})(?:\S+)?$/;;
        var exp1 =/https?:\/\/(?:www\.|player\.)?vimeo.com\/(?:channels\/(?:\w+\/)?|groups\/([^\/]*)\/videos\/|album\/(\d+)\/video\/|video\/|)(\d+)(?:$|\/|\?)/;
        if(exp.test(value))
        {
            return true;
        }
        else if( exp1.test(value))
        {
            return true;
        }
        else{
            return false;
        }

    }
    isDisabledWebsite() {
        let urlIsValid = false;
        if (this.state.video_link === "") {

            this.setState({
                website_error_text:"Please paste youtube or vimeo link"
            });
        } else {
            if (this.validateWebsite(this.state.video_link)) {
                urlIsValid = true;
                this.setState({
                    website_error_text: null
                });
            }
            else {
                this.setState({
                    website_error_text: "Please paste youtube or vimeo link"
                });
            }
        }
        return urlIsValid;
    }
    validate1() {
        let valid=false;
        if(this.state.imgtgs == ""){
            this.setState({
                error_text: "Please enter video tags"
            });
        } else {
            valid=true
            this.setState({
                error_text: null
            })

        }return valid;
    }

    render() {
        return (
            <Dialog
                autoDetectWindowHeight={true}
                modal={false}
                className="send_new_msg uploadVideoPopup"
                bodyStyle={{padding:'0px',  fontSize: '15px'}}
                open={this.props.open}
                autoScrollBodyContent={true}>
                <div>
                    <div className="send_content">
                        <div className="row">
                          <div className="col-xs-12"><span className="photouploader-header">Add Video</span></div>
                        </div>
                        <div className="row">
                            <div className="col-xs-12">
                                <label>Youtube or vimeo link*:</label>
                                <input type="text"  placeholder="Paste youtube or vimeo link"  className="input_form msg_profile"
                                       value={this.state.video_link}
                                       onChange={this.handleInputChange.bind(this,'video_link')}
                                       onBlur={this.isDisabledWebsite.bind(this,'video_link')}
                                    /><small className="errorMsg">{this.state.website_error_text}</small>

                            </div>
                        </div>

                        <div className="row">
                            <div className="col-xs-12">
                                <label>Video Tags*:</label>
                                <input type="text" placeholder="Tag this video, seperate tags by comma"
                                       className="input_form msg_profile"
                                       value={this.state.imgtgs}
                                       onChange={this.handleInputChange.bind(this,'imgtgs')}
                                       onBlur={this.validate1.bind(this,'imgtgs')}/>
                                <small className="errorMsg">{this.state.error_text}</small>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-xs-12">
                                <button type="button" className="send_btn uploadBtn"  onClick={this.addLink.bind(this)}>ADD Video</button>
                            </div>
                        </div>
                    </div>
                </div>
                <RaisedButton label="X" primary={true} className="cancelBtnPopup"
                              onTouchTap={this.props.close}/>
            </Dialog>

        )
    }







}
