import React from 'react';
import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
var util = require('utils/request');
import cookie from 'react-cookie';
import { API_URL } from 'containers/App/constants'

export class CircleMessages extends React.Component {
    openRoute = (route) => {
        this.props.changeRoute(route);
    };


    constructor(props) {
        super(props);
        this.state = {
            testimonial:'',
            blockmessage:'',
            message1:''
        }

    }

    componentDidMount() {

    }

    componentWillReceiveProps(nextProps) {
        var message_id = nextProps.messageid;

        var param = {action: 'circle_request_detail', message_id: message_id}
        var formState = this;
        util.getSetData(param, function (data) {

            if (data.status == "success") {
                formState.setState({
                    message_id: message_id,
                    sender_first_name: data.data.first_name,
                    sender_last_name: data.data.last_name,
                    first_name1: data.data.first_name1,
                    cat_name: data.data.cat_name,
                    ratings: (data.data.rating === null || data.data.rating === "" ||data.data.rating === undefined)?0:data.data.rating,
                    msg_count: data.data.msg_count,
                    city: data.data.city,
                    useful_msg_count: data.data.useful_msg_count,
                    my_user_id: data.data.sent_to,
                    sender_user_id: data.data.user_id,
                    id_circle:data.data.id_circle,
                    photo: data.data.photo,
                    posted_clas:data.data.posted_clas,
                    date:data.data.added_date
                });
            }
        });
    }
    handleInputChange( e) {
       this.setState({testimonial : e.target.value})

    }

    usefulMsg() {
        var param = {
            action: 'useful_msgs',
            message_id: this.state.message_id,
            user_id: this.state.my_user_id,
            useful_user_id: this.state.sender_user_id,
            useful_type: 'circle',
            status: 1
        }
        var formState = this;
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                formState.setState({message1:data.message});
                alert(formState.state.message1);
            }
        })
    }

    blockUser() {
        var param = {action: 'block_user', user_id: this.state.my_user_id, block_user_id: this.state.sender_user_id,}
        var formState = this;
        util.getSetData(param, function (data) {
            if (data.status == "success") {

                formState.setState({
                    blockmessage:data.message
                });
                alert(formState.state.blockmessage);
            }
        })
    }


    clear() {
        this.props.close();
    }


    postTestimonial(){
        var param = {action: 'post_testimonial', user_id: this.state.my_user_id,
            message_description:this.state.testimonial,id_circle:this.state.id_circle}
        var formState = this;
        util.getSetData(param, function (data) {

            if (data.status == "success") {
                formState.setState({
                    message:data.message
                });
                alert(formState.state.message);
                formState.state.circleMsg();
                formState.props.close();
            }
        })

    }



    render() {
        $('#incomingMsg3').mCustomScrollbar({
            setHeight: 270,
            theme: "dark-4"
        })

        $('#outgoingMsg').mCustomScrollbar({
            setHeight: 75,
            theme: "dark-4"
        })

        return (
            <Dialog
                autoDetectWindowHeight={true}
                modal={false}
                className="send_new_msg CircleOuter"
                titleClassName="send_head"
                bodyStyle={{padding:'0px',  fontSize: '15px'}}
                open={this.props.open}
                autoScrollBodyContent={true}>
                <div>
                    <div className="send_head">
                        <div className="row">
                            <div className="col-xs-12">
                                <h2>
                                    Circle Request
                                    From {this.state.sender_first_name + ' ' + this.state.sender_last_name}
                                    &nbsp;as&nbsp;
                                    {this.state.cat_name}
                                    <small className="Date">{this.state.date}</small>
                                </h2>
                            </div>
                        </div>
                    </div>
                    <div className="msgSec">
                        <div className="send_content leftSec">
                            <div className="row">
                                <div className="col-sm-12">
                                    <div id="incomingMsg3">
                                        <div contentEditable="false">
                                            <p>
                                                Dear {this.state.first_name1},
                                            </p>

                                            <p>
                                                {this.state.sender_first_name }&nbsp;says that he has worked with you and would request you to give a brief, attesting to his quality of work.
                                            </p>

                                            <p>
                                                Thank You,<br></br>
                                                Team Kalakar
                                            </p>

                                            <p>
                                                (PS: If {this.state.sender_first_name } has not worked with you or this request is unprofessional please mark it so.)
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-sm-12">
                                    <div id="outgoingMsg1">
                                       <textarea placeholder= {"Please Write Your Testimonial for "+this.state.sender_first_name + " here"}
                                                  onChange={this.handleInputChange.bind(this)}>
                                       </textarea>

                                    </div>
                                </div>
                                <div className="col-sm-12 rightAligh">
                                    <button  className="send_btn" onClick={this.postTestimonial.bind(this)} >
                                        Post Testimonial
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div className="rightSec">
                            <div className="proPic">
                                <img
                                    src={(this.state.photo === null ||this.state.photo === undefined
                                    ||this.state.photo === '')? require('./no-img-pro.png'):this.state.photo}
                                    width={183}
                                    height={104}
                                    alt/>
                            </div>
                            <h2>
                                {this.state.sender_first_name + ' ' + this.state.sender_last_name}
                            </h2>

                            <h3>
                                {this.state.cat_name}
                            </h3>

                            <p className="location">
                                <i className="fa fa-map-marker"/> {this.state.city}
                            </p>

                            <p className="rating">
                                <strong>{this.state.ratings}</strong>
                                <small>
                                    incred rating
                                </small>
                            </p>
                            <ul>
                                <li>
                                    Total Messages sent <em>{this.state.msg_count}</em>
                                </li>
                                <li>
                                    Professionally useful Messages <em>{this.state.useful_msg_count}</em>
                                </li>
                                <li>
                                    Total Classfieds Posted <em>{this.state.posted_clas}</em>
                                </li>
                            </ul>
                            <div className="helpMsg">
                                <p>
                                    Was this Message<br /> Professionally useful
                                </p>
                                <button className="btn green small" onClick={this.usefulMsg.bind(this)}>Yes</button>
                                <button className="btn red small">No</button>
                                <button className="btn grey big" onClick={this.blockUser.bind(this)}>
                                    <i className="fa fa-ban"/> Blacklist this user
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <RaisedButton label="X" primary={true} className="cancelBtnPopup"
                              onTouchTap={this.clear.bind(this)}/>

            </Dialog>)

    }
}
