/**
* A link to a certain page, an anchor tag
*/
import React from 'react';
import RaisedButton from 'material-ui/RaisedButton';

export class DashboardEditProfile extends React.Component {
    constructor(props) {
        super(props);
        this.state =
        {
            pageLoader:true
        }
    }
    componentDidUpdate(){$('.pageloader').remove();}
  componentDidMount() {
    $(".dash_profileItem").owlCarousel({
      items : 5,
      loop:true,
      nav:true,
      autoplayTimeout:3000,
      autoplaySpeed: 1000,
      autoplay:false,
      responsive:{ 0:{items:1}, 480:{items:2},  600:{items:3}, 768:{items:4}, 1000:{items:5}}
      });
}



render() {
return <div>
    <div className="pageloader"><img src="http://kalakar.pro:90/kalakar/demo/other/assets/img/loader.svg"/></div>
     <div className="item">
     <a href={"/my-accounts/extended-profile/"+this.props.profile_id+"/basic"}>
               <div className="item_inner">
                   <span className="edit_p_img">
                      <img src={this.props.bigimage}/>
                   </span>
                   <h3>{this.props.category}</h3>
                      <span className="small_images">
                        <ul>
                           {this.props.smallimages.map(function(object, i){
                                return <li key={i}><img src={object.location} alt=""/></li>
                           })}
                         </ul>
                     </span>
               </div>

           </a>
       </div>

  </div>;
 }
}
