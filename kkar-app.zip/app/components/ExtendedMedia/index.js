import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import {ProfileView} from 'components/ProfileView';
var util = require('utils/request');
import Dialog from 'material-ui/Dialog';
import RaisedButton from 'material-ui/RaisedButton';
import cookie from 'react-cookie';
import Img from 'components/Img';
var iframeStyle = {
    height: "140px",
    width: "100%",
    position: "absolute",
    zIndex: 1
};
var photoFlag = false, videoFlag = false, albumFlag = false;
export class ExtendedMedia extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            videodata: [],
            photodata: [],
            albumdata: [],
            album_details: [],
            openWhatsApp: false,
            pageLoader: true,
            user_id: cookie.load('userId'),
        }
    }

    componentDidUpdate() {
        $('.pageloader').remove();
    }

    componentDidMount() {
        jQuery('.dashboard_rating .rating_left ul li .rating_progress > .progress').click(function () {
            if (jQuery(this).siblings(".sub_rating").hasClass('open')) {
                jQuery('.dashboard_rating .rating_left ul li .rating_progress .progress').siblings(".sub_rating").removeClass('open');
                jQuery('.dashboard_rating .rating_left ul li .rating_progress .progress').siblings(".rating_count").hide();
                jQuery('.dashboard_rating .rating_left ul li .rating_progress .progress').children(".progress-bar").children("span").hide();
            }
            else {
                jQuery('.dashboard_rating .rating_left ul li .rating_progress .progress').siblings(".sub_rating").removeClass('open');
                jQuery('.dashboard_rating .rating_left ul li .rating_progress .progress').siblings(".rating_count").hide();
                jQuery('.dashboard_rating .rating_left ul li .rating_progress .progress').children(".progress-bar").children("span").hide();
                jQuery(this).siblings(".sub_rating").addClass('open');
                jQuery(this).siblings(".rating_count").show();
                jQuery(this).children(".progress-bar").children("span").show();
            }
        });

        var param = {action: 'videos_list', profile_id: this.props.profileId}
        var formState = this;
        util.getSetData(param, function (data) {
            videoFlag = true;
            if (data.status == "success") {
                if (data.data != null) {
                    formState.setState({
                        videodata: data.data
                    });
                    $(".profile_info_right .demo-gallery, .profile_info_right .dashboard_rating").mCustomScrollbar({
                        snapAmount: 40,
                        scrollButtons: {enable: true},
                        keyboard: {scrollAmount: 40},
                        mouseWheel: {deltaFactor: 40},
                        scrollInertia: 400,
                        setHeight: 468
                    });

                }
            }

        });
        var param = {action: 'get_photos', profile_id: this.props.profileId}
        var formState = this;
        util.getSetData(param, function (data) {
            photoFlag = true;
            if (data.status == "success") {
                if (data.data != null) {
                    formState.setState({
                        photodata: data.data
                    });
                    $(".profile_info_right .demo-gallery, .profile_info_right .dashboard_rating").mCustomScrollbar({
                        snapAmount: 40,
                        scrollButtons: {enable: true},
                        keyboard: {scrollAmount: 40},
                        mouseWheel: {deltaFactor: 40},
                        scrollInertia: 400,
                        setHeight: 468
                    });
                }
            }
        });
        var param = {action: 'get_albums', profile_id: this.props.profileId}
        var formState = this;
        util.getSetData(param, function (data) {
            albumFlag = true;
            if (data.status == "success") {
                if (data.data != null) {

                    formState.setState
                    ({
                        albumdata: data.data
                    });


                }
            }
        });
        var param = {action: 'total_ratings', profile_id: this.props.profileId}
        var formState = this;
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                if (data.data != null) {
                    formState.setState({
                        rating: (data.data.ratings == undefined ||data.data.ratings == null ||data.data.ratings == ''||data.data.ratings == '0')?0:data.data.ratings
                    })
                }
            }
        });

        var param = {action: 'detail_ratings', profile_id: this.props.profileId}
        var formState = this;
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                if (data.data != null) {
                    formState.setState({
                        profile_ratings: (data.data.details.Gh_Profile == null) ? 0 : parseFloat(data.data.details.Gh_Profile),
                        workcred_rating: (data.data.details.Gh_Workcred == null) ? 0 : parseFloat(data.data.details.Gh_Workcred),
                        messages_rating: (data.data.details.Gh_Messages == null) ? 0 : parseFloat(data.data.details.Gh_Messages),
                        bookmarks_rating: (data.data.details.Gh_Bookmark == null) ? 0 : parseFloat(data.data.details.Gh_Bookmark),
                        calendar_rating: (data.data.details.Gh_Calendar == null) ? 0 : parseFloat(data.data.details.Gh_Calendar),
                        likes_rating: (data.data.details.Gh_Likes == null) ? 0 : parseFloat(data.data.details.Gh_Likes),
                        awards_rating: (data.data.details.Gh_Awards == null) ? 0 : parseFloat(data.data.details.Gh_Awards),
                        about_Profile: (data.data.Gh_Profile.Gh_about_us == null) ? 0 : parseFloat(data.data.Gh_Profile.Gh_about_us),
                        photo_Profile: (data.data.Gh_Profile.Gh_photos == null) ? 0 : parseFloat(data.data.Gh_Profile.Gh_photos),
                        training_Profile: (data.data.Gh_Profile.Gh_Training == null) ? 0 : parseFloat(data.data.Gh_Profile.Gh_Training),
                        tags_Profile: (data.data.Gh_Profile.Gh_Tags == null) ? 0 : parseFloat(data.data.Gh_Profile.Gh_Tags),
                        links_Profile: (data.data.Gh_Profile.Gh_Links == null) ? 0 : parseFloat(data.data.Gh_Profile.Gh_Links),
                        list_workcred: (data.data.Gh_Workcred.Gh_workcred_listed == null) ? 0 : parseFloat(data.data.Gh_Workcred.Gh_workcred_listed),
                        media_workcred: (data.data.Gh_Workcred.Gh_workcred_media == null) ? 0 : parseFloat(data.data.Gh_Workcred.Gh_workcred_media),
                        uniq_messages: (data.data.Gh_Messages.Gh_uniq_Messages == null) ? 0 : parseFloat(data.data.Gh_Messages.Gh_uniq_Messages),
                        messages_2hr: (data.data.Gh_Messages.Gh_reply_messages_2hr == null) ? 0 : parseFloat(data.data.Gh_Messages.Gh_reply_messages_2hr),
                        messages_3days: (data.data.Gh_Messages.Gh_reply_messages_3days == null) ? 0 : parseFloat(data.data.Gh_Messages.Gh_reply_messages_3days),
                        bookmarks: (data.data.Gh_Bookmark.gh_peer_bookmarks == null) ? 0 : parseFloat(data.data.Gh_Bookmark.gh_peer_bookmarks),
                        calendar_morethen30: (data.data.Gh_Calendar.Gh_calendar_morethen30 == null) ? 0 : parseFloat(data.data.Gh_Calendar.Gh_calendar_morethen30),
                        calendar_atleast30: (data.data.Gh_Calendar.Gh_calendar_atleast30 == null) ? 0 : parseFloat(data.data.Gh_Calendar.Gh_calendar_atleast30),
                        calendar_atleast20: (data.data.Gh_Calendar.Gh_calendar_atleast20 == null) ? 0 : parseFloat(data.data.Gh_Calendar.Gh_calendar_atleast20),
                        calendar_atleast10: (data.data.Gh_Calendar.Gh_calendar_atleast10 == null) ? 0 : parseFloat(data.data.Gh_Calendar.Gh_calendar_atleast10),
                        awards_listed: (data.data.Gh_Awards.Gh_awards_listed == null) ? 0 : parseFloat(data.data.Gh_Awards.Gh_awards_listed),
                        awards_media: (data.data.Gh_Awards.Gh_awards_media == null) ? 0 : parseFloat(data.data.Gh_Awards.Gh_awards_media),
                        likesPeers: (data.data.Gh_Likes["Likes by peers (same profession, basically sub-category)"] == null) ? 0 : parseFloat(data.data.Gh_Likes["Likes by peers (same profession, basically sub-category)"]),
                        likes_others: (data.data.Gh_Likes["Likes by other incred users"] == null) ? 0 : parseFloat(data.data.Gh_Likes["Likes by other incred users"])
                    })
                }

            }
            var pieData1 = [
                {
                    value: 14,
                    color: "#e0e0e0"

                },
                {
                    value: 14,
                    color:"#e0e0e0"

                },

                {
                    value: 14,
                    color: "#e0e0e0"
                },
                {
                    value: 14,
                    color: "#e0e0e0"
                },
                {
                    value: 14,
                    color:"#e0e0e0"
                },
                {
                    value: 14,
                    color: "#e0e0e0"
                },
                {
                    value: 14,
                    color: "#e0e0e0"
                }
            ]

            var pieData = [

                {
                    value: (formState.state.profile_ratings < 0 ) ? 0 : formState.state.profile_ratings,
                    color: "#bc3c6d",

                },
                {
                    value: (formState.state.workcred_rating < 0) ? 0 : formState.state.workcred_rating,
                    color: "#feb528",

                },

                {
                    value: (formState.state.messages_rating < 0) ? 0 : formState.state.messages_rating,
                    color: "#57a695"
                },
                {
                    value: (formState.state.likes_rating < 0) ? 0 : formState.state.likes_rating,
                    color: "#ed6f47"
                },
                {
                    value: (formState.state.awards_rating < 0) ? 0 : formState.state.awards_rating,
                    color: "#feb528"
                },
                {
                    value: (formState.state.calendar_rating < 0) ? 0 : formState.state.calendar_rating,
                    color: "#0098da"
                },
                {
                    value: (formState.state.bookmarks_rating < 0) ? 0 : formState.state.bookmarks_rating,
                    color: "#a8cf45"
                },

            ]
            if(formState.state.rating == 0){
                var myPie = new Chart(document.getElementById("canvas").getContext("2d")).Doughnut(pieData1,{percentageInnerCutout : 60,animateRotate:false,segmentShowStroke:true});
            }else {
                var myPie = new Chart(document.getElementById("canvas").getContext("2d")).Doughnut(pieData,{percentageInnerCutout : 60});
            }

        });

    }

    handleWhatAppOpen = () => {
        this.setState({openWhatsApp: true});
    };

    handleWhatAppClose = () => {
        this.setState({openWhatsApp: false});
    };

    render() {
        var local = this;

        jQuery('#lightgallery').lightGallery();
        jQuery('.lightgallery-single-image').lightGallery();
        jQuery('.lightgallery-single-video').lightGallery();
        jQuery('.videos-for-album').lightGallery();
        jQuery('#videos-without-poster').lightGallery();
        jQuery('#videos-without-poster2').lightGallery();
        jQuery('#videos-without-poster3').lightGallery();
        jQuery('.album_box_tabcontainer').find('.album_box').children('a').click(function () {
            jQuery(this).siblings('.demo-gallery').children('ul').children('li').first().children('a').trigger('click');
        });

        return (

            <div className="col-lg-6">
                <div className="pageloader"><img src="http://kalakar.pro:90/kalakar/demo/other/assets/img/loader.svg"/>
                </div>
                <div className="profile_info_right">
                    <div className="profileinfomenu">
                        <ul className="nav nav-tabs" role="tablist">
                            <li role="presentation" className="active">
                                <a style={this.props.style}
                                   href="#photos"
                                   aria-controls="photos"
                                   role="tab"
                                   data-toggle="tab">photos</a>
                            </li>
                            <li role="presentation">
                                <a style={this.props.style}
                                   href="#videos"
                                   aria-controls="videos"
                                   role="tab"
                                   data-toggle="tab">videos</a>
                            </li>
                            <li role="presentation">
                                <a style={this.props.style}
                                   href="#albums"
                                   aria-controls="albums"
                                   role="tab"
                                   data-toggle="tab">albums</a>
                            </li>
                            <li role="presentation">
                                <a style={this.props.style}
                                   href="#incredrating"
                                   aria-controls="incredrating"
                                   role="tab"
                                   data-toggle="tab">
                                    Incred
                                    Rating
                                </a>
                            </li>
                            <li role="presentation">
                                <a style={this.props.style}
                                   href="#social"
                                   aria-controls="social"
                                   role="tab"
                                   data-toggle="tab">Social</a>
                            </li>
                        </ul>
                    </div>
                    <div className="tab-content">
                        {local.state.photodata.length > 0 &&
                        <div
                            role="tabpanel"
                            className="tab-pane active"
                            id="photos">
                            <div className="demo-gallery">
                                <ul id="lightgallery" className="list-unstyled row">
                                    {local.state.photodata.map(p =>
                                        <li
                                            key={p.photo_id}
                                            className
                                            data-src={p.photo_loc}
                                            data-sub-html={"<p>" + p.photo_tag +"</p>"}>
                                            <a href="#">
                                                <img
                                                    src={(p.photo_loc2 ==='' || p.photo_loc2 === undefined || p.photo_loc2 === null)?
                                                    (p.photo_loc ==='' || p.photo_loc === undefined || p.photo_loc === null) ? require('./no-img-pro.png'): p.photo_loc :  p.photo_loc2}/>

                                            </a>
                                        </li>)}

                                </ul>
                            </div>
                        </div>}
                        {
                            local.state.photodata.length == 0 && photoFlag == false &&

                            <div className="Divloader"><img
                                src="http://kalakar.pro:90/kalakar/demo/other/assets/img/loader.svg"/></div>
                        }
                        {local.state.photodata.length == 0 && photoFlag == true &&
                        <div
                            role="tabpanel"
                            className="tab-pane active"
                            id="photos">
                            <div className="demo-gallery">
                                No Photos Defined
                            </div>
                        </div>}


                        {local.state.videodata.length > 0 &&
                        <div role="tabpanel" className="tab-pane" id="videos">
                            <div className="demo-gallery videos">
                                {(this.state.user_id === undefined || this.state.user_id === "" || this.state.user_id === null)
                                &&
                                <ul id="videos-without-poster3">

                                    <li className="video"  data-src="https://www.youtube.com/watch?v=2dprw9dBSBA&feature=youtu.be"
                                        data-sub-html="<h4></h4>">
                                        <a href>
                                            <iframe  width="100%" height="210px" src="https://www.youtube.com/embed/2dprw9dBSBA" frameborder="0" allowfullscreen></iframe>

                                            <div className="demo-gallery-poster"/>
                                        </a>
                                    </li>


                                </ul>}
                                <ul id="videos-without-poster2">
                                    {local.state.videodata.map(v =>
                                        <li className="video" key={v.video_id} data-src={v.videolink}
                                            data-sub-html="<h4></h4>">
                                            <a href>
                                                <iframe width="100%" height="210px" src={v.videolink} frameBorder={0}
                                                        allowFullScreen/>
                                                <div className="demo-gallery-poster"/>
                                            </a>
                                        </li>)}


                                </ul>

                            </div>
                        </div>}
                        {
                            local.state.videodata.length == 0 && videoFlag == false &&

                            <div className="Divloader"><img
                                src="http://kalakar.pro:90/kalakar/demo/other/assets/img/loader.svg"/></div>
                        }
                        {local.state.videodata.length == 0 && videoFlag == true &&
                        <div role="tabpanel" className="tab-pane" id="videos">
                            <div className="demo-gallery videos">
                                No Videos Defined
                            </div>
                        </div>}

                        {local.state.albumdata.length > 0 &&
                        <div role="tabpanel" className="tab-pane" id="albums">
                            <div className="album_box_tabcontainer">

                                {local.state.albumdata.map(a =>
                                    <div key={a.album_id}>
                                        {a.album_details !== undefined && a.album_details[0] &&
                                        <div className="album_box">
                                            <a href="javascript:void(0);" className="box_album ims">
                                                { a.album_details[0].type === "video" &&
                                                <iframe width="100%" height="108px" src={a.album_details[0].location}
                                                        frameBorder="0" allowFullScreen>
                                                </iframe>
                                                }
                                                { a.album_details[0].type === "image" &&
                                                <img src={a.album_details[0].location} className="mCS_img_loaded"/>}
                                                <span className="albums_title">{a.album_name} </span>

                                                <div className="play_btn_album"></div>
                                            </a>

                                            <div className="demo-gallery dark mrb35" style={{display: 'none'}}>
                                                <ul className="list-unstyled row videos-for-album">
                                                    {a.album_details.map(b =>
                                                            <li key={b.location} className="video" data-src={b.location}
                                                                data-sub-html={"<h4>" + b.tag +"</h4>"}>
                                                                <a href className="click_inner">
                                                                    <img className="img-responsive mCS_img_loaded"
                                                                         src={b.location}/>
                                                                    <span className="albums_title">{b.tag} </span>

                                                                    <div className="demo-gallery-poster"></div>
                                                                </a>
                                                            </li>
                                                    )}
                                                </ul>
                                            </div>
                                        </div>}
                                    </div>)
                                }
                            </div>
                        </div>}
                        {
                            local.state.albumdata.length == 0 && albumFlag == false &&

                            <div className="Divloader"><img
                                src="http://kalakar.pro:90/kalakar/demo/other/assets/img/loader.svg"/></div>
                        }
                        { local.state.albumdata.length == 0 && albumFlag == true &&
                        <div role="tabpanel" className="tab-pane" id="albums">
                            <div className="album_box_tabcontainer">
                                No Albums Defined
                            </div>
                        </div>
                        }

                        <div
                            role="tabpanel"
                            className="tab-pane inc_rating"
                            id="incredrating">
                            <div className="dashboard_rating">
                                <div className="rating_right">
                                    <canvas id="canvas" height={210} width={210} className="round_rating"/>
                                    <div className="total_round_rating">
                                        Total Incred<br />Rating<span>{this.state.rating}</span>
                                    </div>
                                </div>

                                <div className="rating_left">
                                    <ul>
                                        <li>
                                            <span className="rating_name">Profile</span>
                        <span className="rating_progress">
                          <div className="progress progress_sm">
                              <div className="progress-bar bg-profile" role="progressbar" data-transitiongoal={100}
                                   style={{width: (this.state.profile_ratings/12*100)+'%'}}>
                                  <span>  {this.state.profile_ratings}  </span>
                              </div>
                          </div>
                          <span className="rating_count">  12 max</span>
                          <div className="sub_rating">
                              <ul>
                                  <li>
                                <span className="left_sub_rating">
                                  <p>About has 100-200words 2pts </p>
                                  <div className="progress">
                                      <div className="progress-bar bg-profile" role="progressbar"
                                           aria-valuenow={60}
                                           aria-valuemin={0}
                                           aria-valuemax={100}
                                           style={{width: (this.state.about_Profile/2*100)+'%'}}/>
                                  </div>
                                </span>
                                <span className="sub_rating_total">
                                  {this.state.about_Profile} PTS
                                </span>
                                  </li>
                                  <li>
                                <span className="left_sub_rating">
                                  <p>Photos minimum 10 uploaded 3pts </p>
                                  <div className="progress">
                                      <div
                                          className="progress-bar bg-profile"
                                          role="progressbar"
                                          aria-valuenow={60}
                                          aria-valuemin={0}
                                          aria-valuemax={100}
                                          style={{width: (this.state.photo_Profile/3*100)+'%'}}/>
                                  </div>
                                </span>
                                <span className="sub_rating_total">
                                  {this.state.photo_Profile} PTS
                                </span>
                                  </li>
                                  <li>
                                <span className="left_sub_rating">
                                  <p>
                                      Training – 1 minimum – 3pts
                                  </p>
                                  <div className="progress">
                                      <div
                                          className="progress-bar bg-profile"
                                          role="progressbar"
                                          aria-valuenow={60}
                                          aria-valuemin={0}
                                          aria-valuemax={100}
                                          style={{width: (this.state.training_Profile/3*100)+'%'}}/>
                                  </div>
                                </span>
                                <span className="sub_rating_total">
                                  {this.state.training_Profile}PTS
                                </span>
                                  </li>
                                  <li>
                                <span className="left_sub_rating">
                                  <p>Tags 7 minimum – 2pt </p>
                                  <div className="progress">
                                      <div
                                          className="progress-bar bg-profile"
                                          role="progressbar"
                                          aria-valuenow={60}
                                          aria-valuemin={0}
                                          aria-valuemax={100}
                                          style={{width: (this.state.tags_Profile/3*100)+'%'}}/>
                                  </div>
                                </span>
                                <span className="sub_rating_total">
                                  {this.state.tags_Profile} PTS
                                </span>
                                  </li>
                                  <li>
                                <span className="left_sub_rating">
                                  <p>Links 2 minimum – 2pts </p>
                                  <div className="progress">
                                      <div
                                          className="progress-bar bg-profile"
                                          role="progressbar"
                                          aria-valuenow={60}
                                          aria-valuemin={0}
                                          aria-valuemax={100}
                                          style={{width: (this.state.links_Profile/2*100)+'%'}}/>
                                  </div>
                                </span>
                                <span className="sub_rating_total">
                                  {this.state.links_Profile} PTS
                                </span>
                                  </li>
                              </ul>
                          </div>
                        </span>
                                        </li>
                                        <li>
                                            <span className="rating_name">Workcred</span>
                        <span className="rating_progress">

                          <div className="progress progress_sm">
                              <div
                                  className="progress-bar bg-workcred"
                                  role="progressbar"
                                  data-transitiongoal={100}
                                  style={{width: (this.state.workcred_rating/12*100)+'%'}}>
                              <span>
                                {this.state.workcred_rating}
                              </span>
                              </div>
                          </div>
                          <span className="rating_count">
                            12 max
                          </span>
                          <div className="sub_rating">
                              <ul>
                                  <li>
                                <span className="left_sub_rating">
                                  <p>Workcred min 5 Projects 2pts </p>
                                  <div className="progress">
                                      <div
                                          className="progress-bar bg-workcred"
                                          role="progressbar"
                                          aria-valuenow={60}
                                          aria-valuemin={0}
                                          aria-valuemax={100}
                                          style={{width: (this.state.list_workcred/2*100)+'%'}}/>
                                  </div>
                                </span>
                                <span className="sub_rating_total">
                                  {this.state.list_workcred}PTS
                                </span>
                                  </li>
                                  <li>
                                <span className="left_sub_rating">
                                  <p>2 pts per media added </p>
                                  <div className="progress">
                                      <div
                                          className="progress-bar bg-workcred"
                                          role="progressbar"
                                          aria-valuenow={60}
                                          aria-valuemin={0}
                                          aria-valuemax={100}
                                          style={{width:((this.state.media_workcred)/5*100)+'%'}}/>
                                  </div>
                                </span>
                                <span className="sub_rating_total">
                                  {this.state.media_workcred}PTS
                                </span>
                                  </li>
                              </ul>
                          </div>
                        </span>
                                        </li>
                                        <li>
                                            <span className="rating_name">Messages</span>
                        <span className="rating_progress">
                          <div className="progress progress_sm">
                              <div
                                  className="progress-bar bg-messages"
                                  role="progressbar"
                                  data-transitiongoal="18.5"
                                  style={{width: (this.state.messages_rating/10*100)+'%'}}>
                              <span>
                                {this.state.messages_rating}
                              </span>
                              </div>
                          </div>
                          <span className="rating_count">
                            10 max
                          </span>
                          <div className="sub_rating">
                              <ul>
                                  <li>
                                <span className="left_sub_rating">
                                  <p>Users 0.25 per unique message </p>
                                  <div className="progress">
                                      <div
                                          className="progress-bar bg-messages"
                                          role="progressbar"
                                          aria-valuenow={60}
                                          aria-valuemin={0}
                                          aria-valuemax={100}
                                          style={{width: (this.state.uniq_messages/3.3*100)+ '%'}}/>
                                  </div>
                                </span>
                                <span className="sub_rating_total">
                                  {this.state.uniq_messages} PTS
                                </span>
                                  </li>
                                  <li>
                                <span className="left_sub_rating">
                                  <p>0.5 for a reply within two hrs </p>
                                  <div className="progress">
                                      <div
                                          className="progress-bar bg-messages"
                                          role="progressbar"
                                          aria-valuenow={60}
                                          aria-valuemin={0}
                                          aria-valuemax={100}
                                          style={{width: (this.state.messages_2hr/3.3*100)+ '%'}}/>
                                  </div>
                                </span>
                                <span className="sub_rating_total">
                                  {this.state.messages_2hr} PTS
                                </span>
                                  </li>
                                  <li>
                                <span className="left_sub_rating">
                                  <p>
                                      0.05 for a reply within three days
                                  </p>
                                  <div className="progress">
                                      <div
                                          className="progress-bar bg-messages"
                                          role="progressbar"
                                          aria-valuenow={60}
                                          aria-valuemin={0}
                                          aria-valuemax={100}
                                          style={{width: (this.state.messages_3days/3.3*100)+ '%'}}/>
                                  </div>
                                </span>
                                <span className="sub_rating_total">
                                  {this.state.messages_3days} PTS
                                </span>
                                  </li>
                              </ul>
                          </div>
                        </span>
                                        </li>
                                        <li>
                                            <span className="rating_name">Bookmarks</span>
                        <span className="rating_progress">
                          <div className="progress progress_sm">
                              <div
                                  className="progress-bar bg-bookmarks"
                                  role="progressbar"
                                  data-transitiongoal={9}
                                  style={{width:  (this.state.bookmarks_rating/10*100)+'%'}}>
                              <span>
                                {this.state.bookmarks_rating}
                              </span>
                              </div>
                          </div>
                          <span className="rating_count">
                            10 max
                          </span>
                          <div className="sub_rating">
                              <ul>
                                  <li>
                                <span className="left_sub_rating">
                                  <p>Linked to rating of the marking person (30% rating give you 0.3 bump) </p>
                                  <div className="progress">
                                      <div
                                          className="progress-bar bg-bookmarks"
                                          role="progressbar"
                                          aria-valuenow={60}
                                          aria-valuemin={0}
                                          aria-valuemax={100}
                                          style={{width: (this.state.bookmarks/10*100)+ '%'}}/>
                                  </div>
                                </span>
                                <span className="sub_rating_total">
                                  {this.state.bookmarks} PTS
                                </span>
                                  </li>
                              </ul>
                          </div>
                        </span>
                                        </li>
                                        <li>
                                            <span className="rating_name">Calendar</span>
                        <span className="rating_progress">
                          <div className="progress progress_sm">
                              <div
                                  className="progress-bar bg-calendar"
                                  role="progressbar"
                                  data-transitiongoal={100}
                                  style={{width:(this.state.calendar_rating/10*100)+'%'}}>
                              <span>
                                {this.state.calendar_rating}
                              </span>
                              </div>
                          </div>
                          <span className="rating_count">
                            10 max
                          </span>
                          <div className="sub_rating">
                              <ul>
                                  <li>
                                <span className="left_sub_rating">
                                  <p>More than 30% of days in the last 90 days - 10pts </p>
                                  <div className="progress">
                                      <div
                                          className="progress-bar bg-calendar"
                                          role="progressbar"
                                          aria-valuenow={60}
                                          aria-valuemin={0}
                                          aria-valuemax={100}
                                          style={{width: (this.state.calendar_morethen30/2.5*100)}}/>
                                  </div>
                                </span>
                                <span className="sub_rating_total">
                                  {this.state.calendar_morethen30} PTS
                                </span>
                                  </li>
                                  <li>
                                <span className="left_sub_rating">
                                  <p>at least 30% of days in the last 90 days 8pts </p>
                                  <div className="progress">
                                      <div
                                          className="progress-bar bg-calendar"
                                          role="progressbar"
                                          aria-valuenow={60}
                                          aria-valuemin={0}
                                          aria-valuemax={100}
                                          style={{width: (this.state.calendar_atleast30/2.5*100)}}/>
                                  </div>
                                </span>
                                <span className="sub_rating_total">
                                  {this.state.calendar_atleast30} PTS
                                </span>
                                  </li>
                                  <li>
                                <span className="left_sub_rating">
                                  <p>at least 20% of days in the last 90 days 5 pts </p>
                                  <div className="progress">
                                      <div
                                          className="progress-bar bg-calendar"
                                          role="progressbar"
                                          aria-valuenow={60}
                                          aria-valuemin={0}
                                          aria-valuemax={100}
                                          style={{width: (this.state.calendar_atleast20/2.5*100)}}/>
                                  </div>
                                </span>
                                <span className="sub_rating_total">
                                  {this.state.calendar_atleast20} PTS
                                </span>
                                  </li>
                                  <li>
                                <span className="left_sub_rating">
                                  <p>at least 10% of days in the last 90 days 2 pts </p>
                                  <div className="progress">
                                      <div
                                          className="progress-bar bg-calendar"
                                          role="progressbar"
                                          aria-valuenow={60}
                                          aria-valuemin={0}
                                          aria-valuemax={100}
                                          style={{width: (this.state.calendar_atleast10/2.5*100)}}/>
                                  </div>
                                </span>
                                <span className="sub_rating_total">
                                  {this.state.calendar_atleast10} PTS
                                </span>
                                  </li>
                              </ul>
                          </div>
                        </span>
                                        </li>
                                        <li>
                                            <span className="rating_name">Likes</span>
                        <span className="rating_progress">
                          <div className="progress progress_sm">
                              <div
                                  className="progress-bar bg-likes"
                                  role="progressbar"
                                  data-transitiongoal={100}
                                  style={{width:  (this.state.likes_rating/10*100)+'%'}}>
                              <span>
                                  {this.state.likes_rating}
                              </span>
                              </div>
                          </div>
                          <span className="rating_count">
                            10 max
                          </span>
                          <div className="sub_rating">
                              <ul>
                                  <li>
                                <span className="left_sub_rating">
                                  <p>
                                      Likes by peers (same profession, basically sub-category) 6pts
                                  </p>
                                  <div className="progress">
                                      <div
                                          className="progress-bar bg-likes"
                                          role="progressbar"
                                          aria-valuenow={60}
                                          aria-valuemin={0}
                                          aria-valuemax={100}
                                          style={{width: '0%'}}/>
                                  </div>
                                </span>
                                <span className="sub_rating_total">
                                  {this.state.likesPeers} PTS
                                </span>
                                  </li>
                                  <li>
                                <span className="left_sub_rating">
                                  <p>Likes by other incred users 4pts </p>
                                  <div className="progress">
                                      <div
                                          className="progress-bar bg-likes"
                                          role="progressbar"
                                          aria-valuenow={60}
                                          aria-valuemin={0}
                                          aria-valuemax={100}
                                          style={{width: '4.00%'}}/>
                                  </div>
                                </span>
                                <span className="sub_rating_total">
                                  {this.state.likes_others} PTS
                                </span>
                                  </li>
                              </ul>
                          </div>
                        </span>
                                        </li>
                                        <li>
                                            <span className="rating_name">Awards</span>
                        <span className="rating_progress">
                          <div className="progress progress_sm">
                              <div
                                  className="progress-bar bg-workcred"
                                  role="progressbar"
                                  data-transitiongoal={100}
                                  style={{width: (this.state.awards_rating/10*100)+'%'}}>
                              <span>
                                {this.state.awards_rating}
                              </span>
                              </div>
                          </div>
                          <span className="rating_count">
                            10 max
                          </span>
                          <div className="sub_rating">
                              <ul>
                                  <li>
                                <span className="left_sub_rating">
                                  <p>Every listed award. 0.5pts </p>
                                  <div className="progress">
                                      <div
                                          className="progress-bar bg-workcred"
                                          role="progressbar"
                                          aria-valuenow={60}
                                          aria-valuemin={0}
                                          aria-valuemax={100}
                                          style={{width: '2.00%'}}/>
                                  </div>
                                </span>
                                <span className="sub_rating_total">
                                  {this.state.awards_listed} PTS
                                </span>
                                  </li>
                                  <li>
                                <span className="left_sub_rating">
                                  <p>2 pts per media added In awards </p>
                                  <div className="progress">
                                      <div
                                          className="progress-bar bg-workcred"
                                          role="progressbar"
                                          aria-valuenow={60}
                                          aria-valuemin={0}
                                          aria-valuemax={100}
                                          style={{width: '8.00%'}}/>
                                  </div>
                                </span>
                                <span className="sub_rating_total">
                                  {this.state.awards_media} PTS
                                </span>
                                  </li>
                              </ul>
                          </div>
                        </span>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            {/* End of rating profile */}
                        </div>
                        {local.props.social.facebook_link === '' && local.props.social.twitter_link === '' && local.props.social.wordpress_link === ''
                        && local.props.social.youtube_link === '' && local.props.social.whatsapp_link === '' && local.props.social.google_link === '' &&
                        local.props.social.instagram_link === '' &&
                        <div role="tabpanel" className="tab-pane linkListing " id="social">
                            No Social Contents Defined
                        </div>}
                        <div role="tabpanel" className="tab-pane linkListing " id="social">
                            {local.props.social.facebook_link != "" &&
                            <a href={decodeURIComponent(this.props.social.facebook_link)} target="_blank"
                               className="btn btn-block btn-social btn-facebook"><i className="fa fa-facebook"
                                                                                    aria-hidden="true"></i>Facebook</a>}
                            {local.props.social.twitter_link != "" &&
                            <a href={decodeURIComponent(this.props.social.twitter_link)} target="_blank"
                               className="btn btn-block btn-social btn-twitter"><i className="fa fa-twitter"
                                                                                   aria-hidden="true"></i>Twitter</a>}
                            {local.props.social.wordpress_link != "" &&
                            <a href={decodeURIComponent(this.props.social.wordpress_link)} target="_blank"
                               className="btn btn-block btn-social btn-facebook"><i className="fa fa-wordpress"
                                                                                    aria-hidden="true"></i>Wordpress</a>}
                            {local.props.social.youtube_link != "" &&
                            <a href={decodeURIComponent(this.props.social.youtube_link)} target="_blank"
                               className="btn btn-block btn-social btn-google-plus"><i className="fa fa-youtube"
                                                                                       aria-hidden="true"></i>Youtube</a>}
                            {local.props.social.whatsapp_link != "" &&
                            <a href="javascript:void(0)" onTouchTap={this.handleWhatAppOpen}
                               className="btn btn-block btn-social btn-linkedin"><i className="fa fa-whatsapp"
                                                                                    aria-hidden="true"></i>Whatsapp</a> }
                            {local.props.social.google_link != "" &&
                            <a href={decodeURIComponent(this.props.social.google_link)} target="_blank"
                               className="btn btn-block btn-social btn-google-plus"><i className="fa fa-google-plus"
                                                                                       aria-hidden="true"></i> Google
                                Plus</a>}
                            {local.props.social.instagram_link != "" &&
                            <a href={decodeURIComponent(this.props.social.instagram_link)} target="_blank"
                               className="btn btn-block btn-social btn-instagram"><i className="fa fa-instagram"
                                                                                     aria-hidden="true"></i>
                                Instagram</a> }
                        </div>


                        <Dialog className="pay-ads-pop"
                                modal={false}
                                open={this.state.openWhatsApp}
                                onRequestClose={this.handleWhatAppClose}
                                autoScrollBodyContent={true}>

                            <div className="ViewProfileContact">{this.props.social.whatsapp_link}</div>
                            <RaisedButton label="X" primary={true} className="cancelBtnPopup"
                                          onTouchTap={this.handleWhatAppClose}/>

                        </Dialog>
                    </div>
                </div>
                {/* end of profile_info_right*/}
            </div>
        )
    }

}
