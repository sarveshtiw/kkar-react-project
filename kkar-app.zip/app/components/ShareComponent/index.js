/**
* A link to a certain page, an anchor tag
*/
import React from 'react';
import Dialog from 'material-ui/Dialog';
import RaisedButton from 'material-ui/RaisedButton';
import TextField from 'material-ui/TextField';
var util = require('utils/request');
import cookie from 'react-cookie';

export class ShareComponent extends React.Component {

  constructor(props) {
      super(props);
      this.state = {
    }
  }

  shareUrl(){
          var field = document.getElementById('profile_url');
          field.focus();
          field.setSelectionRange(0, field.value.length);
          document.execCommand("copy");
          alert("Artist Profile has been copied on clipboard.");
}

  close(){
    this.props.close();
  }


render() {
return(
      <Dialog modal={false} open = {this.props.open} autoScrollBodyContent={true}>
        <div style={{textAlign:"center"}}>
          <p style={{fontSize:"30px"}}>Copy the below URL to share</p><br />
          <input id="profile_url" type="text" value={this.props.url} style={{width:"70%"}}/><br /><br />
          <RaisedButton className="profileEditbtn" primary={true} label="Copy" onTouchTap={this.shareUrl.bind(this)}/>
          <RaisedButton className="cancelBtnPopup" onTouchTap={this.close.bind(this)} primary={true} label="X"/>
        </div>
  </Dialog>
 );
}
}
