/**
 * A link to a certain page, an anchor tag
 */
import style from 'containers/App/assets/css/stylesheet_vinay.css';
import React from 'react';
import RaisedButton from 'material-ui/RaisedButton';
import {CreateProfile} from 'components/CreateProfile_Component'
import cookie from 'react-cookie'
const util = require('utils/request');

export class DashboardHeader extends React.Component {
  constructor(props) {
      super(props);
      this.state = {
        user_id:cookie.load('userId'),
        user_name : "",
        user_image : "",
        openState : (cookie.load('create_profile') == true ? true : false),
        Code:cookie.load('code')
      }
  }

   componentDidMount() {
     if(this.state.user_id === undefined || this.state.Code ===202 || this.state.Code === 203)
     {
       $(location).attr('href', '/not-found')
     }

      cookie.remove('create_profile',  { path: '/' });
      $('.dashboard_menu ul li a.active').on('click', function(e){
      e.preventDefault();
      $('.dashboard_menu ul').toggleClass('open');
          jQuery('#lightgallery').lightGallery();
          jQuery('.lightgallery-single-image').lightGallery();
          jQuery('.lightgallery-single-video').lightGallery();
});
     var formState = this;
      var userid = this.state.user_id;
      var param = {action:'dashboard',user_id: userid}
      util.getSetData(param,function (data) {
      if(data.status == "success"){
            formState.setState({user_name: data.user_name,user_image : data.user_image});
        }

       });
    }

  handleOpen = () => {
       this.setState({openState: true});
     };

  handleClose = () => {
      this.setState({openState: false});
  };

  render() {
    return <section className="inner_page"><div className="dash_header">
                      <div className="row">
                      <div className="col-xs-6 profileInfo">
                           <span> <a href={'/my-profile/'+this.state.user_id}><img src={(this.state.user_image === '' ||this.state.user_image === undefined ||
                           this.state.user_image === null)?require('./user-profile.png'):this.state.user_image} alt=""/>
                          </a></span>
                           <h3>{this.state.user_name}<span>Dashboard</span></h3>
                       </div>
                       <div className="col-xs-6 profileEdit  ">

                            <RaisedButton className="profileEditbtn float_right" href="/my-accounts" primary={true} label="Edit My Basic Profile" />
                            <span className="lightgallery-single-video">
                             <li className="video" data-src="https://www.youtube.com/watch?v=9GD_quGTt1k&feature=youtu.be">
                                 <button type="button" className=" btn video_assist_btn1">Video Assist <i className="fa fa-play-circle"></i></button>
                             </li>
                            </span>
                       </div>
                       </div>
                       </div>

                   <div className="dashboard_menu">
                       <ul>
                           <li><a href="/my-dashboard" className={(this.props.page === "EditProfile") ? "active" : ""}>Edit Profiles</a></li>
                           <li><a href="javascript:void(0)" onTouchTap={this.handleOpen}>Create New Profile</a></li>
                           <li><a href="/my-dashboard/messages" className={(this.props.page == "Messages") ? "active" : ""}>Messages</a></li>
                           <li><a href="/my-dashboard/bookmarks" className={(this.props.page === "Bookmark") ? "active" : ""}>Bookmarks</a></li>
                           <li><a href='/my-dashboard/analytics' className={(this.props.page === "Analytics") ? "active" : ""}>Analytics</a></li>
                           <li><a href="/my-dashboard/ratings" className={(this.props.page == "ratings") ? "active" : ""}>Ratings</a></li>
                           <li><a href="/my-dashboard/affiliate" className={(this.props.page === "Affiliates") ? "active" : ""}>Affiliates</a></li>
                           <li><a href="/my-dashboard/classifieds" className={(this.props.page === "Classified") ? "active" : ""}>Classifieds</a></li>
                           <li><a href="/my-dashboard/forums" className={(this.props.page === "Forums") ? "active" : ""}>Forums</a></li>
                           <li><a href="/my-dashboard/orders" className={(this.props.page === "Orders") ? "active" : ""}>Orders</a></li>
                           <li><a href="/my-dashboard/calendar" className={(this.props.page === "Calendar") ? "active" : ""}>Calendar</a></li>
                      </ul>
                    <CreateProfile open={this.state.openState} close={this.handleClose}/>
                   </div></section>
  }
}
