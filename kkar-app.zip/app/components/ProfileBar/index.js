import React from 'react';

//import styles from './styles.css';

function ProfileBar() {
  return (
    <div className={style.row}>
    <div className={'col-xs-6 '  + style.profileInfo}>
         <span><img src={this.state.user_image} alt=''/></span>
         <h3>{this.state.user_name}<span>Dashboard</span></h3>
     </div>
     <div className={'col-xs-6 ' + style.profileEdit}>
          <RaisedButton href='/editprofile' label='Edit My Basic Profile' secondary={true} />
     </div>
     </div>
  );
}

export default ProfileBar;
