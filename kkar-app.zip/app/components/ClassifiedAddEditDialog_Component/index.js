/**
* A link to a certain page, an anchor tag
*/
import React from 'react';
import Dialog from 'material-ui/Dialog';
import RaisedButton from 'material-ui/RaisedButton';
import {DashboardClassifiedPopUp} from 'components/DashboardClassifiedPopUp_Component';

export class ClassifiedAddEditDialog extends React.Component {
render() {
return(
  <Dialog
    title={this.props.title}
    autoDetectWindowHeight = {true}
    titleStyle={{textAlign: "center",fontSize:'20px', textColor: '#d01d15',fontWeight:'bold', paddingTop:'10px', paddingBottom:'10px', lineHeight:'24px', marginBottom:'10px'}}
    modal={false}
    open={this.props.stat}
    autoScrollBodyContent={true}>
    <div><DashboardClassifiedPopUp classi_id={this.props.classi_id} close={this.props.close}/></div>
  </Dialog>
 );
}
}
