import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import {ProfileView} from 'components/ProfileView';
var util = require('utils/request');

import Img from 'components/Img';

export class ProfileSearchSlider extends React.Component {
    constructor(props) {
        super(props);

        this.state = {

        }
    }

    componentDidMount() {
        $('.bxslider').bxSlider({
            mode: 'vertical',
            slideWidth: 100,
            minSlides: 7,
            maxSlides: 7,
            slideMargin: 5,
            moveSlides: 1,
            touchEnabled: true,
            infiniteLoop: true
        });

    }
    render(){
      return(<div className="profile_search_result">
      <ul className="bxslider">
        <li>
          <img src="assets/img/photogallery2.jpeg" />
        </li>

      </ul>
    </div>
    )
    }
}
