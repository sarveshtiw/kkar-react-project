import React from 'react';
import Logo from './logo.svg';
import $ from 'jquery';
import A from 'components/A';
import Img from 'components/Img';
import RaisedButton from 'material-ui/RaisedButton';
import {Popover, PopoverAnimationVertical} from 'material-ui/Popover';
import Menu from 'material-ui/Menu';
import MenuItem from 'material-ui/MenuItem';
import cookie from 'react-cookie';
const util = require('utils/request');
const displaynone = {display: 'none'};
import Dialog from 'material-ui/Dialog';

export default class Header extends React.Component {


    constructor(props) {
        super(props);
        this.state = {
            open: false, userId: cookie.load('userId'), email: '', openDownloadDialog: false,
            loginstate: cookie.load('code'),
            password: '', forgotemail: '', first_name: '', last_name: '', regemail: '',
            phone_no: '', regpass: '', conpass: '', refer: '', errorfname: '', errorlname: '',
            errorremail: '', errorrphone: '', errorrpass: '', errorcpass: '', loginerror: '', registererror: '',
        }
    }

    componentDidMount() {
        if (this.state.userId != undefined) {
            $('.loggedIn').show();
            $('.loggedOut').hide();
        }
        else {
            $('.loggedIn').hide();
            $('.loggedOut').show();
        }
        $('#loginWrap').hide();
        jQuery('#lightgallery').lightGallery();
        jQuery('.lightgallery-single-image').lightGallery();
        jQuery('.lightgallery-single-video').lightGallery();
        var userid = this.state.userId;
        var param = {action: 'get_basic_profile', user_id: userid}
        util.getSetData(param, function (data) {

            if (data.status == "success") {
                cookie.save('code', data.code, {path:'/'});
            }
        })

    }

    loginclick() {
         this.setState({loginerror: ''});
        $('#loginWrap').show();
        $('#loginWrap').toggleClass('fadeOutDown fadeInUp');
        this.signIn();

    }

    loginHide() {
        $('#loginWrap').show();
        $('#loginWrap').toggleClass('fadeOutDown fadeInUp');
    }

    joinClick() {
        var userid = cookie.load('userId');
        if (userid === undefined || userid === null || userid === '') {//Show Login Popup
            $('#loginWrap').show();
            $('#loginWrap').toggleClass('fadeOutDown fadeInUp');
        }
        else {

        }
    }

    signUp() {
        this.setState({loginerror: ''});
        $('#loginform, #forgot_form').hide();
        $('#gh_login_form').show();
    }

    resetPassword(value, event) {
        if (event.keyCode == 13 || value === 'click') {
            var REmail = this.state.forgotemail;
            var param1 = {action: 'reset_password', user_input: REmail}
            var localobj = this;
            util.getSetData(param1, function (data) {
                if (data.status == 'success') {
                    var message = data.message;
                    localobj.setState({loginerror: message});
                }
                else {
                    var message = data.message;
                    localobj.setState({loginerror: message});
                }
            });
        }
    }


    onLogin(value, event) {
        if (event.keyCode == 13 || value === 'click') {
            var Email = this.state.email;
            var Pasword = this.state.password;
            var param1 = {action: 'login', email: Email, password: Pasword}
            var localobj = this;
            util.getSetData(param1, function (data) {
                if (data.status == 'success') {
                    var userid = data.user_id;
                    localobj.setState({userId: userid});
                    cookie.save('userId', userid, {path: '/'});
                    cookie.save('code', data.code, {path: '/'});
                    if (data.code === 202) {
                        $(location).attr('href', '/verification/');//  this.props.changeRoute('/verification/');
                    }
                    else {
                        $(location).attr('href', '/');
                    }
                }
                else {
                    var message = data.message;
                    localobj.setState({loginerror: message});
                }
            });
        }
    }

    onLogout() {
        cookie.remove('userId', {path: '/'});
        /** Clear all cookies starting with 'session' (to get all cookies, omit regex argument) */
        /** Object.keys(cookie.select(/^session.*/
        /** i)).forEach(name => cookie.remove(name, { path: '/' })) */
        cookie.remove('userId', {path: '/'})
        cookie.remove('mobile', {path: '/'})
        $(location).attr('href', '/');
    }

    signIn() {
        this.setState({loginerror: ''});
        $('#loginform').show();
        $('#gh_login_form, #forgot_form').hide();
    }

    forgotPWD() {
        this.setState({loginerror: ''});
        $('#forgot_form').show();
        $('#gh_login_form, #loginform').hide();
    }

    handleChange(name, e) {
        if (name == 'email') {
            this.setState({email: e.target.value});
        }
        if (name == 'password') {
            this.setState({password: e.target.value});
        }
        if (name == 'forgotemail') {
            this.setState({forgotemail: e.target.value});
        }
        if (name == 'first_name') {
            this.setState({first_name: e.target.value});
            this.setState({errorfname: ''});
        }
        if (name == 'last_name') {
            this.setState({last_name: e.target.value});
            this.setState({errorlname: ''});
        }
        if (name == 'regemail') {
            this.setState({regemail: e.target.value});
            var atpos = e.target.value.indexOf('@');
            var dotpos = e.target.value.lastIndexOf('.');
            if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= e.target.value.length) {
                this.setState({errorremail: 'Not a valid e-mail address'});
                return false;
            }
            this.setState({errorremail: ' '});

        }
        if (name == 'phone_no') {
            this.setState({phone_no: e.target.value});
            this.setState({errorrphone: ''});
        }
        if (name == 'regpass') {
            this.setState({regpass: e.target.value});
            this.setState({errorrpass: ''});
        }
        if (name == 'conpass') {
            this.setState({conpass: e.target.value});
            if (this.state.regpass === this.state.conpass) {
                this.setState({errorcpass: ''});
            }
            else {
                this.setState({errorcpass: 'Password not matched'});
                return false;
            }

        }
        if (name == 'refer') {
            this.setState({refer: e.target.value});
        }

    }

    onforgotpass() {
    }

    register(user) {
        var fistname = this.state.first_name;
        var errorf = '';
        if (!fistname) {
            this.setState({errorfname: 'Please enter first name'});
            errorf = 'Y';
        }
        var lastname = this.state.last_name;
        if (!lastname) {
            this.setState({errorlname: 'Please enter last name'});
            errorf = 'Y';
        }
        var email = this.state.regemail;
        if (!email) {
            this.setState({errorremail: 'Please enter email address'});
            errorf = 'Y';
        }
        var phone_no = this.state.phone_no;
        if (!phone_no) {
            this.setState({errorrphone: 'Please enter phone number'});
            errorf = 'Y';
            ;
        }
        var password = this.state.regpass;
        if (!password) {
            this.setState({errorrpass: 'Please enter password'});
            errorf = 'Y';
        }
        if (errorf != '') {
            return false;
        }
        const refer_code = this.state.refer;
        const param1 = {
            action: 'signup', gh_first_name: fistname, gh_last_name: lastname,
            email: email, phone_no: phone_no, password: password, refer_code: refer_code
        }
        const localobj = this;
        util.getSetData(param1, function (data) {
            if (data.status === 'success') {
                const userid = data.user_id;
                localobj.setState({userId: userid});
                cookie.save('userId', userid, {path: '/'});
                cookie.save('mobile', phone_no, {path: '/'});
                //verify otp
                cookie.save('code', 202, {path:'/'});
                const url = '/verification';
                $(location).attr('href', url);
            }
            else {
                var regterror = data.message;
                localobj.setState({registererror: regterror});
            }
        });
    }

    CreateProfile(formName) {
        cookie.save('create_profile', true, {path: '/'});
        $(location).attr('href', '/my-dashboard/');
    }

    handleOpen() {
        this.setState({openDownloadDialog: true});
    }

    handleClose = () => {
        this.setState({openDownloadDialog: false});
    };

    render() {


        return (
            <div>
                <header id='masthead' className='site-header'>
                    <div className='container-fluid'>
                        <div className='logo'>
                            <a href='/'>
                                <Img src={Logo} alt='kalakar - Logo' style={{width:'208'}}/>
                            </a>
                        </div>
                        <a className='menuIcon collapsed' data-toggle='collapse' data-target='#nav'>
                            <em></em>
                        </a>
                        <nav id='nav'>
                            <ul>
                                <li><a href='javascript:void(0)' onTouchTap={this.handleOpen.bind(this)}>VIEW JOBS</a>
                                </li>
                                <li><a href='javascript:void(0)' onTouchTap={this.handleOpen.bind(this)}>POST A JOB</a>
                                </li>


              <span className="hidden-lg hidden-md ">
                 <li><a href="/testimonials">TESTIMONIALS</a></li>
                 <li><a href="javascript:void(0)" onTouchTap={this.handleOpen.bind(this)}>Videos</a></li>
                 <li><a href="javascript:void(0)" onTouchTap={this.handleOpen.bind(this)}>Founders and Partners</a></li>
                 <li><a href="javascript:void(0)" onTouchTap={this.handleOpen.bind(this)}>PROJECTS</a></li>
              </span>
                                {(this.state.userId === undefined) ?
                                    <li><a href='javascript:void(0);' className='sign_in_togg'
                                           onTouchTap={this.joinClick.bind(this)}>Join Kalakar</a></li> : ''}
                                <li><a href='javascript:void(0)' data-toggle='modal' data-target='#myModal-app'
                                       onTouchTap={this.handleOpen.bind(this)}>Download App</a>
                                    <Dialog className="pay-ads-pop"
                                            modal={false}
                                            open={this.state.openDownloadDialog}
                                            onRequestClose={this.handleClose}
                                            autoScrollBodyContent={true}>

                                        <div className="ViewProfileContact">Coming Soon</div>
                                        <RaisedButton label="X" primary={true} className="cancelBtnPopup"
                                                      onTouchTap={this.handleClose}/>

                                    </Dialog></li>
                                <li className='loggedOut' onClick={this.loginclick.bind(this)}><a
                                    href='javascript:void(0);'>Sign In</a>
                                </li>
                                <li className='loggedIn animate-if dropdown'><a href='javascript:void(0);'
                                                                                data-toggle='dropdown'>My Account</a>
                                    <ul className='animated fadeInUp dropdown-menu'>
                                        {(this.state.loginstate === 202 || this.state.loginstate === 203) ? '' :
                                            <li><a href='/my-dashboard'>My Dashboard</a></li>}
                                        {(this.state.loginstate === 202 || this.state.loginstate === 203) ? '' :
                                            <li><a href={'/my-profile/'+this.state.userId}>My Profile</a></li>}
                                        {(this.state.loginstate === 202 || this.state.loginstate === 203) ? '' :
                                            <li><a href='javascript:void(0)'
                                                   onTouchTap={this.CreateProfile.bind(this,'home')}>Create a
                                                Profile</a></li>}
                                        {(this.state.loginstate === 202 || this.state.loginstate === 203) ? '' :
                                            <li><a href='/my-dashboard/messages'>My Messages</a></li>}
                                        {(this.state.loginstate === 202 || this.state.loginstate === 203) ? '' :
                                            <li><a href='/my-dashboard/bookmarks'>My Bookmarks</a></li>}
                                        {(this.state.loginstate === 202 || this.state.loginstate === 203) ? '' :
                                            <li><a href='javascript:void(0)'>My Forums</a></li>}
                                        {(this.state.loginstate === 202 || this.state.loginstate === 203) ? '' :
                                            <li><a href='/my-dashboard/calendar'>My Calendar</a></li>}
                                        <li onClick={this.onLogout}><a href='#'>Logout</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </nav>
                    </div>
                    <div id='loginWrap' className='login_info fadeOutDown animated'><span
                        className='close_sign_pop'></span>

                        <div className='sign_in' id='loginform'>
                            <h2>Sign in <a href='javascript:void(0)' onTouchTap={this.loginHide}>X</a></h2>

                            <p className='login-username'>
                                <small>{this.state.loginerror}</small>
                                <input type='text' name='log' id='user_login' className='input' value={this.state.email}
                                       onChange={this.handleChange.bind(this, 'email')} size='20' placeholder='Email'
                                       onKeyDown={this.onLogin.bind(this,'keydown')}/>
                            </p>
                            <p className='login-password'>
                                <input type='password' name='pwd' id='user_pass' value={this.state.password}
                                       onChange={this.handleChange.bind(this, 'password')} className='input' size='20'
                                       placeholder='Password' onKeyDown={this.onLogin.bind(this,'keydown')}/>
                            </p>

                            <p className='login-submit'>
                                <input type='submit' name='wp-submit' value='Log In' className='button-primary'
                                       onClick={this.onLogin.bind(this,'click')}/>
                            </p>

                            <div className='forgot_sec'><a href='javascript:void(0);' className='forget_pass1'
                                                           onClick={this.forgotPWD.bind(this)}>Forgot password?</a>
                            </div>
                            <div className='new_acc'><a href='javascript:void(0)' onClick={this.signUp.bind(this)}>Create
                                an account</a></div>
                            <div className='social_login'></div>
                        </div>

                        <div className='sign_up' id='gh_login_form'>
                            <div className="btn_inline_view ">
                                <h2 className=" h1_btn">Sign Up <a href='javascript:void(0)'
                                                                   onTouchTap={this.loginHide}>X</a></h2>
      <span className="lightgallery-single-video">
         <li className="video" data-src="https://www.youtube.com/watch?v=2dprw9dBSBA&feature=youtu.be">
             <button type="button" className=" btn video_assist_btn margin-top-20">Video Assist <i
                 className="fa fa-play-circle"></i></button>
         </li>
      </span>
                            </div>
                            <div className='datahub_frm'>
                                <p>
                                    <small>{this.state.registererror}</small>
                                    <label htmlFor='gh_name'>First Name*:</label>
                                    <input name='gh_first_name' id='gh_first_name' type='text' required=''
                                           placeholder='First Name' value={this.state.first_name}
                                           onChange={this.handleChange.bind(this, 'first_name')}
                                           className='required isValidName'/>
                                    <small>{this.state.errorfname}</small>
                                </p>
                                <p>
                                    <label htmlFor='gh_lname'>Last Name*:</label>
                                    <input name='gh_last_name' id='gh_last_name' type='text' placeholder='Last Name'
                                           required='' value={this.state.last_name}
                                           onChange={this.handleChange.bind(this, 'last_name')}
                                           className='required isValidName'/>
                                    <small>{this.state.errorlname}</small>
                                </p>
                                <p>
                                    <label htmlFor='email'>Email*:</label>
                                    <input name='email' id='gh_email' type='email' placeholder='Email'
                                           value={this.state.regemail}
                                           onChange={this.handleChange.bind(this, 'regemail')}
                                           onKeyUp={this.handleChange.bind(this, 'regemail')} required=''
                                           className='required email'/>
                                    <small>{this.state.errorremail}</small>
                                </p>
                                <p>
                                    <label htmlFor='phone_no'>Phone Number*:</label>
                                    <input name='phone_no' id='gh_phone_no' type='text' placeholder='Phone number'
                                           value={this.state.phone_no}
                                           onChange={this.handleChange.bind(this, 'phone_no')}
                                           className='required isValidPhone'/>
                                    <small>{this.state.errorrphone}</small>
                                </p>
                                <p>
                                    <label htmlFor='password'>Password*:</label>
                                    <input name='password' id='password' type='password' placeholder='Password'
                                           required='' value={this.state.regpass}
                                           onChange={this.handleChange.bind(this, 'regpass')}
                                           className='required isValidPhone'/>
                                    <small>{this.state.errorrpass}</small>
                                </p>
                                <p>
                                    <label htmlFor='password'>Confirm Password*:</label>
                                    <input name='confirm_password' id='confirm_password' type='password' required=''
                                           placeholder='Confirm Password' value={this.state.conpass}
                                           onKeyUp={this.handleChange.bind(this, 'conpass')}
                                           onChange={this.handleChange.bind(this, 'conpass')}
                                           className='required isValidPhone'/>
                                    <small>{this.state.errorcpass}</small>
                                </p>
                                <p>
                                    <label htmlFor='refer_code'>Refer Code:</label>
                                    <input name='refer_code' id='refer_code' type='text' placeholder='Refer Code'
                                           value={this.state.refer} onChange={this.handleChange.bind(this, 'refer')}
                                           className='required'/>
                                </p>
                            </div>
                            <div className='sign_up_bt'>
                                <input type='submit' alt='submit' name='gh_regisration'
                                       onClick={this.register.bind(this)} value='Sign Up'/>
                            </div>
                            <div className='sign_up_login'><a href='javascript:void(0)' className='signin_new'
                                                              onClick={this.signIn.bind(this)}>Already have an
                                account?</a></div>

                        </div>

                        <div className='sign_in' id='forgot_form'>
                            <div className='forgot_pass_sec'>
                                <h2>Forgot Password <a href='javascript:void(0);' onTouchTap={this.loginHide}>X</a></h2>

                                <div className='forgot_email_con'>
                                    <small>{this.state.loginerror}</small>
                                    <p className='login-username'>
                                        <input type='text' name='log' id='' className='input' value={this.forgotemail}
                                               onChange={this.handleChange.bind(this, 'forgotemail')}
                                               onKeyDown={this.resetPassword.bind(this,'keydown')} size='20'
                                               placeholder='Email'/>
                                    </p>

                                    <p className='login-submit'>
                                        <input type='submit' name='wp-submit' className='button-primary'
                                               onClick={this.resetPassword.bind(this,'click')} value='Reset Password'/>
                                    </p>

                                    <p className='forgot_sec'>
                                        <a href='javascript:void(0);' className='signin_new'
                                           onClick={this.signIn.bind(this)}>Sign In</a>
                                        <a href='javascript:void(0);' className='forget_pass1'
                                           onClick={this.signUp.bind(this)}>Create an account</a>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </header>
            </div>
        );
    }
}
