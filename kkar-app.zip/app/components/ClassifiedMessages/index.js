import React from 'react';
import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
var util = require('utils/request');
import cookie from 'react-cookie';
import { API_URL } from 'containers/App/constants'

export class ClassifiedMessages extends React.Component {
    openRoute = (route) => {
        this.props.changeRoute(route);
    };


    constructor(props) {
        super(props);
        this.state = {
            message: ''


        }

    }

    componentDidMount() {

    }

    componentWillReceiveProps(nextProps) {

        var message_id = nextProps.messageid;

        var param = {action: 'classi_detail', classified_id: this.state.message_id}
        var formState = this;
        util.getSetData(param, function (data) {
            if (data.status == "success") {

                formState.setState({
                    msg_count: data.data[0].msg_count,
                    user_id: data.data[0].user_id,
                    useful_msg_count: data.data[0].useful_msg_count,
                    posted_clas: data.data[0].posted_clas,
                    first_name: data.data[0].first_name,
                    last_name: data.data[0].last_name,
                    location: data.data[0].location,
                    title: data.data[0].title,
                    cat_name: data.data[0].cat_name,
                    post_description: data.data[0].post_description,
                    duration_of_work: data.data[0].duration_of_work,
                    photo: data.data[0].photo,
                    avg_rate: data.data[0].avg_rate,
                    schedule_work_dates: data.data[0].schedule_work_dates,
                    city: data.data[0].city
                });
            }
        });
    }

    deleteClassi() {
        var param = {action: 'classi_delete', classified_id: this.state.message_id}
        var formState = this;
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                formState.props.classiMsg();
                formState.props.close();

            }
        })

    }

    handleInputChange(e) {
        this.setState({description: e.target.value})

    }

    classifiedOffer() {
        var param = {
            action: 'classi_reply', classified_id: this.state.message_id,
            user_id: this.state.user_id, message_description: this.state.description
        }
        var formState = this;
        util.getSetData(param, function (data) {

            if (data.status == "success") {
                formState.setState({
                    message: data.message
                });
                alert(formState.state.message);
                formState.props.close();

            }
        })

    }

    clear() {
        this.props.close();
    }

    render() {
        $('#incomingMsg').mCustomScrollbar({
            setHeight: 366,
            theme: "dark-4"
        })

        $('#outgoingMsg').mCustomScrollbar({
            setHeight: 75,
            theme: "dark-4"
        })
        return (
            <Dialog
                autoDetectWindowHeight={true}
                modal={false}
                className="send_new_msg classifiedOuter"
                titleClassName="send_head"
                bodyStyle={{padding:'0px',  fontSize: '15px'}}
                open={this.props.open}
                autoScrollBodyContent={true}>
                <div>
                    <div className="send_head">
                        <div className="row">
                            <div className="col-xs-12">
                                <h2>
                                    <small>
                                        Classfied Ad for {this.state.cat_name}
                                    </small>
                                    {this.state.title}
                                </h2>
                            </div>
                        </div>
                    </div>
                    <div className="msgSec classified">
                        <div className="send_content leftSec">
                            <div className="row">
                                <div className="col-sm-12">
                                    <div id="incomingMsg">
                                        <div contentEditable={false}>
                                            <p>
                                                Avg Daily Rate:{this.state.avg_rate}
                                            </p>

                                            <p>
                                                Duration of Work:{this.state.duration_of_work}
                                            </p>

                                            <p>
                                                Scheduled Work Dates:{this.state.schedule_work_dates}
                                            </p>

                                            <p>
                                                Location of Work:{this.state.location}
                                            </p>

                                            <p>{this.state.post_description}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="rightSec">
                            <div className="proPic">
                                <img
                                    src={this.state.photo}
                                    width={183}
                                    height={104}
                                    alt/>
                            </div>
                            <h2>
                                {this.state.first_name + ' ' + this.state.last_name}
                            </h2>

                            <h3>
                                &nbsp;
                            </h3>

                            <p className="location">
                                <i className="fa fa-map-marker"/>{this.state.city}
                            </p>

                            <p className="rating">
                                <strong>&nbsp;</strong>
                                <small>
                                    &nbsp;
                                </small>
                            </p>
                            <ul>
                                <li>
                                    Total Messages sent <em>{this.state.msg_count}</em>
                                </li>
                                <li>
                                    Professionally useful Messages <em>{this.state.useful_msg_count}</em>
                                </li>
                                <li>
                                    Total Classfieds Posted <em>{this.state.posted_clas}</em>
                                </li>
                            </ul>
                        </div>
                        <div className="row">
                            <div className="col-sm-12">
                                <div className="col-sm-12">
                                    <div className="outMsg">
                      <textarea placeholder="Write Your Message to" onChange={this.handleInputChange.bind(this)}>
                      </textarea>

                                    </div>
                                    <div className="btns">
                                        <button className="btn grey big" onClick={this.deleteClassi.bind(this)}>
                                            delete classified
                                        </button>
                                        <button className="btn red big" onClick={this.classifiedOffer.bind(this)}>
                                            apply for offer
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <RaisedButton label="X" primary={true} className="cancelBtnPopup"
                              onTouchTap={this.clear.bind(this)}/>

            </Dialog>)
    }
}
