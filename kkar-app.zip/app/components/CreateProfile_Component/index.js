import React from 'react';
import Dialog from 'material-ui/Dialog';
import $ from 'jquery';
import RaisedButton from 'material-ui/RaisedButton';
import SelectField from 'material-ui/SelectField';
import MenuItem from 'material-ui/MenuItem';
import cookie from 'react-cookie';
const util = require('utils/request');

export class CreateProfile extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            user_id: cookie.load('userId'),
            kalakarParentTypeData: [],
            kalakarChildTypeData: [],
            kalakarSubChildTypeData: [],
            parentValue: '',
            childValue: '',
            Amount: 0,
            finalPrice: 600,
            form_data: {
                category_id: '',
                show: false,
                refer_code: '',
                errorMsg: false,
                referalmessage: '',

                successMsg: false
            }
        }
    }

    componentDidMount() {
        var formState = this;
        var kalakarTypeParam = {action: 'get_parent_cat'}
        util.getSetData(kalakarTypeParam, function (data) {
            formState.setState({kalakarParentTypeData: data.data});
        });
    }

    handleParentChange(event, index, value) {
        if (index > 0) {
            var formState = this;
            formState.setState({
                parentValue: value
            });
            this.state.kalakarChildTypeData = [];
            this.state.kalakarSubChildTypeData = [];
            var param = {action: 'get_child_cat', category: value}
            util.getSetData(param, function (data) {
                formState.setState({kalakarChildTypeData: data.data})
            });
        }
    }

    handleChildChange(event, index, value) {
        if (index > 0) {
            var formState = this;
            formState.kalakarSubChildTypeData = [];
            var param = {action: 'get_child_cat', category: value}
            util.getSetData(param, function (data) {
                if (data.code === 200) {
                    formState.setState({Amount: data.data[0].category_price, finalPrice: data.data[0].category_price});
                    var change = {};
                    change.form_data = formState.state.form_data;
                    change.form_data['category_id'] = value;
                    formState.state.form_data["show"] = true;
                    formState.setState(change);
                }
                else {
                    formState.setState({kalakarSubChildTypeData: data.data, childValue: value});
                }
            });
        }
    }


    createprofile() {
        var formState = this;
        if (this.state.finalPrice === 0) {
            var param = {
                action: 'create_profile',
                user_id: this.state.user_id,
                sub_child_cat: formState.state.form_data["category_id"],
                amount_input: this.state.finalPrice,
                refer_code: this.state.form_data.refer_code
            }
            util.getSetData(param, function (data) {
                if (data.status == "success") {
                    $(location).attr('href', '/my-dashboard');
                }
                else {
                    alert(data.message);
                }
            });
        }
        else {
            var param = {
                action: 'create_profile',
                user_id: this.state.user_id,
                sub_child_cat: formState.state.form_data["category_id"],
                amount_input: this.state.finalPrice,
                refer_code: this.state.form_data.refer_code
            }
            util.getSetData(param, function (data) {
                var change = {};
                if (data.status == "success") {
                    var form = $('<form action="http://kalakar.pro:90/kalakar/PayUMoney_form.php" method="post">' +
                        '<input type="hidden" name="amount" value="' + formState.state.finalPrice + '" />' +
                        '<input type="hidden" name="firstname" value="' + data.firstname + '" />' +
                        '<input type="hidden" name="email" value="' + data.email + '" />' +
                        '<input type="hidden" name="productinfo" value="' + data.catID + '" />' +
                        '<input type="hidden" name="phone" value="' + data.phone + '" />' +
                        '<input type="hidden" name="udf1" value="' + data.profile_id + '" />' +
                        '<input type="hidden" name="udf2" value="' + data.user_id + '" />' +
                        '<input type="hidden" name="udf3" value="' + data.order + '" />' +
                        '</form>');
                    $('body').append(form);
                    $(form).submit();
                }
            });
        }
    }

    checkReferalCode() {
        var formState = this;
        if (formState.state.form_data["refer_code"] !== '') {
            var param = {
                action: 'verify_referal',
                user_id: this.state.user_id,
                refer_code: formState.state.form_data["refer_code"]
            }
            util.getSetData(param, function (data) {
                var change = {};
                if (data.status == "fail") {
                    change.form_data = formState.state.form_data;
                    change.form_data["errorMsg"] = true;
                    change.form_data["successMsg"] = false;
                    change.finalPrice = formState.state.Amount;
                    formState.setState(change);
                }
                else {
                    change.form_data = formState.state.form_data;
                    change.form_data["errorMsg"] = false;
                    change.form_data["successMsg"] = true;
                    formState.setState(change);
                    var discount = (formState.state.Amount * data.data.discount_percentage) / 100;
                    var finalAMt = formState.state.Amount - discount;
                    formState.setState({referalmessage: data.message, finalPrice: finalAMt});
                }
            });
        }
        var change = {};
        change.form_data = formState.state.form_data;
        change.form_data["errorMsg"] = false;
        change.form_data["successMsg"] = false;
        formState.setState(change);
    }

    handleInputChange(name, e) {
        var change = {};
        change.form_data = this.state.form_data;
        change.form_data[name] = e.target.value;
        this.setState(change);
    }

    clear() {
        this.props.close();
        this.state.form_data.refer_code = '';
        this.state.parentValue='';
        this.state.childValue='';
        this.state.form_data.category_id='';
        this.state.form_data["show"]=false;
    }

    render() {
        return (
            <Dialog className="pay-ads-pop create_profile_pop" modal={false} open={this.props.open}
                    autoScrollBodyContent={true}>
                <RaisedButton label="X" primary={true} className="cancelBtnPopup" onTouchTap={this.clear.bind(this)}/>

                <div className="create_profile_pop">
                    <h2>Create a new <span>kalakar</span> profile!</h2>

                    <div className="optionsSelect">
                        <div className="row">
                            <div className="col-sm-4">
                                <SelectField className="CrProSelectBox" value={this.state.parentValue}
                                             onChange={this.handleParentChange.bind(this)} maxHeight={180}>
                                    <MenuItem value={this.state.parentValue} primaryText="Type of Kalakar"/>
                                    {this.state.kalakarParentTypeData.map(s =>
                                            <MenuItem value={s.category_id} key={s.category_name}
                                                      primaryText={s.category_name} style={{cursor:'pointer'}}/>
                                    )}
                                </SelectField>
                            </div>
                            <div className="col-sm-4">
                                <SelectField className="CrProSelectBox" value={this.state.childValue}
                                             onChange={this.handleChildChange.bind(this)} maxHeight={180}
                                             fullWidth={true}>
                                    <MenuItem value={this.state.childValue} primaryText="Select"/>
                                    {this.state.kalakarChildTypeData.map(s =>
                                            <MenuItem value={s.category_id} key={s.category_name}
                                                      primaryText={s.category_name} style={{cursor:'pointer'}}/>
                                    )}
                                </SelectField>
                            </div>
                            <div className="col-sm-4">
                                <SelectField className="CrProSelectBox" value={this.state.form_data.category_id}
                                             onChange={this.handleChildChange.bind(this)} maxHeight={180}
                                             fullWidth={true}>
                                    <MenuItem value={this.state.form_data.category_id} primaryText="Select Profession"/>
                                    {this.state.kalakarSubChildTypeData.map(s =>
                                            <MenuItem value={s.category_id} key={s.category_name}
                                                      primaryText={s.category_name} style={{cursor:'pointer'}}/>
                                    )}
                                </SelectField>
                            </div>
                        </div>
                    </div>
                    {this.state.form_data["show"] && <div>
                        <div className="optionsPrices">
                            <div className="row">
                                <div className="col-sm-6">
                                    <div className="checkboxes">
                                        <input type="checkbox" checked/>
                                        <label>premium</label>
                                    </div>
                                </div>
                                <div className="col-sm-6">
                   <span className="plan_price">
                       {this.state.Amount != this.state.finalPrice &&
                   <span className="old_price">Rs <strong>{this.state.Amount}</strong></span>}
                   Rs <strong className="dyn_price">{this.state.finalPrice}</strong>/- year</span>
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-xs-12">
                                    <p> Get a comprehensive website - show your photos, videos, work credibility,
                                        training, testimonials, social media links and all contact details.</p>

                                    <p>Unlock professional features - unlimited photos and videos; view rating based
                                        messages; all professional classifieds and multiple profile analytics.
                                        Additionally receive
                                        custom professional training tutorials, videos and invitations to live community
                                        workshops.</p>
                                </div>
                            </div>
                        </div>
                        <div className="refer_code_profile">
                            <div className="row">
                                <div className="col-xs-12">
                                    <p>Refer Code</p>
                                    <input type="text" id="refer_code_text" name="refer_code_text"
                                           value={this.state.form_data.refer_code}
                                           onChange={this.handleInputChange.bind(this,'refer_code')}
                                           onBlur={this.checkReferalCode.bind(this)}/>
                                    {this.state.form_data["successMsg"] &&
                                    <span id="refer_code_msg_s" className="refer_code_msg_s">{this.state.referalmessage}</span>}
                                    {this.state.form_data["errorMsg"] &&
                                    <span id="refer_code_msg_f" className="refer_code_msg_f">Invalid Code.</span>}
                                </div>
                            </div>
                        </div>
                        <div className="refer_code_profile">
                            <div className="row">
                                <div className="col-xs-12">
                                    <button type="button" id="order_btn" className="pay_now_offer"
                                            onClick={this.createprofile.bind(this)}>Pay Now
                                    </button>
                                </div>
                            </div>
                        </div>

                    </div>
                    }
                </div>

            </Dialog>);
    }
}
