import React from 'react';
import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
var util = require('utils/request');
import cookie from 'react-cookie';
import {ReportDialog} from 'components/ReportDialog';
import {NewMessage} from 'components/NewMessage';
import {ShareComponent} from 'components/ShareComponent';
import {ResultMsg} from 'components/ResultMsg';

/**
 * Alerts are urgent interruptions, requiring acknowledgement, that inform the user about a situation.
 */
export class UserProfile_LeftSection extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            user_id: cookie.load('userId'),
            openDialog: false,
            open: false,
            openMessage: false,
            likes_count: this.props.data.likes,
            button_text: "Like this profile",
            bookmarkText:'Bookmark',
            text_show: '',
            openShare : false,
            resultDialogOpen : false,
            resultMessage : ''

        }
    }

    handleOpen(name) {
        var userid = this.state.user_id;
        if (name == "userphone") {
            if (this.props.data.phone_visibility_to == "public" ||this.props.data.phone_visibility_to == "register_users"  && userid != undefined ) {
                this.setState({
                    text_show: this.props.data.user_phone,
                    open: true
                });
            }
            else {
                if (this.props.data.phone_visibility_to == "none") {
                    this.setState({
                        text_show: "Contact is restricted by user",
                        open: true
                    });
                }
            }
        }
        if (name == "useremail") {
            if (this.props.data.email_visibility_to == "public" || (this.props.data.email_visibility_to == "register_users" && userid != undefined )) {
                this.setState({
                    text_show: this.props.data.user_email,
                    open: true
                });
            }

            if (this.props.data.email_visibility_to == "none") {
                this.setState({
                    text_show: "Email id is restricted by user",
                    open: true
                });
            }
        }
        if (name == "agentphone") {
            if (this.props.data.agent_phone_visibility_to == "public" || (this.props.data.agent_phone_visibility_to == "register_users" && userid != undefined )) {
                this.setState({
                    text_show: this.props.data.agent_phone,
                    open: true
                });
            }
            if (this.props.data.agent_phone_visibility_to == "none") {
                this.setState({
                    text_show: "Contact is restricted by user",
                    open: true
                });
            }
        }
        if (name == "agentemail") {
            if (this.props.data.agent_email_visibility_to == "public" || (this.props.data.agent_email_visibility_to == "register_users" && userid != undefined )) {
                this.setState({
                    text_show: this.props.data.agent_email,
                    open: true
                });
            }
            if (this.props.data.agent_email_visibility_to == "none") {
                this.setState({
                    text_show: "Email id is restricted by user",
                    open: true
                });
            }
        }

    }

    handleOpenMessage() {
        var userid = this.state.user_id;
        if(userid === undefined || userid === null || userid ===''){//Show Login Popup
            $('#loginWrap').show();
            $('#loginWrap').toggleClass('fadeOutDown fadeInUp');
            //this.setState({openMessage: false});
        }
        else{
            this.setState({openMessage: true});
        }


    };

    handleCloseMessage() {

        this.setState({openMessage: false
        });
    };


    handleClose = () => {
        this.setState({open: false});
    };

    componentDidMount() {
        if(jQuery(window).width() > 1199){
            jQuery(document).ready(function() {
                jQuery('.profile_main_info ul.responsive-tabs__list li.responsive-tabs__list__item').click(function(){
                    jQuery("html, body").animate({ scrollTop: 0 }, "slow");
                });
            });

            jQuery(document).scroll( function(){
                var header_h = jQuery('.header-main').height();
                var header_h1 = header_h - 35;
                if(jQuery(this).scrollTop() > header_h1){
                    jQuery('.profile_page .profile_left').addClass('sticky_common_menu');
                    jQuery('.profile_page .profile_left').css('top','30px')
                }
                else{
                    jQuery('.profile_page .profile_left').removeClass('sticky_common_menu');
                    jQuery('.profile_page .profile_left').css('top','0px');
                }
            });

            jQuery(document).scroll( function(){
                var menu_height_b2 = jQuery('.profile_page .profile_main').height();
                var menu_height_b3 = jQuery('.profile_page .profile_left').height();
                var menu_height_b = menu_height_b2 - menu_height_b3 ;

                if(jQuery(this).scrollTop() > menu_height_b){
                    jQuery('.profile_page .profile_left').css('top',menu_height_b - 30);
                    jQuery('.profile_page .profile_left').addClass('sticky_left_menu_bottom');
                }
                else{
                    jQuery('.profile_page .profile_left').removeClass('sticky_left_menu_bottom');
                }
            });
        }



        var events = [];
        var profileID = this.props.profileId;

        var found = false,found1 = false;
        for (var i = 0; i < this.props.data.bookmark_by.length && !found; i++) {
            if (this.props.data.bookmark_by[i] == cookie.load('userId')) {
                found = true;
                this.setState({bookmarkText : "Bookmarked"});
                break;
            }
        }

        for (var i = 0; i < this.props.data.like_by.length && !found1; i++) {
            if (this.props.data.like_by[i] == cookie.load('userId')) {
                found1 = true;
                this.setState({button_text : "Dislike this profile"});
                break;
            }
        }

        var param = {action: 'calendar', profile_id: profileID, type: 'fetch'}
        var formState = this;
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                if (data.data != null) {
                    for (var i = 0; i < data.data.length; i++) {
                        var event = {};
                        event["id"] = data.data[i].id;
                        event["title"] = data.data[i].title;
                        event["start"] = data.data[i].startdate;
                        event["end"] = data.data[i].enddate;
                        events.push(event);
                    }
                }
            }

            jQuery('#calendar').fullCalendar({
                events: events,
                eventRender: function(event, element, view) {
                    var dataToFind = moment(event.start).format('YYYY-MM-DD');
                    //  $("td[data-date='"+dataToFind+"']").html('');
                    //  $("td[data-date='"+dataToFind+"']").append("<a class='fc-event'>"+new Date(dataToFind).getDate()+"</a>");
                }
            });


        });
        jQuery('.user_event_cal a').click(function (e) {
           jQuery('#calendar').toggleClass('cal_open');
       });
       jQuery('header, footer, .profile_main, .login_info_click a, .result_flag a, .actor_p, .actor_rating, .actor_contact, #nav-dots span').click(function (e) {
          jQuery('#calendar').removeClass('cal_open');
      });



    }

    likeprofile() {
        var userid = this.state.user_id;
        if(userid === undefined || userid === null || userid ===''){//Show Login Popup
            $('#loginWrap').show();
            $('#loginWrap').toggleClass('fadeOutDown fadeInUp');
            return;
        }

        var formstate = this;
        var param = {action: 'likes', profile_id: this.props.profileId, user_id: cookie.load('userId')}
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                if (data.code == 200) {
                    formstate.setState({
                        button_text: 'Dislike this Profile',
                        likes_count: data.likes_count
                    })
                }
                else if(data.code == 201){
                    formstate.setState({
                        button_text: 'Like this Profile',
                        likes_count: data.likes_count
                    })
                }
                else if(data.code == 202){//Show Login Popup
                    $('#loginWrap').show();
                    $('#loginWrap').toggleClass('fadeOutDown fadeInUp');
                    formstate.setState({
                        likes_count: likes_count
                    })
                }
                else if(data.code == 203){
                    formstate.setState({resultDialogOpen : true,resultMessage:data.message});
                    //  alert(data.message);
                }
                else {
                    formstate.setState({resultDialogOpen : true,resultMessage:data.message});
                    //  alert(data.message);
                }

            }
            else {
                formstate.setState({resultDialogOpen : true,resultMessage:data.message});
                //alert(data.message);
            }
        });
    }

    openReportDialog = () => {
        this.setState({openDialog: true});
    };

    closeReportDialog = () => {
        this.setState({openDialog: false});
    };

    profileBookmark(){
        var userid = this.state.user_id;
        if(userid === undefined || userid === null || userid ===''){//Show Login Popup
            $('#loginWrap').show();
            $('#loginWrap').toggleClass('fadeOutDown fadeInUp');
            return;
        }
        var formstate = this;
        var param = {action: 'bookmark', profile_id: this.props.profileId, user_id: cookie.load('userId')}
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                if(data.code == 200)
                    formstate.setState({bookmarkText : "Bookmarked"});
                else if(data.code == 201)
                    formstate.setState({bookmarkText : "Bookmark"});
            }
            formstate.setState({resultDialogOpen : true,resultMessage:data.message});
        });
    }
    shareUrl(){
        this.setState({openShare: true});
    }


    handleDialogClose = () => {
        this.setState({openShare: false});
    };

    render() {
        if (this.props.data != undefined) {
            var bgdivStyle = {
                backgroundColor: '#' + this.props.data.profile_color,
                borderColor: '#' + this.props.data.profile_color
            };
            var fontStyle = {
                color: '#' + this.props.data.profile_color
            };
        }
        return (

            <div>

                {this.props.data != undefined &&
                <div>
                    <div className="actor_p">
      <span className="result_images">
          <a href={'/my-profile/'+this.props.data.user_id}><img src={(this.props.data.photo_path ==="" ||this.props.data.photo_path === null||this.props.data.photo_path ===undefined)? require('./no-img-pro.png'): this.props.data.photo_path }
                                                                alt="" height="110" width="200"/></a>
          <span className="result_flag">
              <span className="report_result" id="report_result"><a href="javascript:void(0);" data-id="1943"
                                                                    id="media_id">
                  <img src="http://www.kalakar.pro:90/kalakar/demo/other/assets/img/report_ico.png"
                       onClick={this.openReportDialog} alt="report"/></a> Report
                  <ReportDialog media_id={this.props.data.photo} open={this.state.openDialog}
                                close={this.closeReportDialog}/>
              </span>
              <span className="like_result" id="likes_count_img">
                <a href="#"><img src="http://www.kalakar.pro:90/kalakar/demo/other/assets/img/like_ico.png" alt=""/></a> {this.props.data.likes}
              </span>
          </span>
      </span>
                        <a href={'/my-profile/'+this.props.data.user_id}><h2 title={this.props.data.first_name+' '+this.props.data.last_name}>{this.props.data.first_name+' '+this.props.data.last_name}</h2></a>

                        <h3 title={this.props.data.category_name}>{this.props.data.category_name}</h3>
                        <span className="location"> <i className="fa fa-map-marker"
                                                       aria-hidden="true"></i> {this.props.data.city}</span>
                    </div>

                    <div className="rating_container">
                        <div className="actor_rating">
                            <span className="left_rating">Avg Prof. Fee <strong><i className="fa fa-inr"></i> {this.props.data.workrate}
                                /day</strong></span>
                            <span className="right_rating">{this.props.data.rating}<strong style={fontStyle}>incred
                                rating</strong></span>
                        </div>
                        <div className="actor_links">
        <span className="u_action_btns login_info_click">

          <a href="javascript:void(0)" title={this.props.data.first_name} style={bgdivStyle} data-toggle="modal"
             data-target="#myModal-1"
             onTouchTap={ this.handleOpenMessage.bind(this)}>Message {this.props.data.first_name}</a>
          <NewMessage open={this.state.openMessage} close={this.handleCloseMessage.bind(this)}
                      name={this.props.data.full_name}
                      profileId={this.props.data.id_profile} categoryId={this.props.data.category_id}
                      categoryName={this.props.data.category_name}
                      userId={this.props.data.user_id}
                      isDisabled={true} myProfileId={this.props.profileId}/>

            <a href="javascript:void(0)" style={bgdivStyle} id="bookmark" onClick={this.profileBookmark.bind(this)}>{this.state.bookmarkText}</a>
        </span>
                            <ul>
                                <li className="user_event_cal">
                                    <a href="javascript:void(0)" >{this.props.data.first_name + "'" } s Calendar</a>
                                  <span className="user_calender_evt" >
                                       <div id="calendar" className="fc fc-ltr fc-unthemed"></div>
                                  </span>
                                </li>

                                <li>
                                    <input id="url" type="text" value={this.props.data.profile_url} className="hidden"/>
                                    <a href="javascript:void(0)" onClick={this.shareUrl.bind(this)}>Share profile</a>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div className="actor_contact">
      <span className="login_info_click">
        <span className="left_like_p"><a href="javascript:void(0)" onClick={this.likeprofile.bind(this)}
                                         className="share_p" id="liked"
                                         style={fontStyle}>{this.state.button_text}</a></span>
        <span className="right_like_p" id="likes_count" style={fontStyle}>{this.state.likes_count} Likes</span>
      </span>
      <span className="contact_p_detail">
          <span className="my_con">
              <h2 title={this.props.data.first_name}>{this.props.data.first_name}</h2>
              <span className="contact_hover">
                  <a href="javascript:void(0)" onTouchTap={this.handleOpen.bind(this,'userphone')}><i
                      className="fa fa-phone-square"
                      aria-hidden="true"></i></a>
              </span>
              <span className="contact_hover">
                  <a href="javascript:void(0)" onTouchTap={this.handleOpen.bind(this,'useremail')}><i
                      className="fa fa-envelope" aria-hidden="true"></i></a>
              </span>
          </span>
          <span className="agent_con">
              <h2>Agent</h2>
              <span className="contact_hover">
                  <a href="javascript:void(0)" onTouchTap={this.handleOpen.bind(this,'agentphone')}><i
                      className="fa fa-phone-square" aria-hidden="true"></i></a>
              </span>
              <span className="contact_hover">
                  <a href="javascript:void(0)" onTouchTap={this.handleOpen.bind(this,'agentemail')}><i
                      className="fa fa-envelope" aria-hidden="true"></i></a>
              </span>

          </span>
           <Dialog className="pay-ads-pop"
                   modal={false}
                   open={this.state.open}
                   onRequestClose={this.handleClose}
                   autoScrollBodyContent={true}>

               <div className="ViewProfileContact">{this.state.text_show}</div>
               <RaisedButton label="X" primary={true} className="cancelBtnPopup" onTouchTap={this.handleClose}/>

           </Dialog>
              <span className="contact_social_detail">

                  {this.props.social.facebook_link != "" &&
                  <a href={decodeURIComponent(this.props.social.facebook_link)} target="_blank"><i
                      className="fa fa-facebook-square" aria-hidden="true"></i></a>}
                  {this.props.social.twitter_link != "" &&
                  <a href={decodeURIComponent(this.props.social.twitter_link)} target="_blank"><i
                      className="fa fa-twitter-square" aria-hidden="true"></i></a>}
                  {this.props.social.youtube_link != "" &&
                  <a href={decodeURIComponent(this.props.social.youtube_link)} target="_blank"><i
                      className="fa fa-youtube" aria-hidden="true"></i></a>}
                  {this.props.social.wordpress_link != "" &&
                  <a href={decodeURIComponent(this.props.social.wordpress_link)} target="_blank">
                      <i className="fa fa-wikipedia-w" aria-hidden="true"></i></a>}
                  {this.props.social.instagram_link != "" &&
                  <a href={decodeURIComponent(this.props.social.instagram_link)} target="_blank">
                      <i className="fa fa-instagram" aria-hidden="true"></i></a>}
              </span>

      </span>
                        <span className="contact_email_detail">
              <p>
                  <a href={(this.props.data.my_website === null || this.props.data.my_website === undefined ||this.props.data.my_website === "")?"":this.props.data.my_website} target="_blank">
                  {(this.props.data.my_website === null || this.props.data.my_website === undefined ||this.props.data.my_website === "")?"":this.props.data.my_website}</a>
              </p>
          </span>
                    </div>
                    <ShareComponent open={this.state.openShare} close={this.handleDialogClose} url = {this.props.data.profile_url}/>
                </div>


                }
                <ResultMsg open={this.state.resultDialogOpen} title="Delete Tag"
                           body={this.state.resultMessage} openState = {this}/>
            </div>


        );
    }
}
