import React from 'react';
import RaisedButton from 'material-ui/RaisedButton';

export class Profilecomponent extends React.Component {
    constructor(props) {
        super(props);
        this.state =
        {
            pageLoader:true
        }}
    componentDidUpdate(){$('.pageloader').remove();}
    componentDidMount() {

        $(".dash_profileItem").owlCarousel({
            items : 5,
            loop:true,
            nav:true,
            autoplayTimeout:3000,
            autoplaySpeed: 1000,
            autoplay:false,
            responsive:{  0:{items:1}, 360:{items:2},  600:{items:3}, 768:{items:4}, 1000:{items:5} }
        });

      //$(".owl-next").trigger('click');
      //$(".owl-prev").trigger('click');

    }



    render() {

        var local=this;
        return <div>
            <div className="pageloader"><img src="http://kalakar.pro:90/kalakar/demo/other/assets/img/loader.svg"/></div>

            <div className="item">
                <a href={this.props.proUrl}>
                    <div className="item_inner">
                   <span className="edit_p_img">
                      <img src={this.props.bigimage}/>
                   </span>
                        <h3>{this.props.category}</h3>
                      <span className="small_images">
                        <ul>
                            {this.props.smallimages.map(function(object, i){
                                return <li key={i}><img src={object.photo} alt=""/></li>
                            })}
                        </ul>
                     </span>
                    </div>
                </a>
            </div>

        </div>
    }
}
