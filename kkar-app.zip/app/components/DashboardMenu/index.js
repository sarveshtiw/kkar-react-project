import React from 'react';
import $ from 'jquery';
import { DialogConfirm } from 'components/TagDelete';
import cookie from 'react-cookie';
var util = require('utils/request');

export class DashboardMenu extends React.Component {

  constructor(props) {
      super(props);
      this.state = {
         confirmOpen : false,
         user_id:cookie.load('userId')
       }
  }

  componentDidMount() {
        $('.sidebar h2').click(function(){
    		$(this).toggleClass('active');
    		$(this).next('ul').toggleClass('open');
    	});
  }

  handleOpen = () => {
      this.setState({confirmOpen: true});
  };

  handleClose = () => {
      this.setState({confirmOpen: false});
  };

  delete(profile_id){
      var param = {action: 'deleteProfile',profile_id: profile_id, user_id: this.state.user_id}
      util.getSetData(param, function (data) {
          if (data.status == "success") {
            console.log(data);
             alert("Your Profile has been deleted successfully.");
             $(location).attr('href', '/my-dashboard');
          }
          else {
              alert("Please try again.");
          }
      });
  }

    render() {
        return(
        <div  className="sidebar cell">
            <h2>Create My Profile</h2>
            <ul>
                <li className={(this.props.page === "ProfileBasic") ? "active" : ""}><a href={"/my-accounts/extended-profile/"+this.props.profileId+"/basic"}>profile basics</a></li>
                <li className={(this.props.page === "ContactDetails") ? "active" : ""}><a href={"/my-accounts/extended-profile/"+this.props.profileId+"/details"}>Contact Details</a></li>
                <li className={(this.props.page === "Intro") ? "active" : ""}><a href={"/my-accounts/extended-profile/"+this.props.profileId+"/intro"}>Intro</a></li>
                <li className={(this.props.page === "Workcred") ? "active" : ""}><a href={"/my-accounts/extended-profile/"+this.props.profileId+"/workcred"}>Workcred</a></li>
                <li className={(this.props.page === "Training") ? "active" : ""}><a href={"/my-accounts/extended-profile/"+this.props.profileId+"/training"}>training</a></li>
                <li className={(this.props.page === "Awards") ? "active" : ""}><a href={"/my-accounts/extended-profile/"+this.props.profileId+"/awards"}>awards</a></li>
                <li className={(this.props.page === "Links") ? "active" : ""}><a href={"/my-accounts/extended-profile/"+this.props.profileId+"/links"}>links</a></li>
                <li className={(this.props.page === "Tags") ? "active" : ""}><a href={"/my-accounts/extended-profile/"+this.props.profileId+"/tags"}>Tags</a></li>
                <li className={(this.props.page === "Circle") ? "active" : ""}><a href={"/my-accounts/extended-profile/"+this.props.profileId+"/circle"}>Circle</a></li>
                <li className={(this.props.page === "Photos") ? "active" : ""}><a href={"/my-accounts/extended-profile/"+this.props.profileId+"/photos"}>photos</a></li>
                <li className={(this.props.page === "Videos") ? "active" : ""}><a href={"/my-accounts/extended-profile/"+this.props.profileId+"/video"}>videos</a></li>
                <li className={(this.props.page === "Albums") ? "active" : ""}><a href={"/my-accounts/extended-profile/"+this.props.profileId+"/albums"}>albums</a></li>
                <li className={(this.props.page === "Deck") ? "active" : ""}><a href={"/my-accounts/extended-profile/"+this.props.profileId+"/deck"}>Deck</a></li>
                <li className={(this.props.page === "Social") ? "active" : ""}><a href={"/my-accounts/extended-profile/"+this.props.profileId+"/social"}>Social</a></li>
                <li className={(this.props.page === "DeleteProfile") ? "active" : ""}><a href="#" onTouchTap={this.handleOpen}>DELETE MY PROFILE</a></li>
                <DialogConfirm open={this.state.confirmOpen} title={"Delete My Profile"} onSubmit={this.delete.bind(this,this.props.profileId)}
                body="Do you really want to delete this profile? Because the action is not reversible."
                onClose={this.handleClose}/>
            </ul>
        </div>
    );
    }
}
