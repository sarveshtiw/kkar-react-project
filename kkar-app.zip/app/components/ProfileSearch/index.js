import React from 'react';
import SelectField from 'material-ui/SelectField';
import MenuItem from 'material-ui/MenuItem';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
var util = require('utils/request');
import cookie from 'react-cookie';
import { API_URL } from 'containers/App/constants'
import FontIcon from 'material-ui/FontIcon';
var style1 = {
color:'#ffffff'
};
var style2 = {
    max_width: '100px'
};
var style3 = {
    width: 'auto',
position: 'relative'
}
const URL = 'http://52.66.48.222:8983/solr/search/select';
var slider = null;

export class ProfileSearch extends React.Component {
    constructor(props) {
        super(props);

        this.state = {searchbox:'',
          SortFilter:'id asc',
           SortTerm:2,
           data:[],
          SolrQuery: cookie.load('SolrQuery'),
          searchbox:'',
          nameOrder:'asc',
          likeOrder:'asc',
          ratingOrder:'desc',
          workrateOrder:'asc',
          workredOrder:'asc',
          idOrder:'asc',
          refineText:'',
          selectedUser:''
        }
    }

    showSlider(){
      this.showSlider1('.profile_rightBtm .bxslider');
    //  this.showSliderResponsive('.profile_rightTop .bxslider');//Responive Slider
    }

    showSlider1(cls){
      if(slider)
      {
        slider.reloadSlider();
        $('.bx-loading').removeClass('bx-loading');
        return;
      }
      slider = jQuery(cls).bxSlider({
            mode: 'vertical',
            slideWidth: 100,
            minSlides: 7,
            maxSlides: 7,
            slideMargin: 5,
            moveSlides: 7,
            //startSlide:0,
            touchEnabled: true,
            infiniteLoop : false
          //  hideControlOnEnd :true
        });
         $('.bx-loading').removeClass('bx-loading');
    }

    showSliderResponsive(cls){
      if(slider)
      {
        slider.reloadSlider();
        $('.bx-loading').removeClass('bx-loading');
        return;
      }
      slider = jQuery(cls).bxSlider({
          mode:'horizontal',
          slideWidth: 100,
          minSlides: 4,
          maxSlides: 4,
          slideMargin: 5,
          moveSlides: 1,
          touchEnabled: true,
          infiniteLoop: false
        });
         $('.bx-loading').removeClass('bx-loading');
    }


    SolrSearch(urls){
      cookie.save('SolrQuery', urls, { path: '/' });
      $.ajax({
          'url': urls,
          'success': function(data) {
              var queryparam = data.responseHeader.params.q;
              queryparam = queryparam.replace('%20',' ');
              queryparam = queryparam.replace('*','');
              this.setState({
                  data: data.response.docs,
                  proglob: data.response.numFound,
                  Qparam: queryparam,
                  searchbox: queryparam,
                  Loader:false,
              }) }.bind(this),
          'error': function(XMLHttpRequest, textStatus, errorThrown) {
              currenstate.setState({Loader:false});
          },
          'dataType': 'jsonp',
          'jsonp': 'json.wrf'
      });
    }

    componentDidMount() {
       var urls = this.state.SolrQuery;
        $.ajax({
         'url':urls,
          'success': function(data) {
           var queryparam = data.responseHeader.params.q;
           var queryparams = queryparam.slice(1);
             this.setState({
                 data: data.response.docs,
                 searchbox: queryparams,
             });
            for (var j = 0; j < data.response.docs.length; j++) {
              if(data.response.docs[j].id == this.props.profileId){
                this.setState({selectedUser : data.response.docs[j].id});
                break;
              }
            }
            //Show Seacrh params on Right-side slider

          this.setState({refineText : queryparams});
          this.showSlider();

         }.bind(this),
        'dataType': 'jsonp',
        'jsonp': 'json.wrf',
          });
      //  this.sortBy(null, null, 2);
      }

      sortBy(event,index, value) {
        var gender=this.state.genderfilter;
        var age= this.state.agefilter;
        var nameorder = this.state.nameOrder;
        var likeorder = this.state.likeOrder;
        var ratingorder = this.state.ratingOrder;
        var workredorder = this.state.workredOrder;
        var workrateorder = this.state.workrateOrder;
        var idorder = this.state.idOrder;
        var WorkRate = this.state.feefilter;
        var lang = this.state.languagefilter;
        var lang1 = this.state.languagefilter1;
        var SortF = this.state.SortFilter;
        var stateName = this.state.statefilter;
        var cityName = this.state.cityfilter;
        var avialdate = this.state.Avialdate;
        this.setState({SortTerm:value});


        if(value=='1'){SortF='Fullname '+nameorder;if(nameorder ==='asc'){this.setState({nameOrder:'desc'})} else {this.setState({nameOrder:'asc' });}}
        if(value=='2'){SortF='Rating '+ratingorder;if(ratingorder ==='asc'){this.setState({ratingOrder:'desc'})}else {this.setState({ratingOrder:'asc' });}}
        if(value=='3'){SortF='WorkRate '+workrateorder;if(workrateorder ==='asc'){this.setState({workrateOrder:'desc'})}else {this.setState({workrateOrder:'asc' });}}
        if(value=='4'){SortF='worckredTotal '+workredOrder;if(workredOrder ==='asc'){this.setState({workredOrder:'desc'})}else {this.setState({workredOrder:'asc' });}}
        if(value=='5'){SortF='id '+idorder;if(idorder ==='asc'){this.setState({idOrder:'desc'})}else {this.setState({idOrder:'asc' });}}
      if(value=='6'){SortF='likesTotal '+likeorder;if(likeorder ==='asc'){this.setState({likeOrder:'desc'})}else {this.setState({likeOrder:'asc' });}}
      var searchbox = this.state.searchbox;
      var queryS = '*'+searchbox.replace('%20',' ');
      var predefineArray = searchbox.split('%20');
      //fq=Gender:(computers OR phones);
      var toatalEle = predefineArray.length;
      var genRes='';
      var i;
      for (i = 0; i < toatalEle; i++) {
        if(predefineArray[i]=='male' || predefineArray[i]=='female' || predefineArray[i]=='other')
        {
          genRes = predefineArray[i];
          predefineArray.splice(i, 1);
      }
    }
    var Gend='';
    if(genRes=='male' || genRes=='female' || genRes=='other'){Gend ='&fq=Gender:'+ genRes; }
    var Query = '?q='+queryS+Gend+'&sort='+SortF+'&start=0&rows=1000&wt=json';
    var urls = URL+Query;
    cookie.save('SolrQuery', urls, { path: '/' });
     $.ajax({
      'url':urls,
       'success': function(data) {
        var queryparam = data.responseHeader.params.q;
        var queryparams = queryparam.slice(1);
              this.setState({
                data: data.response.docs,
                searchbox: queryparams,
                SortFilter:SortF,
            });
            this.showSlider();
           }.bind(this),
      'dataType': 'jsonp',
      'jsonp': 'json.wrf',
      });
    }



    searchprofiles(val, event) {
      if((event.keyCode == 13 && val === 'keydown') || val ==='click' || val === 'change'){
      var SortF = this.state.SortFilter;
      var nameorder = this.state.nameOrder;
      var likeorder = this.state.likeOrder;
      var ratingorder = this.state.ratingOrder;
      var workredOrder = this.state.workredOrder;
      var workrateorder = this.state.workrateOrder;
      var idorder = this.state.idOrder;
      this.setState({SortTerm:2});
      var searchbox = this.state.searchbox;

    var currenstate = this;
      var FQS = {action: 'Solr', SolrTerm: queryS};

      $.ajax({
          'url':API_URL,
          type: "POST",
          dataType: 'json',
          data: FQS,
          'success': function(data) {
                  var Query =data.query;
                  var urls = URL+Query+Gend+'&start=0&rows=5000&wt=json';
                  currenstate.setState({querystring:Query});
                  currenstate.SolrSearch(urls+'&sort=Rating desc');
                  currenstate.showSlider();
                }
            });

    }
  }

        changetext(event){
          this.setState({searchbox:event.target.value});
        }

        backPage(){
          var spliter = this.state.SolrQuery.split('Procat:');
          if(spliter.length > 1){
          var split0 = spliter[1].split("&");
           $(location).attr('href', '/search/'+split0[0]);
         }
         else {
           spliter = this.state.SolrQuery.split("q=*");
           var split0 = spliter[1].split("&");
            $(location).attr('href', '/search/'+split0[0]);
         }
    }

    render() {
        return (
                <div>
                    <div className="search_options">
                        <div className="search-form MultiFile-intercepted" method="get" role="search">
        <span className="search_box">
            <input type="text" className="search_profile" name="s"  value={this.state.searchbox} onChange={this.changetext.bind(this)} onKeyDown={this.searchprofiles.bind(this, 'keydown')} placeholder="New Search"
            />
          <input type="submit" className="profile_s_submit" onClick={this.searchprofiles.bind(this, 'click')}  value="submit"/>
            </span>
          </div>
    <span className="search_like"><p>{this.state.refineText}</p></span>
    <span className="sort_by_profile">
    <a href="javascript:void(0)" className="refine_search" onTouchTap={this.backPage.bind(this)}>Refine Search</a>
      <h3>Sort by</h3>
        <SelectField value={this.state.SortTerm}  onChange={this.sortBy.bind(this)} className='SearchSelectBox3'  menuStyle={style1}>

          <MenuItem value={1} primaryText='Name' rightIcon={ <FontIcon className="NameArrow"> <i className={(this.state.nameOrder==='asc' && this.state.SortTerm ===1)? "fa fa-angle-down": (this.state.SortTerm ===1)?"fa fa-angle-up":''} aria-hidden="true"></i></FontIcon>} />
          <MenuItem value={2} primaryText='Ratings' rightIcon={ <FontIcon className="NameArrow"> <i className={(this.state.ratingOrder==='asc' && this.state.SortTerm ===2)? "fa fa-angle-down": (this.state.SortTerm ===2)?"fa fa-angle-up":''} aria-hidden="true"></i></FontIcon>} />
          <MenuItem value={3} primaryText='Avg. Fee' rightIcon={ <FontIcon className="NameArrow"> <i className={(this.state.workrateOrder==='asc' && this.state.SortTerm ===3)? "fa fa-angle-down": (this.state.SortTerm ===3)?"fa fa-angle-up":''} aria-hidden="true"></i></FontIcon>}/>
          <MenuItem value={4} primaryText='Workcred' rightIcon={ <FontIcon className="NameArrow"> <i className={(this.state.workredOrder==='asc' && this.state.SortTerm ===4)? "fa fa-angle-down":(this.state.SortTerm ===4)?"fa fa-angle-up":'' } aria-hidden="true"></i></FontIcon>}/>
          <MenuItem value={5} primaryText='Newest' rightIcon={ <FontIcon className="NameArrow"> <i className={(this.state.idOrder==='asc' && this.state.SortTerm ===5)? "fa fa-angle-down": (this.state.SortTerm ===5)?"fa fa-angle-up":''} aria-hidden="true"></i></FontIcon>}/>
          <MenuItem value={6} primaryText='Likes' rightIcon={ <FontIcon className="NameArrow"> <i className={(this.state.likeOrder==='asc' && this.state.SortTerm ===6)? "fa fa-angle-down":(this.state.SortTerm ===6)?"fa fa-angle-up":''} aria-hidden="true"></i></FontIcon>}/>
        </SelectField>
    </span>
</div>
                    <div className="profile_search_result">

                    <ul className="bxslider">
                        {this.state.data.map(c =>
                          <li key={c.id} id={c.id} style={{position:'relative', margin:'10px 0'}}>
                              <a href={decodeURIComponent(c.proUrl)} className={this.state.selectedUser == c.id ? "active" : ''}>
                                <img src={(c.ProfilePic === undefined || c.ProfilePic === "" || c.ProfilePic=== null)? require('./no-img-pro.png') : c.ProfilePic}/>
                              <span className="hover_rating">
                                  <h3>{(c.Rating===undefined)? '0' : c.Rating}</h3>
                                  <p>INCRED RATING</p>
                            </span>
                            </a>
                          </li>)}
                      </ul>
                    </div>
                    </div>
                )}}
