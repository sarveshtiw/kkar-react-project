import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import {DashboardHeader} from 'components/DashboardHeader_Component';
import Img from 'components/Img';

import TextField from 'material-ui/TextField';
import ActionFavorite from 'material-ui/svg-icons/action/favorite';
import ActionFavoriteBorder from 'material-ui/svg-icons/action/favorite-border';
import FontIcon from 'material-ui/FontIcon';
import IconButton from 'material-ui/IconButton';
import ActionGrade from 'material-ui/svg-icons/action/grade';

export class BookmarkSearch extends React.Component {
    openRoute = (route) => {
        this.props.changeRoute(route);
    };
    render () {
        return (

<div className="container">
    <div className="dashBookmark">
        <div className="row">
            <div className="col-sm-6">
                <div className="search_bookmark">
                    <label>Search Bookmark</label>
                    <TextField hintText="eg: Name Profession, Tags, City" className="NormalInputTxt"/>
                    <a href="#" className="tooltip2" data-toggle="tooltip" data-placement="top" title="" data-original-title="Search Bookmar" aria-describedby="tooltip748746"><Img src={require('./img/icon-tooltip.png')} alt="kalakar"/></a>
                    <IconButton className="submit_book"></IconButton>
                </div>
            </div>
        </div>
    </div>
</div>
        )}}