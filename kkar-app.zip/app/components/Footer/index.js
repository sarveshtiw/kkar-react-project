import React from 'react';

import A from 'components/A';
import Img from 'components/Img';
import FooterLogo from './footer_logo.png';
// import style from './styles.css';
import cookie from 'react-cookie';
export default class Footer extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      user_id: cookie.load('userId')

    }
  }
  componentDidMount() {

  }
 openRegistration() {
    var userid = this.state.user_id;
    if(userid === undefined || userid === null || userid ===''){
      $('#loginform, #forgot_form').hide();
      $('#gh_login_form').show();
      $('#loginWrap').show();
      $('#loginWrap').toggleClass('fadeOutDown fadeInUp');

    }

  };


  render() {
  return (
    <footer className="site-footer">
    <div className="container">
      <div className="row">
      <div className="col-sm-2 logo">
      <a href="#"><Img src={FooterLogo} alt="kalakar - Logo"/></a>
      </div>
      <div className="col-sm-2 links">
        <h3>About Kalakar</h3>
        <ul>
        <li><a href="/page/about us">About Us</a></li>
        <li><a href="/page/news">News</a></li>
        <li><a href="/page/investors">Investors</a></li>
          <li><a href="/page/cintaa">CINTAA</a></li>
        <li><a href="/page/careers">Careers</a></li>
        <li><a href="/page/testimonials">Testimonials</a></li>
        <li><a href="/page/advertise">Advertise</a></li>
        <li><a href="/page/forums">Forums</a></li>
        <li><a href="/page/blog">Blog</a></li>
        </ul>
      </div>
      <div className="col-sm-2 knowMore">
        <h3>Know How</h3>
        <ul>
        <li><a href="#">How it works</a></li>
        <li><a href="#">Become an Affiliate</a></li>
          {this.state.userid === cookie.load('userId') &&
        <li><a href='javascript:void(0)' onClick={this.openRegistration.bind(this)}>Registration</a></li>}
        <li><a href="#">User Guide</a></li>
        <li><a href="#">Tools &amp; Apps</a></li>
        <li><a href="#">Site Map</a></li>
        </ul>
      </div>
      <div className="col-sm-2 help">
        <h3>Help</h3>
        <ul>
        <li><a href="#">Need Help</a></li>
        <li><a href="/ContactUs">Contact Us</a></li>
        <li><a href="/">Your Account</a></li>
        <li><a href="#">Privacy Policy</a></li>
        <li><a href="#">Feedback</a></li>
        </ul>
      </div>
      <div className="col-sm-2 pull_right">
        <span className="footer_social">
          <p>Kalakar App</p>
          <ul className="apps">
          <li><a href="#"><i className="fa fa-android"></i></a></li>
          <li><a href="#"><i className="fa fa-apple"></i></a></li>
          </ul>
          <p>Follow Us</p>
          <ul className="social">
          <li><a href="#"><i className="fa fa-instagram"></i></a></li>
          <li><a href="https://www.youtube.com/channel/UCUmtowDGi0VsFcfKo2s7Pkw"><i className="fa fa-youtube-play"></i></a></li>
          <li><a href="https://in.linkedin.com/in/kalakar-app-481a84111"><i className="fa fa-linkedin"></i></a></li>
          <li><a href="#"><i className="fa fa-google-plus"></i></a></li>
          <li><a href="https://www.facebook.com/kalakarapp"><i className="fa fa-facebook"></i></a></li>
          <li><a href="https://twitter.com/kalakarapp"><i className="fa fa-twitter"></i></a></li>
          </ul>
          <div className="footer_copyright">
          <p>&copy; 2016 Copyright InCred Private Limited.</p>
          </div>
        </span>
      </div>
      </div>
    </div>
    </footer>
  );
}}

export default Footer;
