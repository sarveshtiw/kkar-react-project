import React, { Component } from 'react';
import { DialogConfirm } from 'components/TagDelete';
var util = require('utils/request');
/**
 * Alerts are urgent interruptions, requiring acknowledgement, that inform the user about a situation.
 */
export class ExtendedPhotos extends React.Component {

  constructor(props) {
      super(props);
      this.state = {
        edittag:'',
        confirmOpen : false
      }
  }
  componentDidMount(){
    (function(jQuery){
        jQuery(".photo_right_gp").mCustomScrollbar({
            setHeight:435,
            theme:"dark-3"
          });    

    })(jQuery);
  }

  handleChange(event) {
     this.setState({edittag : event.target.value});
  };

  photoEdit(id){
    document.getElementById("tag"+id).disabled = false;
  }

   saveTag(e){
     var formState = this;
     if(e.keyCode == 13 || e.keyCode == undefined){
       var param = {action: 'editPhotos', profile_id: this.props.profile_id,photoId:this.props.photo.photo_id,photoTag:e.target.value}
       util.getSetData(param, function (data) {
           if (data.status == "success") {
               document.getElementById("tag" + formState.props.photo.photo_id).disabled = true;
           }
           else {
               console.log(data);
           }
       });

     }
     else{

     }
   }

    handleOpen() {
        this.setState({confirmOpen: true});
    }

    handleClose = () => {
        this.setState({confirmOpen: false});
    };

    handleDelete(photoId,formState){
      this.setState({confirmOpen: false});
      this.props.handleDelete(photoId,formState);
    }

    render() {

        return (
              <div className="albums-data__inner" id="photo-block1">
                  <div className="photo-block">
                      <div className="photo-block__img">
                          <img src={this.props.photo.photo_loc2} alt="" title="" className="img-responsive mCS_img_loaded"/>
                      </div>
                       <a href="javascript:void(0)" title="Delete"><span className="pic-delt" onTouchTap={this.handleOpen.bind(this)}></span></a>

                      <input type="text" id={"tag"+this.props.photo.photo_id} className="editbox" placeholder="Tag this photo, seperate tags by comma"
                      value={(this.state.edittag!=='')? this.state.edittag: this.props.photo.photo_tag} disabled="true"
                      onChange={this.handleChange.bind(this)} onBlur={this.saveTag.bind(this)}
                      onKeyDown = {this.saveTag.bind(this)} />

                      <span className="pic-edit" onClick={this.photoEdit.bind(this,this.props.photo.photo_id)}></span>
                  </div>
                  <DialogConfirm open={this.state.confirmOpen} title={"Delete Photos"} onSubmit={this.handleDelete.bind(this,this.props.photo.photo_id,this.props.formState)}
                  body="Do you really want to delete?"
                  onClose={this.handleClose}/>

            </div>
        );
    }
}
