import React from 'react';
import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
var util = require('utils/request');
import cookie from 'react-cookie';
import { API_URL } from 'containers/App/constants'

export class DraftMessages extends React.Component {
    openRoute = (route) => {
        this.props.changeRoute(route);
    };


    constructor(props) {
        super(props);
        this.state = {
            sender_fullname: '',
            show: false,
            user_info: [],
            isDisabled: this.props.isDisabled,
            user_id: cookie.load('userId'),

            profileName: '',
            fileList: [],
            open: false,
            searchData: [],
            form_data: {
                nature_of_message: " ",
                subject: "",
                sent_to: '',
                my_profile_id: '',
                message_description: "",
                display_status: 0,
                sender_profile_id: "",
                attached_doc_name: '',
                attach_doc: '',
                categoryList: [],
                file_data: [],
                attached_doc_name:'',
                attach_doc:''
            }
        }
    }

    componentWillReceiveProps(nextProps) {

        var message_id = nextProps.messageid;
        var param = {action: 'inbox_msg_details', message_id: message_id}
        var formState = this;
        util.getSetData(param, function (data) {

            if (data.status == "success") {

                formState.setState({
                    profileName: data.data.fullName,
                    form_data: {
                        message_id: message_id,
                        nature: data.data.nature_of_message,
                        cat_name: data.data.cat_name,
                        subject: data.data.subject,
                        message_description: data.data.message_description,
                        file_data: data.data.file_data,
                        sender_user_id: data.data.user_id,
                        sent_to: data.data.sent_to,
                        sProfile: data.data.my_profile_id,
                        Scat_name: data.data.Scat_name,
                        cate_id: data.data.cate_id,
                        categoryList: [{
                            profile_id: data.data.my_profile_id,
                            cat_name: data.data.cat_name
                        }],
                        attached_doc_name:'',
                        attach_doc:''
                    },

                });


            }

        });

    }

    componentDidMount() {
        var userid = this.state.user_id;
        var param = {action: 'myprofile', user_id: userid}
        var formState = this;
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                formState.setState({
                    user_info: data.Profilesdata
                });
            }
        });

    }

    handleFileUpload(e) {
        e.preventDefault();
        var photo = document.getElementById("photo");
        var file = photo.files[0];
        var fl = this.state.fileList;
        if (fl.length >= 4) {
            alert("You have exceeded the upload limit");
            return false;
        }
        fl.push(file);
        this.setState({fileList: fl});
        return false;
    }

    handleInputChange(name, e) {
        var change = {};
        change.form_data = this.state.form_data;
        change.form_data[name] = e.target.value;
        this.setState(change);

    }

    handleInputChange1(name, e) {
        var change = {};
        change[name] = e.target.value;
        this.setState(change);
        var ProfileName = e.target.value;
        var formState = this;
        if (ProfileName.length > 3) {
            var userid = this.state.user_id;
            var param = {action: 'circle_requests_search', user_id: userid, keywords: ProfileName};
            formState.setState({
                show: true
            });
            util.getSetData(param, function (data) {

                if (formState.state.show) {
                    var searchdata = data.data;
                    if (data.status == "success") {
                        formState.setState({
                            searchdata: data.data
                        });
                        $('#sent').show();
                    }
                }

            });
        }
        else {
            $('#sent').hide();
            formState.setState({
                show: false
            });

        }

    }


    onSelect(obj) {
        var change = this.state.form_data;
        change.sent_to = obj.user_id;
        change.categoryList = obj.category;
        this.setState({
            profileName: obj.user_name,
            searchdata: [],
            form_data: change
        });
        $('#sent').hide();

    }


    handleOptionChange1(name, e) {
        var change = {};
        change.form_data = this.state.form_data;
        change.form_data[name] = e.target.value;
        this.setState(change);

    }

    handleOptionChange(name, e) {
        var change = {};
        change.form_data = this.state.form_data;
        change.form_data[name] = e.target.value;
        this.setState(change);
        if (name == "sender_profile_id") {

        }
    }

    clear() {

        var change = this.state.form_data;
        change.nature_of_message ="";
        change.subject = "";
        change.message_description = "";
        change.sender_profile_id="";
        change.my_profile_id="";
        change.sent_to='';
        change.categoryList=[];
        this.setState({
            fileList:[],
            form_data: change,
            profileName:'',
            show:false,
            searchData:[]
        });
        $('#sent').hide();
        this.props.close();
    }

    delete(index) {
        var fl = this.state.fileList;
        fl.splice(index, 1);
        this.setState({
            fileList: fl
        });
    }

    save(name) {

        if (name == "draft") {
            this.state.form_data.display_status = 1;
        }
        if (name == "send") {
            this.state.form_data.display_status = 0;
        }
        var userid = this.state.user_id;
        this.state.form_data.action = 'send_new_msgs';
        this.state.form_data.user_id = userid;
        var param = this.state.form_data;
        var formState = this;
        var formData = new FormData();
        formData.append("action", "send_new_msgs");
        formData.append("my_profile_id", this.state.form_data.sProfile);
        formData.append("user_id", userid);
        formData.append("display_status", this.state.form_data.display_status);
        formData.append("nature_of_message", this.state.form_data.nature);
        formData.append("subject", this.state.form_data.subject);
        formData.append("sent_to", this.state.form_data.sent_to);
        formData.append("message_description", this.state.form_data.message_description);
        formData.append("sender_profile_id", this.state.form_data.cate_id);
       //// formData.append("file_data",this.state.form_data.file_data);
       // for (var i = 0; i < this.state.form_data.file_data.length; i++) {
       //     var fileName1 = this.state.form_data.file_data[i].name;
       //     var file1 = this.state.form_data.file_data[i];
       //     formData.append("attached_doc_name1[" + i + "]", fileName1);
       //     formData.append("attach_doc1[" + i + "]", file1);
       // }
        for (var i = 0; i < this.state.fileList.length; i++) {
            var fileName = this.state.fileList[i].name;
            var file = this.state.fileList[i];
            formData.append("attached_doc_name[" + i + "]", fileName);
            formData.append("attach_doc[" + i + "]", file);
        }
        $.ajax({
            url: API_URL,
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function (data) {

                formState.props.close();
                formState.clear();
            }.bind(this)

        });
    }


    render() {
        return (
            <Dialog
                title="New Message"
                autoDetectWindowHeight={true}
                modal={false}
                className="send_new_msg"
                titleClassName="send_head"
                bodyStyle={{padding:'0px',  fontSize: '15px'}}
                open={this.props.open}
                autoScrollBodyContent={true}>
                <div>


                    <div className="send_content">
                        <div className="row">
                            <div className="col-sm-4">

                                <input type="text" placeholder="To" className="input_form msg_to"
                                       value={this.state.profileName}
                                       onChange={this.handleInputChange1.bind(this,'profileName')}
                                    />
                                {( this.state.searchdata != undefined && this.state.searchdata != []) &&

                                <div id="sent" className="circleResults MsgNamesDrop ">
                                    <ul>
                                        {this.state.searchdata.map(s =>
                                                <li key={s.user_id}>
                                                    <div className="row">
                                                        <div className="col-md-8 col-xs-8"
                                                             onClick={this.onSelect.bind(this,s)}>
                                                            <span > {s.user_name}</span>
                                                        </div>
                                                    </div>
                                                </li>
                                        )}
                                    </ul>
                                </div>}
                            </div>

                            <div className="col-sm-2">

                                <select data-placeholder="Select" className="chosen-select msg_as" id="category_id"
                                        value={this.state.form_data.sProfile}
                                        onChange={this.handleOptionChange1.bind(this,'sProfile')}>
                                    <option value="">As</option>
                                    {this.state.form_data.categoryList.map((obj)=> {
                                        return <option value={obj.profile_id}
                                                       key={obj.profile_id}>{obj.cat_name}</option>
                                    })}
                                </select>
                                <small className="errorMsg">{this.state.sent_toerror_text}</small>
                            </div>
                            <div className="col-sm-6">
                                <select data-placeholder="Select" className="chosen-select msg_nature"
                                        value={this.state.form_data.nature}
                                        onChange={this.handleOptionChange.bind(this,'nature')}>
                                    <option value="">Nature of Message</option>
                                    <option value="General Query">General Query</option>
                                    <option value="Job Offer">Job Offer</option>
                                    <option value="Project Based">Project Based</option>
                                    <option value="Social Message">Social Message</option>
                                </select>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-sm-10">
                                <input type="text" placeholder="Subject" className="input_form msg_profile"
                                       value={this.state.form_data.subject}
                                       onChange={this.handleInputChange.bind(this,'subject')}
                                       onBlur={this.handleInputChange.bind(this,'subject')}/>
                                <small className="errorMsg">{this.state.error_text}</small>
                            </div>
                            <div className="col-sm-2">
                                <select data-placeholder="Select" className="chosen-select msg_select_p"
                                        value={this.state.form_data.cate_id}
                                        onChange={this.handleOptionChange.bind(this,'cate_id')}>
                                    <option value="">My Profile</option>
                                    {this.state.user_info != undefined && this.state.user_info.map((obj)=>
                                            <option key={obj.profile_id}
                                                    value={obj.profile_id}> {obj.category} </option>
                                    )}
                                </select>
                                <small className="errorMsg">{this.state.sendererror_text}</small>
                            </div>
                        </div>

                        <div className="row">
                            <div className="col-xs-12">
                <textarea name="message_description" id="message_description"
                          value={this.state.form_data.message_description}
                          onChange={this.handleInputChange.bind(this,'message_description')}
                          onBlur={this.handleInputChange.bind(this,'message_description')}>
                                              </textarea>
                                <small className="errorMsg">{this.state.error}</small>

                            </div>
                        </div>

                        <div className="row">
                            <div className="col-sm-6">

                                <div className="fileUploadFileName">
                                    {this.state.form_data.file_data.map((c,index) =>
                                        <span id="uploadFile">{c.name}<a href="javascript:void(0)" onClick={this.delete.bind(this, index)} >X</a>
                                            </span>)}


                                {this.state.fileList != undefined && this.state.fileList.map((file, index) =>
                                        <span id="uploadFile">{file.name}<a href="javascript:void(0)" onClick={this.delete.bind(this, index)} >X</a>
                                    </span>

                                )}

                            </div>

                            </div>
                            <div className="col-sm-6 rightAligh">
                                <button type="button" className="send_btn" onClick={this.save.bind(this,'send')}>Send
                                </button>
                                <button type="button" className="save_as" onClick={this.save.bind(this,'draft')}>save as
                                    draft
                                </button>


                                <div className="fileUploadMsg">
                                    <input type="file" name="photo" id="photo"
                                           onChange={this.handleFileUpload.bind(this)}/>

                                    <i className="fa fa-paperclip" aria-hidden="true"></i>

                                    <p>Attach File</p>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>
                <RaisedButton label="X" primary={true} className="cancelBtnPopup"
                              onTouchTap={this.clear.bind(this)}/>

            </Dialog>

        )
    }
}