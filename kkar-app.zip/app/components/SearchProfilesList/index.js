import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import {DashboardHeader} from 'components/DashboardHeader_Component';
import Img from 'components/Img';
import cookie from 'react-cookie';
import { API_URL } from 'containers/App/constants';
import {ShareComponent} from 'components/ShareComponent';
var util = require('utils/request');

export class SearchProfilesList extends React.Component {
    openRoute = (route) => {
        this.props.changeRoute(route);
    };

    constructor(props) {
        super(props);
        this.state =
        {
            user_id: cookie.load('userId'),
            likes_count: -1,
            openDialog: false,
            profile_url: ''
        }
    }

    bookmarkPro(profilid) {
        var userId = this.state.user_id;
        if (userId === undefined) {
            $('#loginWrap').show();
            $('#loginWrap').toggleClass('fadeOutDown fadeInUp');
        }
        var param = {action: 'bookmark', user_id: userId, profile_id: profilid};
        $.ajax({
            url: API_URL,
            type: "POST",
            dataType: 'json',
            data: param,
            success: function (data) {
                this.setState({bookmarkmsg: data.message, bookmarkID: data.profile_id});
                this.props.getBookmarkList();
            }.bind(this),
            error: function (err) {
            }
        });
    }

    shareUrl(id) {
        var param = {action: 'prourl', profile_id: id}
        var formState = this;
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                formState.setState({openDialog: true, profile_url: data.Prourl});
            }
        });
    }

    likePro(profilid) {
        var userId = this.state.user_id;
        if (userId === undefined) {
            $('#loginWrap').show();
            $('#loginWrap').toggleClass('fadeOutDown fadeInUp');
        }
        var param = {action: 'likes', user_id: userId, profile_id: profilid};
        $.ajax({
            url: API_URL,
            type: "POST",
            dataType: 'json',
            data: param,
            success: function (data) {
                if (data.code == 200) {
                    this.setState({
                        Likemsg: data.message,
                        likes_count: data.likes_count
                    })
                }
                else if (data.code == 201) {
                    this.setState({
                        likes_count: data.likes_count
                    })
                }

            }.bind(this),
            error: function (err) {
            }
        });
    }

    handleDialogClose = () => {
        this.setState({openDialog: false});
    };

    render() {

        var c = this.props.obj;

        var isBookmarked = this.props.isBookmarked(c.id);
        return (
            <li key={this.props.i}>
                <ShareComponent open={this.state.openDialog} close={this.handleDialogClose}
                                url={this.state.profile_url}/>


                <div className='inner'>
                    <div className='result_images'>
                        <a href={decodeURIComponent(c.proUrl)} >
                            <Img
                                src={(c.ProfilePic==='' || c.ProfilePic===undefined)? (c.ProfilePic1==='' || c.ProfilePic1===undefined)? (c.ProfilePic2==='' || c.ProfilePic2===undefined)?  require('./no-img-pro.png'): c.ProfilePic2 : c.ProfilePic1 : c.ProfilePic}
                                alt={(c.Firstname!=='' && c.Lastname)? c.Firstname + ' ' + c.Lastname: 'kalakar'}/>

                        </a>
                    </div>

                    <div className='result_info'>
                        <div className='result_upper'>
                            <a href={decodeURIComponent(c.proUrl)} >
                                <h3>{(c.Firstname !== '' && c.Lastname) ? c.Firstname + ' ' + c.Lastname : 'kalakar'}</h3>
                            </a>
                            <h4>{(c.Procat !== '') ? c.Procat : 'kalakar'}</h4>
                            <h4>{(c.CityName !== '') ? c.CityName : 'kalakar'}</h4>
                        </div>
                        <div className='result_upper'>

                              <span className='share_links'>
                                   <span className='p_share'><a href='javascript:void(0)'
                                                                onClick={this.shareUrl.bind(this, c.id)} title='Share'
                                                                data-toggle='tooltip'><i
                                       className='fa fa-share-alt'></i></a></span>
                                  <span className='p_like'>
                                      <a href='javascript:void(0);' className={(isBookmarked)? 'active':''}
                                         onClick={this.bookmarkPro.bind(this, c.id)}
                                         title={(isBookmarked)?"Bookmarked":"Bookmark"} data-toggle='tooltip'>
                                          <i className='fa fa-star'></i></a></span>

                                  <span className='p_like'><a href='javascript:void(0);'
                                                              onClick={this.likePro.bind(this, c.id)} title='Like'
                                                              data-toggle='tooltip'><i className='fa fa-heart'>
                                  </i></a><span> {this.state.likes_count == -1 ? c.likesTotal : this.state.likes_count} </span></span>
                            </span>
                              <span className='rating'>
                                  <h2>{(c.Rating !== '' ||c.rating!= undefined ||c.rating!= null ) ? c.Rating : '0'}</h2>
                                  <p>INCRED RATING</p>
                              </span>

                        </div>
                        <div className='result_upper'>
                              <span className='average'>
                                <p>Avg <strong><i className='fa fa-inr'></i> {(c.WorkRate !== '') ? c.WorkRate : '0'}
                                </strong></p>
                              </span>
                              <span className='workcred'>
                                <p>Work Cred <strong>{(c.worckredTotal !== '') ? c.worckredTotal : '0'}</strong></p>
                              </span>
                        </div>
                    </div>
                </div>
            </li>

        )
    }
}
