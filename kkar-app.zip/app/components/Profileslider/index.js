import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import {ViewEdit} from 'components/ViewEdit_Component';
var util = require('utils/request');


export class ProfileMainSlider extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            sliderData : []
        }
    }

    Slider(){
      $(function() {
          var Page = (function() {
              var $nav = $( '#nav-dots > span' ),
                  slitslider = $( '#slider' ).slitslider( {
                    autoplay: true,
                    interval: 6000,
                      onBeforeChange : function( slide, pos ) {
                          $nav.removeClass( 'nav-dot-current' );
                          $nav.eq( pos ).addClass( 'nav-dot-current' );
                      }
                  } ),
                  init = function() {
                        initEvents();
                    },
                  initEvents = function() {
                      $nav.each( function( i ) {
                          $( this ).on( 'click', function( event ) {
                              var $dot = $( this );
                              if( !slitslider.isActive() ) {
                                  $nav.removeClass( 'nav-dot-current' );
                                  $dot.addClass( 'nav-dot-current' );
                              }

                              slitslider.jump( i + 1 );
                              return false;
                          } );
                      } );
                  };
              return { init : init };
          })();
          Page.init();
      });
    }
    componentDidMount() {
      var sliderData = [];
        var param = {action: 'deckview', profile_id: this.props.profileId}
        var formState = this;
        util.getSetData(param, function (data) {
              if (data.status == "success") {
              if(data.slidesData != null & data.slidesData.length > 0){
                 formState.setState({sliderData : data.slidesData});
                  formState.Slider();
            }
         }
        });
    }

    render(){
      var formState = this;
      var showDeck = [];
      for (var i = 0; i < this.state.sliderData.length; i++) {
      var c = this.state.sliderData[i];
        if (c.slideOrigin == "photo") {
          var left = 0;
          var top = 0;
       if(c.T1possition != undefined && c.T1possition != null && c.T1possition != ""){
         var split = c.T1possition.split(",");
         var tansl = split[0].match(/translate/g);
         if(tansl===null){
            left = '';
            top = '';
         }else {
            left = split[0].replace('translate(',"");
            top = split[1].replace(')',"");
         }
       }


            showDeck.push(<div key={c.slideNo}
                className="sl-slide"
                data-orientation={c.rotation}
                data-slice1-rotation={-25}
                data-slice2-rotation={-25}
                data-slice1-scale={2}
                data-slice2-scale={2}>
                <div className="sl-slide-inner">
                    <div style={{backgroundImage:'url('+c.bgImg+')',height:'100%',width: '100%' }}/>

                    <h2 style={{fontFamily:c.T1font,position:'absolute',top:top,left:left,fontSize:c.T1fontsize+"px",color:c.T1color}}>
                        {c.T1}
                    </h2>
                    <blockquote>
                    <p style={{fontFamily:c.T2font, position:'absolute',top:"0px", transform: c.T2possition, fontSize:c.T2fontsize+"px", color:c.T2color}}>
                    {c.T2}</p>
                    <div style={{fontFamily:c.T3font, position:'absolute',top:"0px", transform: c.T3possition, fontSize:c.T3fontsize+"px", color:c.T3color}}>
                    {c.T3}</div></blockquote>
                </div>
            </div>);
        }
        else if(c.slideOrigin == "video"){
          showDeck.push(<div key={c.slideNo} className="sl-slide">
                  <iframe src={c.videolink+'?wmode=opaque&amp;rel=0&amp;autohide=1&amp;showinfo=0&amp;wmode=transparent'} width="100%" height="100%" frameBorder="0" allowFullScreen></iframe>
                </div>);

        }
      }
        return(
              <div className="demo-2 slSliderMain">
                 <div id="slider" className="sl-slider-wrapper">
                    <div className="sl-slider">
                     {showDeck}
                    <div>
                   </div>
                   <nav id="nav-dots" className="nav-dots">
                        {
                          this.state.sliderData.map(c =>
                         (c.slideNo === 1) ? <span className="nav-dot-current" key={c.slideNo}/> : <span key={c.slideNo}/>)
                        }
                 </nav>
              </div>


          </div>
      </div>
        )}}
