
import React from 'react';
import RaisedButton from 'material-ui/RaisedButton';
import TextField from 'material-ui/TextField';
import SelectField from 'material-ui/SelectField';
import MenuItem from 'material-ui/MenuItem';
import DatePicker from 'material-ui/DatePicker';
import Img from 'components/Img';
import FlatButton from 'material-ui/FlatButton';
//var Constant = require('containers/App/constants');
var util = require('utils/request');
import cookie from 'react-cookie';
import {PayNowDialog} from 'components/PayNowDialog_component'

export class DashboardClassifiedPopUp extends React.Component {
  constructor(props) {
      super(props);
      this.state = {
        user_id:cookie.load('userId'),
        open: true,
        payNowOpen:false,
        kalakarParentTypeData : [],
        kalakarChildTypeData : [],
        kalakarSubChildTypeData : [],
        form_data : {
        category_id : '',
        childCatId : '',
        parentCatID : '',
        schedule_work_dates : null,
        post_date : null,
        duration_of_work : '',
        avg_rate : '',
        location : '',
        title : '',
        post_description : ''
      }
    }
  }

getClassifiedData(classi_id) {
    var formState = this;
    var userid = this.state.user_id;
    var param = {action:'edit_classifieds',user_id: userid,classified_id : classi_id}
    util.getSetData(param,function (data) {
    formState.setState({ form_data : data.data[0] })
    if(data.data[0].parentCatID > 0){
      formState.handleParentChange("",data.data[0].parentCatID,data.data[0].parentCatID);
    }
    if(data.data[0].childCatId > 0){
      formState.handleChildChange("",data.data[0].childCatId,data.data[0].childCatId);
    }
    if(data.data[0].schedule_work_dates != null && data.data[0].schedule_work_dates != ""){
      var change = {};
      change.form_data = formState.state.form_data;
      change.form_data["schedule_work_dates"] = new Date(data.data[0].schedule_work_dates);
      formState.setState(change);
    }
    if(data.data[0].post_date != null && data.data[0].post_date != ""){
      var change = {};
      change.form_data = formState.state.form_data;
      change.form_data["post_date"] = new Date(data.data[0].post_date);
      formState.setState(change);
    }
  });
}

componentDidMount() {
   var formState = this;
   var kalakarTypeParam = {action:'get_parent_cat'}
   util.getSetData(kalakarTypeParam,function (data) {
   formState.setState({ kalakarParentTypeData : data.data })
  });

  if(this.props.classi_id != 0){
    this.getClassifiedData(this.props.classi_id);
  }
}

handleParentChange(event, index, value) {
  if(index > 0){
   var formState = this;
   var change = {};
   change.form_data = this.state.form_data;
   change.form_data["parentCatID"] = value;
   formState.setState(change);

   this.state.kalakarChildTypeData = [];
   this.state.kalakarSubChildTypeData = [];
   var param = {action:'get_child_cat',category:value}
   util.getSetData(param,function (data) {
   formState.setState({  kalakarChildTypeData : data.data })
  });
  }
 }

handleChildChange(event, index, value) {
    if(index > 0){
      var formState = this;
      var change = {};
      change.form_data = this.state.form_data;
      change.form_data["childCatId"] = value;
      formState.setState(change);

       formState.kalakarSubChildTypeData = [];
       var param = {action:'get_child_cat',category:value}
       util.getSetData(param,function (data) {
         formState.setState({ kalakarSubChildTypeData : data.data });
        });
     }
 }

 handleSubChildChange(event, index, value) {
    var change = {};
    change.form_data = this.state.form_data;
    change.form_data["category_id"] = value;
    this.setState(change);
     this.validateSelectProf();
  }

handleScheduleChange = (event, date) => {
  var change = {};
  change.form_data = this.state.form_data;
  change.form_data["schedule_work_dates"] = date;
  this.setState(change);
  this.validate2();
};

handlePostAdChange = (event, date) => {
  var change = {};
  change.form_data = this.state.form_data;
  change.form_data["post_date"] = date;
  this.setState(change);
    this.validate4();
};

handleChange(name, e) {
  var change = {};
  change.form_data = this.state.form_data;
  change.form_data[name] = e.target.value;;
  this.setState(change);
    if(name == 'duration_of_work'){
        this.validate1();
    }
    if(name == 'location'){
        this.validate3();
    }
    if(name == 'title'){
        this.validate5();
    }
    if(name == 'avg_rate'){
        this.validateRate();
    }



};

    validateRatereg(value) {
        var reg = /^\d+$/;
        return reg.test(value);
    }
validateRate() {
    let valid = false;
    if (this.state.form_data.avg_rate === "" || this.state.form_data.avg_rate === null || this.state.form_data.avg_rate === undefined) {
        this.setState({
            avg_rate_error_text: null
        });
    }
    else {
        if (this.validateRatereg(this.state.form_data.avg_rate)) {
            valid = true
            this.setState({
                avg_rate_error_text: null
            });
        }
        else {
            this.setState({
                avg_rate_error_text: "Please provide a number"
            });
        }
    }
    return valid;}

payNowHandleOpen = () => {
   this.setState({payNowOpen: true});
 };

payNowHandleClose = () => {
   this.setState({payNowOpen: false});
};

validateSelectProf() {
    let valid=false;
    if(this.state.form_data.category_id == ""){
        this.setState({
                category_id_text: "Required"
            }
        );

    } else {
        valid=true
        this.setState({
            category_id_text: null
        })

    }return valid;
}

validate1() {
    let valid=false;
    if(this.state.form_data.duration_of_work == ""){
        this.setState({
            error_text: "Required"
        });
    } else {
        valid=true
        this.setState({
            error_text: null
        })

    }return valid;
}

validate2() {
    let valid=false;
    if(this.state.form_data.schedule_work_dates == null){
        this.setState({
            schedule_work_dates_error_text: "Required"
        });
    } else {
        valid=true
        this.setState({
            schedule_work_dates_error_text: null
        })

    }return valid;
}

validate3() {
    let valid=false;
    if(this.state.form_data.location == ""){
        this.setState({
            location_error_text: "Required"
        });
    } else {
        valid=true
        this.setState({
            location_error_text: null
        })

    }return valid;
}

validate4() {
    let valid=false;
    if(this.state.form_data.post_date == null){
        this.setState({
            post_date_error_text: "Required"
        });
    } else {
        valid=true
        this.setState({
            post_date_error_text: null
        })

    }return valid;
}

validate5() {
    let valid=false;
    if(this.state.form_data.title == ""){
        this.setState({
            title_error_text: "Required"
        });
    } else {
        valid=true
        this.setState({
            title_error_text: null
        })

    }return valid;
}

submitData() {
    if(! (this.validateSelectProf() && this.validate1() && this.validate2() && this.validate3() && this.validate4() && this.validate5()
        && this.validateRate())){
        this.validateSelectProf();
        this.validate1();
        this.validate2();
        this.validate3();
        this.validate4();
        this.validate5();
        this.validateRate();
        return;
    }

  var formState = this;
  var userid = this.state.user_id;
  var sc_date = this.state.form_data.schedule_work_dates;
  this.state.form_data.schedule_work_dates = sc_date.getFullYear() + "/" + (sc_date.getMonth() + 1) + "/" + sc_date.getDate()
  var post_date = this.state.form_data.post_date;
  this.state.form_data.post_date = post_date.getFullYear() + "/" + (post_date.getMonth() + 1) + "/" + post_date.getDate()
  this.state.form_data.action = 'save_classifieds';
  this.state.form_data.user_id = userid;
  util.getSetData(this.state.form_data,function (data) {
  if(data.status == "success"){
     formState.props.close("SUCCESS");
    }
    else{
       alert("Please fill Manadatory fields.");
    }
  });
}

render() {
return(
<div className="classifiedPopup">
  <div className="">
  <ul>
     <li className="basic_profile">
        <p>Select Profession</p>
        <div className="h_col_4 col_common">
        	<div className="filter">
              <SelectField value={this.state.form_data.parentCatID} onChange={this.handleParentChange.bind(this)} maxHeight={180} fullWidth={true}>
                <MenuItem value="" primaryText="Type of Kalakar"/>
                {this.state.kalakarParentTypeData.map(s =>
                        <MenuItem value={s.category_id} key={s.category_name} primaryText={s.category_name} style={{cursor:'pointer'}}/>
                )}
              </SelectField>
          </div>
        </div>
          <div className="h_col_4 col_common">
  	     	<div className="filter">
              <SelectField value={this.state.form_data.childCatId} onChange={this.handleChildChange.bind(this)} maxHeight={180} fullWidth={true}>
                <MenuItem value="" primaryText="Select"/>
                {this.state.kalakarChildTypeData.map(s =>
                        <MenuItem value={s.category_id} key={s.category_name}
                                  primaryText={s.category_name} style={{cursor:'pointer'}}/>
                )}
              </SelectField>
  	        </div>
          </div>
          <div className="h_col_4 col_common">
  	     	<div className="filter">
              <SelectField value={this.state.form_data.category_id} onChange={this.handleSubChildChange.bind(this)} maxHeight={180} fullWidth={true}>
                <MenuItem value="" primaryText="Select Profession"/>
                {this.state.kalakarSubChildTypeData.map(s =>
                        <MenuItem value={s.category_id} key={s.category_name}
                                  primaryText={s.category_name} style={{cursor:'pointer'}}/>
                )}
              </SelectField>
                <small  className="errorMsg" style={{marginTop:'0px'}}>{this.state.category_id_text}</small>
  	        </div>
          </div>
          <a href="#" className="tooltip2" data-toggle="tooltip" data-placement="left" title="Select Profession">
          <Img src={require('./img/icon-tooltip.png')} alt="kalakar"/></a>
      </li>

      <li>
        <div className="h_col_4 col_common">
              <p>Avg Professional Fee</p>
              <TextField   hintText="Rs / Day" className="NormalInputTxt"
              value={this.state.form_data.avg_rate} onChange={this.handleChange.bind(this,'avg_rate')}/>

            <small className="errorMsg" style={{marginTop:'0px'}}>{this.state.avg_rate_error_text}</small>
           </div>
          <div className="h_col_4 col_common">
            <p>Duration of Work</p>
            <TextField hintText="No. of Days" className="NormalInputTxt"
            value={this.state.form_data.duration_of_work} onChange={this.handleChange.bind(this,'duration_of_work')}
               />
              <small className="errorMsg" style={{marginTop:'0px'}}>{this.state.error_text}</small>

          </div>
          <div className="h_col_4 col_common">
            <p>Scheduled Work Dates </p>
            <DatePicker hintText="Scheduled Work Dates" value={this.state.form_data.schedule_work_dates} autoOk = {true} container="inline"
            onChange={this.handleScheduleChange} className="date_pick hasDatepicker DatePicTxt"/>
              <small className="errorMsg" style={{marginTop:'0px'}}>{this.state.schedule_work_dates_error_text}</small>

          </div>

          <a href="#" className="tooltip2" data-toggle="tooltip" data-placement="left" title="Avg Professional Fee">
          <Img src={require('./img/icon-tooltip.png')} alt="kalakar"/></a>
       </li>

      <li>
        <div className="h_col_6 col_common">
              <p>Location of Work</p>
              <TextField hintText="eg: Mumbai" className="NormalInputTxt"
              value={this.state.form_data.location} onChange={this.handleChange.bind(this,'location')}/>
            <small className="errorMsg" style={{marginTop:'0px'}}>{this.state.location_error_text}</small>
          </div>
          <div className="h_col_6 col_common">
            <p>Post Ad Date</p>
              <DatePicker hintText="Post Ad Date" value={this.state.form_data.post_date} autoOk = {true} container="inline"
              onChange={this.handlePostAdChange} className="date_pick hasDatepicker DatePicTxt "/>
              <small className="errorMsg" style={{marginTop:'0px'}}>{this.state.post_date_error_text}</small>

          </div>
          <a href="#" className="tooltip2" data-toggle="tooltip" data-placement="left" title="Location of Work">
          <Img src={require('./img/icon-tooltip.png')} alt="kalakar"/></a>
      </li>

      <li>
        <div className="h_col_12 col_common">
              <p>Title of Classified Post <span>Max 75 Characters</span></p>
              <TextField  id="text-field2" hintText="Title of Classified Post" className="NormalInputTxt"
              value={this.state.form_data.title} onChange={this.handleChange.bind(this,'title')}/>
            <small className="errorMsg" style={{marginTop:'0px'}}>{this.state.title_error_text}</small>


          </div>
          <a href="#" className="tooltip2" data-toggle="tooltip" data-placement="left" title="Title of Classified Post">
          <Img src={require('./img/icon-tooltip.png')} alt="kalakar"/></a>
      </li>

      <li>
        <div className="h_col_12 col_common">
          <p>Text of Classified Post <span>Max 75 Characters</span></p>
          <TextField  id="text-field2" hintText="Title of Classified Post" className="TextareaTxt" multiLine={true} rows={5}
          value={this.state.form_data.post_description} onChange={this.handleChange.bind(this,'post_description')}/>
        </div>
         <a href="#" className="tooltip2" data-toggle="tooltip" data-placement="left" title="Text of Classified Post">
         <Img src={require('./img/icon-tooltip.png')} alt="kalakar"/></a>
      </li>
  </ul>
  <span className="add_classified_btn">
    <RaisedButton className="EditClissifieldBtn" onClick={this.submitData.bind(this)} primary={true} label="SAVE AS DRAFT"/>
    <RaisedButton className="profileEditbtn" onTouchTap={this.payNowHandleOpen} primary={true} label="PAY NOW"/>
    <RaisedButton className="cancelBtnPopup" onTouchTap={this.props.close} primary={true} label="X"/>
    <PayNowDialog open = {this.state.payNowOpen} close={this.payNowHandleClose}/>
  </span>

   </div> </div>
);
 }
}
