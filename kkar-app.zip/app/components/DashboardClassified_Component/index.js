/**
 * A link to a certain page, an anchor tag
 */
import React from 'react';
import Dialog from 'material-ui/Dialog';
import RaisedButton from 'material-ui/RaisedButton';
import {DashboardClassifiedPopUp} from 'components/DashboardClassifiedPopUp_Component';
import {ClassifiedAddEditDialog} from 'components/ClassifiedAddEditDialog_Component'

export class DashboardClassified extends React.Component {
    constructor(props) {
        super(props);
        this.state =
        {
            open: false
        }
    }

    handleOpen = () => {
        this.setState({open: true});
    };

    handleClose = (s) => {
        if (s == "SUCCESS") {
            this.props.close("SUCCESS");
            this.setState({open: false});
        }
        else {
            this.setState({open: false});
        }
    };

    render() {
        return (
            <li>
                <span className="classified_name"
                      data-title="Classifieds">{this.props.title + "-" + this.props.category_name}</span>
                <span className="classified_date" data-title="Date">{this.props.schedule_work_dates}</span>
                {(this.props.avg_rate === null || this.props.avg_rate === '' || this.props.avg_rate === undefined ) ?
                    <span className="classified_amount" data-title="Amount">&nbsp;</span> :
                    <span className="classified_amount" data-title="Amount">Rs. {this.props.avg_rate}</span>}
  <span className="classified_action" data-title="">
      <RaisedButton label={this.props.display_status} className="action_btn modalPopup" primary={true}
                    onTouchTap={this.handleOpen} className="EditClissifieldBtn"/>
  </span>
                <ClassifiedAddEditDialog title={"Edit Classified Ad"} classi_id={this.props.classi_id}
                                         stat={this.state.open} close={this.handleClose}/>
            </li>
        );
    }
}
