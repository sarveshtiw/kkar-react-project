import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import {DashboardHeader} from 'components/DashboardHeader_Component';
import Img from 'components/Img';
import cookie from 'react-cookie';
import { API_URL } from 'containers/App/constants';
import {ShareComponent} from 'components/ShareComponent';
var util = require('utils/request');
export class MessageSettings extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            rating: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20],
            parentCategory: [],
            child: [],
            subchild: [],
            checked: [],
            selectAll: false,
        }
    }

    componentDidMount() {
        var formState = this;
        var param = {action: 'get_home_cat'}
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                var checked = [];
                for (var i = 0; i <= data.subChild.length - 1; i++) {
                    checked.push(false);
                }

                formState.setState({
                    parentCategory: data.parent,
                    child: data.child,
                    subchild: data.subChild,
                    checked: checked
                });
               // console.log(checked);
            }
        })
    }

    handleSelectChange(e) {
        var change = {};
        change[name] = e.target.value;
        this.setState(change);

    }


    checkAll() {
        var checked = this.state.checked;
        var checkState = !this.state.selectAll;
        for (var i = 0; i < this.state.checked.length; i++) {
            checked[i] = checkState;
        }
        this.state.selectAll = checkState;
        this.setState({
            checked: checked, selectAll: this.state.selectAll
        })
    }


    handleChecked(i, name) {
       // console.log(i);
            var checked = this.state.checked;
        //console.log(checked);
            checked[i] = !checked[i];
            this.setState({checked: checked});
      //  console.log(this.state.checked);


        //var formState = this;
        //var param = {action: 'message_settings',origin:'sub_child',nchkd:''}
        //util.getSetData(param, function (data) {
        //    if (data.status == "success") {
        //
        //        }



        //})
}

    render() {
        var loopval = '';
        for (var i = 0; i <= 100; i++) {
            loopval += '<option value="' + i + '"">' + i + '</option>';
        }
        return (

            <div className="message-setting">
                <div className="msg-panel-heading">
                    <h1>Message Settings</h1>

                    <p>Select Professional categories to receive messages from
                        <span>And set Rating Filters for each professional category.</span>
                    </p>

                    <div className="today-text"/>
                    <div className="ir-text"><span /></div>
                </div>
                <div className="panel-group" id="accordion" role="tablist"
                     aria-multiselectable="true">
                    {this.state.parentCategory.map(c =>
                        <div className="panel panel-default">
                            <a role="button" data-toggle="collapse"
                               data-parent={c.category_id} href={"#col"+c.category_id} aria-expanded="true"
                               aria-controls="collapseOne" className>

                                <div className="panel-heading" role="tab" id={c.category_id}
                                     key={c.category_id}>
                                    <h4 className="panel-title">{c.category_name}</h4>
                                </div>
                            </a>

                            <p><a role="button" data-toggle="collapse"
                                  data-parent={"#accordion"+c.category_id} href={"#"+c.category_id}
                                  aria-expanded="false"
                                  aria-controls="collapseOne" className="collapsed"/></p>

                            <div id={"col"+c.category_id} className="panel-collapse collapse in"
                                 role="tabpanel" style={{position: 'relative'}}
                                 aria-labelledby="heading1" aria-expanded="true">
                                <div className="chkprnt">
                                    <div className="checkboxx">
                                        <div className="radio">
                                            <input type="checkbox"
                                                   className="checkparent1"
                                                   name={1} checked={this.state.selectAll}
                                                   onChange={this.checkAll.bind(this)}/><label><span />Set
                                            All</label></div>
                                    </div>
                                </div>

                                <div className="panel-body">

                                    <div className="row">
                                        {this.state.child[c.category_id].map(d =>
                                            <div key={d.category_id}
                                                 className="col-lg-3 col-md-4 col-sm-6 col-xs-12  message-setting-inner">
                                                <table className=" table-responsive">
                                                    <tbody>
                                                    <tr>
                                                        <th>{d.category_name}</th>
                                                        <th><span className="small-text">Set Rating</span>
                                                        </th>
                                                    </tr>
                                                    <tr>
                                                        <td />
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <div className="chkchild">
                                                                <div className="checkboxx">
                                                                    <div className="radio">
                                                                        <input type="checkbox"
                                                                               className="checkchild2 checkparent1"
                                                                               id={2 }
                                                                               checked={this.state.checked[i]}
                                                                            /><label><span />Set
                                                                        All</label></div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <select id="sel2"
                                                                    dangerouslySetInnerHTML={{__html: loopval}}>

                                                            </select>
                                                        </td>
                                                    </tr>
                                                    {this.state.subchild[d.category_id].map(L =>
                                                        <tr className="chksubchild">
                                                            <td key={L.category_id}>
                                                                <div className="checkboxx">
                                                                    <div className="radio">
                                                                        <input type="checkbox"
                                                                               className="checkchild2 checkparent1"
                                                                               id={3}
                                                                               checked={this.state.checked[i]}
                                                                               onChange={this.handleChecked.bind(this,L.category_id,'subchild')}
                                                                              />
                                                                        <label><span />
                                                                            {L.category_name}</label>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <select id="sel3"
                                                                        dangerouslySetInnerHTML={{__html: loopval}}>
                                                                </select>
                                                            </td>
                                                        </tr>)}

                                                    </tbody>
                                                </table>
                                            </div>)}

                                    </div>
                                </div>
                            </div>
                        </div>)}

                </div>
            </div>

        )
    }
}
