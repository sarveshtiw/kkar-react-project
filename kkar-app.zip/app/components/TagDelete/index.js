import React from 'react';
import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';

/**
 * Alerts are urgent interruptions, requiring acknowledgement, that inform the user about a situation.
 */
export class DialogConfirm extends React.Component {
    render() {
        return (
            <div>
              <Dialog className="pay-ads-pop tagDel" title={this.props.title} modal={false} open={this.props.open}>
                  <p>{this.props.body}</p><br/>
                  <RaisedButton label="Yes" primary={true} className="tagDelbtn" onTouchTap={this.props.onSubmit} />
                  <RaisedButton label="No" primary={true}  className="tagDelbtn" onTouchTap={this.props.onClose} />
                  <RaisedButton label="X" primary={true} className="cancelBtnPopup" onTouchTap={this.props.onClose}/>
              </Dialog>
            </div>
        );
    }
}
