import React from 'react';
import Dialog from 'material-ui/Dialog';
import RaisedButton from 'material-ui/RaisedButton';

export class ProfileView extends React.Component {

    constructor(props) {
        super(props);

        this.state = {

        }
    }

    initializeScroller(){
        jQuery(".profileLeftTabReapeat").mCustomScrollbar({
            setHeight:524,
            theme:"dark-3"
        });
    }

    render() {
        jQuery('.lightgallery-single-image').lightGallery();
        jQuery('.lightgallery-single-video').lightGallery();
        //this.initializeScroller();

        return (
            <div className="row profileLeftTabReapeat">
                <div className="col-sm-6 col-sm-6 col-xs-12">
                        <h5>{this.props.institute}</h5>
                        <p>{this.props.project_name}</p>
                        <p>{this.props.year}  {this.props.no_days} {this.props.duration}</p>
                    </div>
                <div className="col-md-6 col-sm-6 col-xs-12 ">
                    <ul>
                        {(this.props.hLink == "") ? "" :
                            <li><a href={this.props.hLink} target="_blank"><i className="fa fa-link" aria-hidden="true"></i></a></li>}

                        {(this.props.hVideo == 0 || this.props.hVideo == null ||this.props.hVideo == "") ? "" : <span className="lightgallery-single-video">
                       <li className="video" data-src={this.props.hVideo}>
                           <a href="#"> <i className="fa fa-play-circle-o" aria-hidden="true"></i></a></li></span>}
                        {(this.props.hPhoto == 0 ||this.props.hPhoto == null || this.props.hPhoto == "") ? "" : <span className="lightgallery-single-image">
                       <li className
                           data-src={this.props.hPhoto}><a href="#">
                           <i className="fa fa-clone" aria-hidden="true"></i></a></li></span>}
                    </ul>


                       </div>

                    </div>



        )};
}
