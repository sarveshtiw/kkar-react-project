import React from 'react';
import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
var util = require('utils/request');
import cookie from 'react-cookie';
import { API_URL } from 'containers/App/constants'

export class InboxMessages extends React.Component {
    openRoute = (route) => {
        this.props.changeRoute(route);
    };

    constructor(props) {
        super(props);
        this.state = {
            file_data: [],
            subpage: "main",
            replymessage:'',
            fileList:[],
            attached_doc_name:'',
            attach_doc:'',
            message1:''

        }

    }

    componentDidMount() {
      $('#incomingMsg11').mCustomScrollbar({
          setHeight: 152,
          theme: "dark-4"
      });

    }

    componentWillReceiveProps(nextProps) {
        var message_id = nextProps.messageid;
        var param = {action: 'inbox_msg_details', message_id: message_id}
        var formState = this;
        util.getSetData(param, function (data) {

            if (data.status == "success") {

                formState.setState({
                    message_id: message_id,
                    nature: data.data.nature_of_message,
                    cat_name: data.data.cat_name,
                    subject: data.data.subject,
                    message_description: data.data.message_description,
                    sender_first_name: data.data.first_name,
                    sender_last_name: data.data.last_name,
                    rating: (data.data.rating === null || data.data.rating === "" ||data.data.rating === undefined)?0:data.data.rating,
                    msg_count: data.data.msg_count,
                    useful_msg_count: data.data.useful_msg_count,
                    file_data: data.data.file_data,
                    photo: data.data.photo,
                    date: data.data.added_date,
                    sender_user_id: data.data.user_id,
                    my_user_id: data.data.sent_to,
                    Scate_name: data.data.Scat_name,
                    city: data.data.city
                });
            }
        });

        $('#incomingMsg').mCustomScrollbar({
            setHeight: 341,
            theme: "dark-4"
        });
    }

    blockUser() {
        var param = {action: 'block_user', user_id: this.state.my_user_id, block_user_id: this.state.sender_user_id}
        var formState = this;
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                formState.setState({
                    blockmessage: data.message

                });
                alert(formState.state.blockmessage);
            }
        })
    }
    handleInputChange( e) {
        this.setState({replymessage : e.target.value})

    }
    handleFileUpload(e) {
        e.preventDefault();
        var photo = document.getElementById("photo");
        var file = photo.files[0];
        var fl = this.state.fileList;
        if(fl.length >= 4) {
            alert("You have exceeded the upload limit");
            return false;
        }
        fl.push(file);
        this.setState({fileList:fl});
        return false;
    }
    delete(index){
        var fl = this.state.fileList;
        fl.splice(index, 1);
        this.setState({
            fileList: fl
        });
    }

    usefulMsg() {
        var param = {
            action: 'useful_msgs',
            message_id: this.state.message_id,
            user_id: this.state.my_user_id,
            useful_user_id: this.state.sender_user_id,
            useful_type: 'inbox',
            status: 1
        }
        var formState = this;
        util.getSetData(param, function (data) {

            if (data.status == "success") {

                formState.setState({message1:data.message});
                alert(formState.state.message1);
            }
        })
    }

    deleteMsg() {
        var param = {action: 'delete_messages', message_id: this.state.message_id}
        var formState = this;
        util.getSetData(param, function (data) {

            if (data.status == "success") {
                formState.props.inboxMsg();
                formState.props.close();


            }
        })
    }

    replyMessage() {
        this.setState({
            subpage: "reply"
        });

    }

    sendMessage() {
        var formData = new FormData();
        formData.append("action",  'reply_messages' );
        formData.append("reply_of",  this.state.message_id );
        formData.append('user_id', this.state.my_user_id);
        formData.append("message_description", this.state.replymessage);

        for(var i=0;i<this.state.fileList.length;i++) {
            var fileName = this.state.fileList[i].name;
            var file = this.state.fileList[i];
            formData.append("attached_doc_name["+i+"]", fileName);
            formData.append("attach_doc["+i+"]", file);
        }
        $.ajax({
            url: API_URL,
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function (data) {
                alert("message sent");
                this.setState({
                    subpage: "main"
                });
                this.props.inboxMsg();
                    this.props.close();

                $('#incomingMsg').mCustomScrollbar({
                    setHeight: 341,
                    theme: "dark-4"
                });
            }.bind(this)

        });


    }

    clear() {
        this.setState({
            subpage: "main"
        });
        this.props.close();

    }

    render() {
        $('#incomingMsg1').mCustomScrollbar({
            setHeight: 341,
            theme: "dark-4"
        });
        $('#incomingMsg2').mCustomScrollbar({
            setHeight: 341,
            theme: "dark-4"
        });

        $('#incomingMsg11').mCustomScrollbar({
            setHeight: 152,
            theme: "dark-4"
        });

        return (
            <Dialog
                autoDetectWindowHeight={true}
                modal={false}
                className="send_new_msg DetailMsgOuter"
                titleClassName="send_head"
                bodyStyle={{padding:'0px',  fontSize: '15px'}}
                open={this.props.open}
                autoScrollBodyContent={false}
                >
                <div>
                    <div className="send_head">
                        <div className="row">
                            <div className="col-xs-12">
                                <h2>
                                    <small> {this.state.nature} for {this.state.cat_name}</small>
                                    <small className="Date">{this.state.date}</small>
                                    <small><strong>{this.state.subject}</strong></small>
                                </h2>
                            </div>
                        </div>
                    </div>
                    <div className="table-responsive">
                    <div className="msgSec msgDetails">
                        {this.state.subpage == "main" &&
                        <div className="send_content leftSec">

                            <div className="row">
                                <div className="col-sm-12">
                                    <div id="incomingMsg1">
                                        <div contentEditable="false">
                                            {this.state.message_description}
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-md-12">
                                    <div className="col-sm-6 btnRow">
                                        <div className="fileUploadFileName OnlyShowAtt">
                                            {this.state.file_data.map(c =>
                                                <span id="uploadFile" key={c.location}>
                                           <a href={c.location}><i className="fa fa-paperclip"></i> {c.name} </a>
                                            </span>)}
                                        </div>
                                    </div>
                                    <div className="col-sm-6 btnRow">
                                        <div className="fltRight">
                                            <button type="submit" className="btn small red"
                                                    onClick={this.replyMessage.bind(this)}>Reply
                                            </button>
                                            <button type="submit" className="btn small grey"
                                                    onClick={this.deleteMsg.bind(this)}>Delete
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>}
                        {this.state.subpage == "reply" &&
                        <div className="send_content leftSec ReplyMessageInbox">
                            <div className="row">
                                <div className="col-sm-12">
                                    <div id="" className="Replayinner">
                                      <div id="incomingMsg11">
                                        <div contentEditable="false">
                                            {this.state.message_description}
                                        </div>
                                      </div>
                                        <div className="fileUploadFileName OnlyShowAtt">
                                            {this.state.file_data.map(c =>
                                                <span id="uploadFile" key={c.location}>
                                           <a href={c.location}><i className="fa fa-paperclip"></i> {c.name} </a>
                                            </span>)}
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <div className="row">
                                <div className="col-md-12">

                                    <div>
                                       <textarea placeholder=" Please Write Your Message here "  onChange={this.handleInputChange.bind(this)}
                                           style={{height: '100px '}}>
                                       </textarea>
                                    </div>
                                    <div className="col-sm-6 btnRow">

                                        <div className="fileUploadFileName">

                                            {this.state.fileList != undefined && this.state.fileList.map((file, index) =>
                                                    <span id="uploadFile">{file.name}<a href="javascript:void(0)" onClick={this.delete.bind(this, index)} >X</a>
                                    </span>

                                            )}
                                        </div>
                                    </div>

                                    <div className="col-sm-6 btnRow">
                                        <div className="fltRight">
                                            <button type="submit" className="btn small red"
                                                    onClick={this.sendMessage.bind(this)}>Send
                                            </button>
                                            <div className="fileUploadMsg">
                                                <input type="file" name="photo" id="photo" onChange={this.handleFileUpload.bind(this)}/>
                                                <i className="fa fa-paperclip" aria-hidden="true"></i>
                                                <p>Attach File</p>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div> }
                        <div className="rightSec">
                            <div className="proPic">
                                <img
                                    src={(this.state.photo === null ||this.state.photo === undefined
                                    ||this.state.photo === '')? require('./no-img-pro.png'):this.state.photo}
                                    width={183}
                                    height={104}
                                    alt/>
                            </div>
                            <h2>
                                {this.state.sender_first_name + ' ' + this.state.sender_last_name}&nbsp;
                            </h2>

                            <h3>
                                {this.state.Scate_name}&nbsp;
                            </h3>

                            <p className="location">
                                <i className="fa fa-map-marker"/> {this.state.city}
                            </p>

                            <p className="rating">
                                <strong>{this.state.rating}</strong>
                                <small>
                                    incred rating
                                </small>
                            </p>
                            <ul>
                                <li>
                                    Total Messages sent <em>{this.state.msg_count}</em>
                                </li>
                                <li>
                                    Professionally useful Messages <em>{this.state.useful_msg_count}</em>
                                </li>
                            </ul>
                            <div className="helpMsg">
                                <p>
                                    Was this Message<br /> Professionally useful
                                </p>
                                <button className="btn green small" onClick={this.usefulMsg.bind(this)}>Yes</button>
                                <button className="btn red small">No</button>
                                <button className="btn grey big" onClick={this.blockUser.bind(this)}>
                                    <i className="fa fa-ban"/> BLOCK THIS USER
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                    </div>


                <RaisedButton label="X" primary={true} className="cancelBtnPopup"
                              onTouchTap={this.clear.bind(this)}/>

            </Dialog>

        )
    }
}
