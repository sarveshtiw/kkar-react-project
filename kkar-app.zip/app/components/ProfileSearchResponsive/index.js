import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
var util = require('utils/request');
import cookie from 'react-cookie';
var style1 = {
        width: '100%',
        overflow: 'hidden',
        position: 'relative',
        height: '0px'
};
var style2 = {
    max_width: '100px'
};
var style3 = {
    width: 'auto',
position: 'relative'
}
const URL = 'http://52.66.48.222:8983/solr/search/select';
var flag = false;
var slider = null;

export class ProfileSearchResponsive extends React.Component {
    constructor(props) {
        super(props);

        this.state = {searchbox:'',
          SortFilter:'id asc',
           SortTerm:0,
           data:[],
          SolrQuery: cookie.load('SolrQuery'),
          searchbox:'',
          nameOrder:'asc',
          likeOrder:'asc',
          ratingOrder:'desc',
          workrateOrder:'asc',
          workredOrder:'asc',
          idOrder:'asc',
        }
    }

    showSlider(){
      this.showSliderResponsive('.profile_rightTop .bxslider');//Responive Slider
    }

    showSliderResponsive(cls){
      if(slider)
      {
        slider.reloadSlider();
        $('.bx-loading').removeClass('bx-loading');
        return;
      }
      slider = jQuery(cls).bxSlider({
          mode:'horizontal',
          slideWidth: 100,
          minSlides: 4,
          maxSlides: 4,
          slideMargin: 5,
          moveSlides: 1,
          touchEnabled: true,
          infiniteLoop: false
        });
         $('.bx-loading').removeClass('bx-loading');
    }
    componentDidMount() {
      // if(!flag)
      // {
      //   flag = true;
      //   return;
      // }
        var urls = this.state.SolrQuery;
        $.ajax({
         'url':urls,
          'success': function(data) {
           var queryparam = data.responseHeader.params.q;
                 this.setState({
                 data: data.response.docs,
                 searchbox: queryparams,
             });
             this.showSlider();
                //cookie.remove('SolrQuery', { path: '/' });
         }.bind(this),
        'dataType': 'jsonp',
        'jsonp': 'json.wrf',
          });
      }

    searchprofiles(val, event) {
      if((event.keyCode == 13 && val === 'keydown') || val ==='click' || val === 'change'){
      var SortF = this.state.SortFilter;
      var nameorder = this.state.nameOrder;
      var likeorder = this.state.likeOrder;
      var ratingorder = this.state.ratingOrder;
      var workredorder = this.state.workredOrder;
      var workrateorder = this.state.workrateOrder;
      var idorder = this.state.idOrder;
      this.setState({SortTerm:event.target.value});
      if(event.target.value=='1'){SortF='Fullname '+nameorder;if(nameorder ==='asc'){this.setState({nameOrder:'desc'})} else {this.setState({nameOrder:'asc' });}}
      if(event.target.value=='2'){SortF='Rating '+ratingorder;if(ratingorder ==='asc'){this.setState({ratingOrder:'desc'})}else {this.setState({ratingOrder:'asc' });}}
      if(event.target.value=='3'){SortF='WorkRate '+workrateorder;if(workrateorder ==='asc'){this.setState({workrateOrder:'desc'})}else {this.setState({workrateOrder:'asc' });}}
      if(event.target.value=='4'){SortF='worckredTotal '+worckredorder;if(worckredorder ==='asc'){this.setState({workredOrder:'desc'})}else {this.setState({workredOrder:'asc' });}}
      if(event.target.value=='5'){SortF='id '+nameorder;if(idorder ==='asc'){this.setState({idOrder:'desc'})}else {this.setState({idOrder:'asc' });}}
    if(event.target.value=='7'){SortF='likesTotal '+likeorder;if(likeorder ==='asc'){this.setState({likeOrder:'desc'})}else {this.setState({likeOrder:'asc' });}}
else {
  SortF='Rating desc';
  this.setState({SortTerm:2});
}
      var searchbox = this.state.searchbox;
      var queryS = '*'+searchbox.replace('%20',' ');
      var predefineArray = searchbox.split('%20');
      //fq=Gender:(computers OR phones);
      var toatalEle = predefineArray.length;
      var genRes='';
      var i;
      for (i = 0; i < toatalEle; i++) {
        if(predefineArray[i]=='male' || predefineArray[i]=='female' || predefineArray[i]=='other')
        {
          genRes = predefineArray[i];
          predefineArray.splice(i, 1);
      }
    }
    var Gend='';
    if(genRes=='male' || genRes=='female' || genRes=='other'){Gend ='&fq=Gender:'+ genRes; }
    var Query = '?q='+queryS+Gend+'&sort='+SortF+'&start=0&rows=1000&wt=json';
    var urls = URL+Query;
    cookie.save('SolrQuery', urls, { path: '/' });
     $.ajax({
      'url':urls,
       'success': function(data) {

        var queryparam = data.responseHeader.params.q;
        var queryparams = queryparam.slice(1);
              this.setState({
                data: data.response.docs,
                searchbox: queryparams,
                SortFilter:SortF,
            });
            console.log("####ShowSlider12");
            this.showSlider();
           }.bind(this),
      'dataType': 'jsonp',
      'jsonp': 'json.wrf',
      });
    }
  }

        changetext(event){
          this.setState({searchbox:event.target.value});
        }

    render() {
        return (
                <div>
                    <div className="search_options">
                        <div className="search-form MultiFile-intercepted" method="get" role="search">
        <span className="search_box">
            <input type="text" className="search_profile" name="s"  value={this.state.searchbox} onChange={this.changetext.bind(this)} onKeyDown={this.searchprofiles.bind(this, 'keydown')} placeholder="New Search"
            />
          <input type="submit" className="profile_s_submit" onClick={this.searchprofiles.bind(this, 'click')}  value="submit"/>
            </span>
          </div>
                        <span className="search_like"></span>
    <span className="sort_by_profile">
      <h3>Sort by</h3>
      <select value={this.state.SortTerm} onChange={this.searchprofiles.bind(this, 'change')}>
        <option value={0} >Sort</option >
        <option value={1} >Name</option >
        <option value={2} >Ratings</option >
        <option value={3} >Avg.Fee</option >
        <option value={4} >Workcred</option >
        <option value={5} >Newest</option >
        <option value={6} >Likes</option >
      </select>
    </span>
</div>
                    <div className="profile_search_result">

                    <ul className="bxslider">
                                              {this.state.data.map(c =>
                                                <li key={c.id} id={c.id} style={{position:'relative', margin:'10px 0'}}>
                                                    <a href={'/user-profile/'+c.id}>
                                                      <img src={(c.ProfilePic===undefined)? require('./no-img-pro.png') : c.ProfilePic}/>
                                                    <span className="hover_rating">
                                                        <h3>{(c.Rating===undefined)? '0' : c.Rating}</h3>
                                                        <p>INCRED RATING</p>
                                                  </span>
                                                  </a>
                                                </li>)}
                                            </ul>
                    </div>
                    </div>
                )}}
