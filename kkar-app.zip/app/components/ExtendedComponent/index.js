import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import {ProfileView} from 'components/ProfileView';
var util = require('utils/request');

export class ExtendedProfile extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            workcreddata: [],
            trainingdata: [],
            awards: [],
            linkdata: [],
            tagdata: [],
            //requestList: [],
            circledata: []
        }
    }

    initializeScroller(){
        jQuery(".profile_info_left .tab-pane, .custom-scroll").mCustomScrollbar({
            setHeight:494,
            theme:"dark-3"
        });
    }

    componentDidMount() {
        var formState = this; 
        var param = {action: 'about_get', profile_id: this.props.profileId}
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                var aboutdata = data.data.about_us;
		aboutdata = aboutdata.replace(new RegExp('\r\n', 'g'), '<br/>');
                var aboutdata1=  $("#intro p").html(aboutdata);
            }
        });

        jQuery('.profile_main_info ul.nav-tabs li a').click(function(){
          jQuery('.slSliderMain').hide();
          jQuery('.decHide').show();
          $(window).scrollTop(0);
         });

         jQuery('.decHide').click(function(){
           jQuery('.slSliderMain').show()
           jQuery('.decHide').hide()
         });


        param = {action: 'workcred_list', profile_id: this.props.profileId}

        util.getSetData(param, function (data) {
            if (data.status == "success") {
                if (data.data != null){
                formState.setState({workcreddata: data.data});
              }
            }
        });
        var param = {action: 'training_list', profile_id: this.props.profileId}
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                if (data.data != null) {
                    formState.setState({trainingdata: data.data});
                }
            }
        });
        param = {action: 'awards_list', profile_id: this.props.profileId}
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                if (data.data != null) {
                  formState.setState({awards: data.data});
              }
            }
        });
        var param = {action: 'link_list', profile_id: this.props.profileId}
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                if (data.data != null) {
                formState.setState({linkdata: data.data});
              }
            }
        });

        var param = {action: 'tags_list', profile_id: this.props.profileId}
        //var formState = this;
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                if (data.data != null) {
                formState.setState({
                    tagdata: data.data
                })}
            }
        });

        var param = {action: 'circle_approved', profile_id: this.props.profileId}
        util.getSetData(param, function (data) {
            if (data.status == "success") {
            if (data.data != null) {
                formState.setState({
                    circledata: data.data
                })
            }}
        });

    }

    render() {
        this.initializeScroller();
        var local = this;
        return (
            <div className="col-lg-6">
                <div className="profile_info_left">
                  <div className="profileinfomenu">
                    <ul className="nav nav-tabs" role="tablist">
                        <li role="presentation" className="active">
                            <a style={this.props.style}
                               href="#intro"
                               aria-controls="intro"
                               role="tab"
                               data-toggle="tab">Intro</a>
                        </li>
                        <li role="presentation">
                            <a style={this.props.style}
                               href="#workcred"
                               aria-controls="workcred"
                               role="tab"
                               data-toggle="tab">Workcred</a>
                        </li>
                        <li role="presentation">
                            <a style={this.props.style}
                               href="#training"
                               aria-controls="training"
                               role="tab"
                               data-toggle="tab">Training</a>
                        </li>
                        <li role="presentation">
                            <a style={this.props.style}
                               href="#awards"
                               aria-controls="awards"
                               role="tab"
                               data-toggle="tab">Awards</a>
                        </li>
                        <li role="presentation">
                            <a style={this.props.style}
                               href="#links"
                               aria-controls="links"
                               role="tab"
                               data-toggle="tab">Links</a>
                        </li>
                        <li role="presentation">
                            <a style={this.props.style}
                               href="#tags"
                               aria-controls="tags"
                               role="tab"
                               data-toggle="tab">Tags</a>
                        </li>
                        <li role="presentation">
                            <a style={this.props.style}
                               href="#circle"
                               aria-controls="circle"
                               role="tab"
                               data-toggle="tab">Circle</a>
                        </li>
                    </ul>
                    </div>
                    <div className="tab-content">
                        <div
                            role="tabpanel"
                            className="tab-pane active"
                            id="intro">
                            <p></p>
                        </div>
                        <div
                            role="tabpanel"
                            className="tab-pane wordcreed_data"
                            id="workcred">
                         <div className="custom-scroll">
                            {this.state.workcreddata.map(function (obj, i) {
                                return <ProfileView key={obj.id_workcred} id_workcred={obj.id_workcred}
                                                    institute={obj.worked_as}
                                                    project_name={obj.project_name}
                                                    year={obj.year_of_project + " | "}
                                                    no_days={obj.number_of_days_workcred} duration="Days"
                                                    hPhoto={obj.photourl} hVideo={obj.work_video}
                                                    hLink={obj.work_link}
                                    />
                            })}
                            </div>

                        </div>
                        <div role="tabpanel"
                             className="tab-pane wordcreed_data"
                             id="training">

                         <div className="custom-scroll">
                            {local.state.trainingdata.map(function (object, i) {
                                return <ProfileView key={i} institute={object.institute_name}
                                                    project_name={object.nature_of_training}
                                                    year={object.year_of_training + " | "}
                                                    no_days={object.number_of_days}
                                                    duration={object.duration_in}
                                                    hPhoto={object.photourl}
                                                    hVideo={object.education_video}
                                                    hLink={object.education_link} showEdit={false}/>
                            })}
                         </div>
                        </div>
                        <div
                            role="tabpanel"
                            className="tab-pane wordcreed_data"
                            id="awards">
                        <div className="custom-scroll">
                            {this.state.awards.map(function (obj, i) {
                                return <ProfileView key={i} award_id={obj.award_id}
                                                    institute={obj.award_name}
                                                    project_name={obj.award_for}
                                                    year={obj.year_of_award}
                                                    hPhoto={obj.photourl} hVideo={obj.award_video}
                                                    hLink={obj.award_link}
                                                    showEdit={false}/>
                            })}
                          </div>
                        </div>
                        <div
                            role="tabpanel "
                            className="tab-pane linkListing "
                            id="links">
                            <ul>
                                {this.state.linkdata.map(l =>

                                        <li key={l.id_link}>
                                               <span>
                                                 <a href={l.link} target="_blank">{l.link}</a>
                                                <p>{l.about_link}</p>
                                               </span></li>
                                )}
                            </ul>
                        </div>
                        <div
                            role="tabpanel"
                            className="tab-pane"
                            id="tags">
                            <div className="tagsItems marginTopBott4">
                                <ul>
                                    {this.state.tagdata.map(t =>
                                            <li key={t.id_tags}>
                                                {t.tags}
                                            </li>
                                    )}
                                </ul>
                            </div>
                        </div>
                        <div
                            role="tabpanel"
                            className="tab-pane"
                            id="circle">
                            <div className="circle_con_details">
                                <h2>
                                    Circle of Peers
                                </h2>
                                <ul>
                                    {local.state.circledata.map(c =>
                                        <li key={c}>
                                            <div className="left_circle_detail"></div>
                                            <div className="right_circle_detail">
                                                <div className="d_circle_text">{c.description}
                                                </div>
                                                <div className="d_circle_info">
                                                    <div className="left_info_c">
                                                    <span className="image_c"><img src={c.photo_url}
                                                                                   className="mCS_img_loaded"/></span>
                                          <span className="other_c">
                                              <h2>{c.name}</h2>
                                              <h3>{c.category_name}</h3>
                                              <span
                                                  className="rating"><strong>{c.rating_point} </strong>Incred Rating</span>
                                          </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>)}
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        )
    }


}
