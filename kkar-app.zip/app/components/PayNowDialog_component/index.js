/**
* A link to a certain page, an anchor tag
*/
import React from 'react';
import Dialog from 'material-ui/Dialog';
import RaisedButton from 'material-ui/RaisedButton';


export class PayNowDialog extends React.Component {
render() {
return(
      <Dialog
      className="pay-ads-pop"
         modal={false} open = {this.props.open} autoScrollBodyContent={true}>
        <div className="pay_ads_con">
          <p>Your Classified Ad has been forwarded to the Kalakar Team for review.</p>
          <p>On an average a review takes 1 working day.
          If your Classified Ad doesn''t pass our review someone shall contact you,
          and you will not be charged.</p>
          <h2>Rs <span>499</span>/-</h2>
          <input type="button" className="pay_now" value="Pay Now" id="classified_pay_now" onTouchTap={this.props.close}/>
          <RaisedButton className="cancelBtnPopup" onTouchTap={this.props.close} primary={true} label="X"/>
        </div>
  </Dialog>
 );
}
}
