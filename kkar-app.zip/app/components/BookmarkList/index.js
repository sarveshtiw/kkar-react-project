import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import {DashboardHeader} from 'components/DashboardHeader_Component';
import Img from 'components/Img';
import cookie from 'react-cookie';
import { API_URL } from 'containers/App/constants';
import {ShareComponent} from 'components/ShareComponent';
var util = require('utils/request');

export class BookmarkList extends React.Component {
    openRoute = (route) => {
        this.props.changeRoute(route);
    };
    constructor(props) {
        super(props);
        this.state =
        {likes_count:-1,
            user_id: cookie.load('userId'),
            openDialog:false,
            likes_count : this.props.bookmark.likes_count

        }
    }

    bookmarkPro(){
        this.props.profileBookmark(this.props.profile_id,this.props.formstate);
    }

    likePro(){
        var userId = this.state.user_id;
        var param = {action:'likes', user_id:userId, profile_id:this.props.profile_id};
        $.ajax({
            url: API_URL,
            type: "POST",
            dataType: 'json',
            data: param,
            success: function (data) {
                this.setState({Likemsg : data.message, LikeID : data.profile_id,likes_count: data.likes_count});
                alert(this.state.Likemsg)
            }.bind(this),
            error: function (err) {
            }
        });
      }

    shareUrl(){
        var param = {action: 'prourl', profile_id: this.props.profile_id}
        var formState = this;
        util.getSetData(param, function (data) {
            if (data.status == "success") {
                formState.setState({openDialog: true,profile_url : data.Prourl});
            }
            else {
                alert("Please try again.");
            }
        });
    }

    handleDialogClose = () => {
        this.setState({openDialog: false});
    };

    render() {

        return (

            <li>
                <div className="inner">
                    <div className="result_images">
                        <a href={this.props.bookmark.proUrl}>

                            <Img src={(this.props.bookmark.photo === null ||this.props.bookmark.photo === undefined
                            ||this.props.bookmark.photo === '')? require('./no-img-pro.png'):this.props.bookmark.photo} alt={this.props.bookmark.full_name}/></a>
                    </div>

                    <div className="result_info">
                        <div className="result_upper">
                            <a href={this.props.bookmark.proUrl}><h3>{this.props.bookmark.full_name}</h3></a>
                            <h4>{this.props.bookmark.categoryname}</h4>
                            <h4>{this.props.bookmark.city_name}</h4>
                        </div>

                        <div className="result_upper">
                              <span className="share_links">
                                  <span className="p_share">
                                    <a href="javascript:void(0)" title="Share" data-toggle="tooltip" onClick={this.shareUrl.bind(this)}>
                                    <i className="fa fa-share-alt"></i></a>
                                  </span>
                                  <span className="p_like">
                                       <a href="javascript:void(0);" className="active" onClick={this.bookmarkPro.bind(this)} title="Bookmarked" data-toggle="tooltip">
                                       <i className="fa fa-star"></i></a>
                                  </span>
                                  <span className="p_like">
                                       <a href="javascript:void(0);" onClick={this.likePro.bind(this)} title="Like" data-toggle="tooltip">
                                       <i className="fa fa-heart"></i></a>
                                       <span>{this.state.likes_count == -1  ? this.props.bookmark.likes_count :  this.state.likes_count}</span>
                                  </span>
                              </span>

                              <span className="rating">
                                  <h2>{this.props.bookmark.rating}</h2>
                                  <p>INCRED RATING</p>
                              </span>
                        </div>

                        <div className="result_upper">
                              <span className="average">
                                <p>Avg <strong><i className="fa fa-inr"></i> {this.props.bookmark.work_rate}</strong></p>
                              </span>
                              <span className="workcred">
                                <p>Work Cred <strong>{this.props.bookmark.Workcred}</strong></p>
                              </span>
                        </div>

                    </div>
                </div>
                <ShareComponent open={this.state.openDialog} close={this.handleDialogClose} url = {this.state.profile_url}/>

            </li>

        )
    }
}
