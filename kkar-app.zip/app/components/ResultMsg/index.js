import React from 'react';
import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';

/**
 * Alerts are urgent interruptions, requiring acknowledgement, that inform the user about a situation.
 */
export class ResultMsg extends React.Component {


  handleClose = () => {
      if(this.props.redDirect){
      this.props.openState.setState({resultDialogOpen: false});
         this.props.dashboard();
      }
      else{
          this.props.openState.setState({resultDialogOpen: false});
      }
  };

    render() {
        return (
            <div>
                <Dialog modal={false} open={this.props.open} onRequestClose={this.handleClose} autoScrollBodyContent={true}>
                     <div style={{textAlign:"center"}}>
                         <p>{this.props.body}</p><br />
                         <RaisedButton className="profileEditbtn" primary={true} label="OK" onTouchTap={this.handleClose.bind(this)}/>
                         <RaisedButton className="cancelBtnPopup" onTouchTap={this.handleClose.bind(this)} primary={true} label="X"/>
                     </div>
                 </Dialog>
            </div>
        );
    }
}
