// These are the pages you can go to.
// They are all wrapped in the App component, which should contain the navbar etc
// See http://blog.mxstbr.com/2016/01/react-apps-with-pages for more information
// about the code splitting business
import {
  getAsyncInjectors,
} from './utils/asyncInjectors';

const errorLoading = (err) => {
  console.error('Dynamic page loading failed', err); // eslint-disable-line no-console
};

const loadModule = (cb) => (componentModule) => {
  cb(null, componentModule.default);
};

export default function createRoutes(store) {
  // create reusable async injectors using getAsyncInjectors factory
  const {
    injectReducer,
    injectSagas,
  } = getAsyncInjectors(store);
  return [{
    path: '/',
    name: 'home',
    getComponent(nextState, cb) {
      const importModules = Promise.all([
        System.import('containers/HomePage/reducer'),
        System.import('containers/HomePage/sagas'),
        System.import('containers/HomePage'),
      ]);
      const renderRoute = loadModule(cb);
      importModules.then(([reducer, sagas, component]) => {
        injectReducer('home', reducer.default);
        injectSagas(sagas.default);
        renderRoute(component);
      });
      importModules.catch(errorLoading);
    },
  },
  {
    path: '/features',
    name: 'features',
    getComponent(nextState, cb) {
      System.import('containers/FeaturePage')
      .then(loadModule(cb))
      .catch(errorLoading);
    },
  },
  {
    path: '/page*',
    name: 'page',
    getComponent(nextState, cb) {
      System.import('containers/Page')
      .then(loadModule(cb))
      .catch(errorLoading);
    },
  },

  {
    path: '/emailVerification',
    name: 'emailVerification',
    getComponent(nextState, cb) {
      System.import('containers/emailVerification')
      .then(loadModule(cb))
      .catch(errorLoading);
    },
  },
  {
    path: '/my-accounts',
    name: 'my-accounts',
    getComponent(nextState, cb) {
      System.import('containers/EditBasicProfile')
      .then(loadModule(cb))
      .catch(errorLoading);
    },
  },
  {
    path: '/my-dashboard/bookmarks',
    name: 'bookmarks',
    getComponent(nextState, cb) {
      System.import('containers/Bookmark')
      .then(loadModule(cb))
      .catch(errorLoading);
    },
  },
    {
      path: '/my-dashboard/analytics',
      name: 'analytics',
      getComponent(nextState, cb) {
        System.import('containers/Analytics')
            .then(loadModule(cb))
            .catch(errorLoading);
      },
    },
  {
    path: '/my-dashboard',
    name: 'mydashboard',
    getComponent(nextState, cb) {
      System.import('containers/DashBoard')
      .then(loadModule(cb))
      .catch(errorLoading);
    },
  },
  {
    path: '/my-dashboard/classifieds',
    name: 'dashboardclassifieds',
    getComponent(nextState, cb) {
      System.import('containers/DashBoardClassifieds')
      .then(loadModule(cb))
      .catch(errorLoading);
    },
  },
  {
    path: '/my-dashboard/calendar',
    name: 'dashboardcalendar',
    getComponent(nextState, cb) {
      System.import('containers/DashBoardCalendar')
      .then(loadModule(cb))
      .catch(errorLoading);
    },
  },
  {
    path: '/my-dashboard/orders',
    name: 'dashboardorders',
    getComponent(nextState, cb) {
      System.import('containers/DashBoardOrders')
      .then(loadModule(cb))
      .catch(errorLoading);
    },
  },
  {
    path: '/affiliate',
    name: 'dashboardaffiliate',
    getComponent(nextState, cb) {
      System.import('containers/DashBoardAffiliate')
      .then(loadModule(cb))
      .catch(errorLoading);
    },
  },
  {

    path: '/my-accounts/extended-profile/:profileId/basic',
    name: 'profilebasics',
    getComponent(nextState, cb) {
      System.import('containers/ProfileBasics')
      .then(loadModule(cb))
      .catch(errorLoading);
    },
  },
  {
    path: '/my-accounts/extended-profile/:profileId/training',
    name: 'training',
    getComponent(nextState, cb) {
      System.import('containers/Training')
      .then(loadModule(cb))
      .catch(errorLoading);
    },
  },
  {
    path: '/search*',
    name: 'search',
    getComponent(nextState, cb) {
      System.import('containers/Search')
      .then(loadModule(cb))
      .catch(errorLoading);
    },
  },
  {
    path: '/Bookmarks',
    name: 'Bookmarks',
    getComponent(nextState, cb) {
      System.import('containers/Bookmark')
      .then(loadModule(cb))
      .catch(errorLoading);
    },
  },
  {
    path: '/my-accounts/extended-profile/:profileId/details',
    name: 'contacts',
    getComponent(nextState, cb) {
      System.import('containers/DashboardContactdetails')
      .then(loadModule(cb))
      .catch(errorLoading);
    },
  },
  {
    path: '/my-accounts/extended-profile/:profileId/awards',
    name: 'awards',
    getComponent(nextState, cb) {
      System.import('containers/Awards')
      .then(loadModule(cb))
      .catch(errorLoading);
    },
  },
  {
    path: '/my-accounts/extended-profile/:profileId/workcred',
    name: 'workcred',
    getComponent(nextState, cb) {
      System.import('containers/Workcred')
      .then(loadModule(cb))
      .catch(errorLoading);
    },
  },
  {
    path: '/my-accounts/extended-profile/:profileId/intro',
    name: 'intro',
    getComponent(nextState, cb) {
      System.import('containers/Intro')
      .then(loadModule(cb))
      .catch(errorLoading);
    },
  },
  {
    path: '/my-accounts/extended-profile/:profileId/links',
    name: 'links',
    getComponent(nextState, cb) {
      System.import('containers/Links')
      .then(loadModule(cb))
      .catch(errorLoading);
    },
  },
  {
    path: '/my-accounts/extended-profile/:profileId/photos',
    name: 'links',
    getComponent(nextState, cb) {
      System.import('containers/Photos')
      .then(loadModule(cb))
      .catch(errorLoading);
    },
  },
    {
      path: '/my-accounts/extended-profile/:profileId/albums',
      name: 'album',
      getComponent(nextState, cb) {
        System.import('containers/Album')
            .then(loadModule(cb))
            .catch(errorLoading);
      },
    },
    {
      path: '/my-accounts/extended-profile/:profileId/deck',
      name: 'deck',
      getComponent(nextState, cb) {
        System.import('containers/Deck')
            .then(loadModule(cb))
            .catch(errorLoading);
      },
    },
  {
    path: '/my-dashboard/orders',
    name: 'orders',
    getComponent(nextState, cb) {
      System.import('containers/DashBoardOrders')
      .then(loadModule(cb))
      .catch(errorLoading);
    },
  },
  {
    path: '/my-dashboard/affiliate',
    name: 'orders',
    getComponent(nextState, cb) {
      System.import('containers/DashBoardAffiliate')
      .then(loadModule(cb))
      .catch(errorLoading);
    },
  },
  {
    path: '/my-accounts/extended-profile/:profileId/social',
    name: 'social',
    getComponent(nextState, cb) {
      System.import('containers/Social')
      .then(loadModule(cb))
      .catch(errorLoading);
    },
  },
  {
    path: '/my-accounts/extended-profile/:profileId/tags',
    name: 'tags',
    getComponent(nextState, cb) {
      System.import('containers/Tags')
      .then(loadModule(cb))
      .catch(errorLoading);
    },
  },
  {
    path: '/my-accounts/extended-profile/:profileId/circle',
    name: 'circle',
    getComponent(nextState, cb) {
      System.import('containers/Circle')
      .then(loadModule(cb))
      .catch(errorLoading);
    },
  },
  {
    path: '/my-accounts/extended-profile/:profileId/video',
    name: 'video',
    getComponent(nextState, cb) {
      System.import('containers/Video')
      .then(loadModule(cb))
      .catch(errorLoading);
    },
  },
  {
    path: '/verification',
    name: 'verification',
    getComponent(nextState, cb) {
      System.import('containers/verification')
      .then(loadModule(cb))
      .catch(errorLoading);
    },
  }, {
    path: '/my-dashboard/forums',
    name: 'forums',
    getComponent(nextState, cb) {
      System.import('containers/forums')
      .then(loadModule(cb))
      .catch(errorLoading);
    },
  },
  {
    path: '/my-dashboard/messages',
    name: 'messages',
    getComponent(nextState, cb) {
      System.import('containers/Messages')
      .then(loadModule(cb))
      .catch(errorLoading);
    },
  },
    {
      path: '/my-dashboard/ratings',
      name: 'ratings',
      getComponent(nextState, cb) {
        System.import('containers/Ratings')
            .then(loadModule(cb))
            .catch(errorLoading);
      },
    },
    {
      path: '/user-profile/*',
      name: 'userprofile',
      getComponent(nextState, cb) {
        System.import('containers/UserProfile')
            .then(loadModule(cb))
            .catch(errorLoading);
      },
    },
    {
      path: '/user-profile1/:profileName',
      name: 'userprofile',
      getComponent(nextState, cb) {
        System.import('containers/UserProfile')
            .then(loadModule(cb))
            .catch(errorLoading);
      },
    },
    {
      path: '/testimonials',
      name: 'testimonials',
      getComponent(nextState, cb) {
        System.import('containers/Testimonial')
            .then(loadModule(cb))
            .catch(errorLoading);
      },
    },
    {
      path: '/my-profile*',
      name: 'myprofile',
      getComponent(nextState, cb) {
        System.import('containers/MyProfile')
            .then(loadModule(cb))
            .catch(errorLoading);
      }
    },
    {
      path: '/cintaa',
      name: 'cintaa',
      getComponent(nextState, cb) {
        System.import('containers/Cintaa')
            .then(loadModule(cb))
            .catch(errorLoading);
      }
    },
    {
      path: '/ContactUs',
      name: 'ContactUs',
      getComponent(nextState, cb) {
        System.import('containers/ContactUs')
            .then(loadModule(cb))
            .catch(errorLoading);
      }
    },
  {
    path: '*',
    name: 'notfound',
    getComponent(nextState, cb) {
      System.import('containers/NotFoundPage')
      .then(loadModule(cb))
      .catch(errorLoading);
    },
  },

];
}
